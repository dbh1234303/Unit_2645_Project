#include "G1_Audio.h"
#include "Buzzer.h"

extern Buzzer_cfg_t buzzer_cfg;

static void g1_audio_start(G1_AudioState* audio, uint32_t freq_hz, uint8_t volume, uint16_t duration_ms)
{
    buzzer_tone(&buzzer_cfg, freq_hz, volume);
    audio->tone_ms = duration_ms;
}

void G1_Audio_Init(G1_AudioState* audio)
{
    audio->tone_ms = 0u;
    audio->low_o2_cooldown_ms = 0u;
    buzzer_off(&buzzer_cfg);
}

void G1_Audio_Tick(G1_AudioState* audio, uint16_t frame_ms)
{
    if (audio->tone_ms > frame_ms) {
        audio->tone_ms = (uint16_t)(audio->tone_ms - frame_ms);
    } else if (audio->tone_ms > 0u) {
        audio->tone_ms = 0u;
        buzzer_off(&buzzer_cfg);
    }

    if (audio->low_o2_cooldown_ms > frame_ms) {
        audio->low_o2_cooldown_ms = (uint16_t)(audio->low_o2_cooldown_ms - frame_ms);
    } else {
        audio->low_o2_cooldown_ms = 0u;
    }
}

void G1_Audio_PlayStart(G1_AudioState* audio)     { g1_audio_start(audio, 920u, 24u, 80u); }
void G1_Audio_PlayShield(G1_AudioState* audio)    { g1_audio_start(audio, 1500u, 25u, 70u); }
void G1_Audio_PlayRescue(G1_AudioState* audio)    { g1_audio_start(audio, 1280u, 25u, 90u); }
void G1_Audio_PlaySupply(G1_AudioState* audio)    { g1_audio_start(audio, 1040u, 24u, 90u); }
void G1_Audio_PlayDock(G1_AudioState* audio)      { g1_audio_start(audio, 1700u, 28u, 120u); }
void G1_Audio_PlayPrecision(G1_AudioState* audio) { g1_audio_start(audio, 2000u, 30u, 90u); }
void G1_Audio_PlayCrash(G1_AudioState* audio)     { g1_audio_start(audio, 380u, 35u, 120u); }
void G1_Audio_PlayWarning(G1_AudioState* audio)   { g1_audio_start(audio, 600u, 22u, 60u); audio->low_o2_cooldown_ms = 900u; }
void G1_Audio_PlayClear(G1_AudioState* audio)     { g1_audio_start(audio, 2400u, 32u, 220u); }

void G1_Audio_Stop(G1_AudioState* audio)
{
    audio->tone_ms = 0u;
    buzzer_off(&buzzer_cfg);
}

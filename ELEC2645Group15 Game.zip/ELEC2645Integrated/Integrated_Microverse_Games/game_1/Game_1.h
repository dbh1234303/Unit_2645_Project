#ifndef GAME_1_H
#define GAME_1_H

#include "Menu.h"

/*
 * Game 1: Zero-G Rescue
 * Modular implementation split into:
 * - Game_1.c    : core state machine / loop
 * - G1_Physics  : inertia flight model and collision response
 * - G1_World    : hazards, rescue pods, supplies, mission target and guidance
 * - G1_UI       : title, tutorial, HUD, pause, result screens
 * - G1_Scoring  : rescue/dock/crash scoring and grade calculation
 * - G1_Audio    : feedback tones and warning beeps
 */

MenuState Game1_Run(void);

#endif

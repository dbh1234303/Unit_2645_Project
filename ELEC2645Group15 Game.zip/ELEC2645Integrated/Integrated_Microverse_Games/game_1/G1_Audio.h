#ifndef G1_AUDIO_H
#define G1_AUDIO_H

#include <stdint.h>

typedef struct {
    uint16_t tone_ms;
    uint16_t low_o2_cooldown_ms;
} G1_AudioState;

void G1_Audio_Init(G1_AudioState* audio);
void G1_Audio_Tick(G1_AudioState* audio, uint16_t frame_ms);
void G1_Audio_PlayStart(G1_AudioState* audio);
void G1_Audio_PlayShield(G1_AudioState* audio);
void G1_Audio_PlayRescue(G1_AudioState* audio);
void G1_Audio_PlaySupply(G1_AudioState* audio);
void G1_Audio_PlayDock(G1_AudioState* audio);
void G1_Audio_PlayPrecision(G1_AudioState* audio);
void G1_Audio_PlayCrash(G1_AudioState* audio);
void G1_Audio_PlayWarning(G1_AudioState* audio);
void G1_Audio_PlayClear(G1_AudioState* audio);
void G1_Audio_Stop(G1_AudioState* audio);

#endif

#include "G1_Scoring.h"
#include "G1_Physics.h"

uint16_t G1_Scoring_RescueBonus(const G1_World* world)
{
    return (uint16_t)(70u + ((uint16_t)world->wave * 12u) + ((uint16_t)world->dock_streak * 10u));
}

uint16_t G1_Scoring_DockBonus(const G1_World* world, const G1_Ship* ship, uint8_t precision_dock)
{
    uint16_t bonus = (uint16_t)(220u + ((uint16_t)world->wave * 25u));
    uint16_t oxygen_bonus = (uint16_t)(ship->oxygen / 20u);

    bonus = (uint16_t)(bonus + ((uint16_t)world->dock_streak * 18u));
    bonus = (uint16_t)(bonus + oxygen_bonus);

    if (precision_dock) {
        bonus = (uint16_t)(bonus + 80u);
    }
    if (G1_Physics_GetSpeedScore(ship) <= 80u) {
        bonus = (uint16_t)(bonus + 20u);
    }

    return bonus;
}

void G1_Scoring_OnCrash(G1_World* world, G1_Ship* ship)
{
    world->dock_streak = 0u;
    if (ship->score > 25u) {
        ship->score = (uint16_t)(ship->score - 25u);
    } else {
        ship->score = 0u;
    }
}

char G1_Scoring_Grade(const G1_World* world, const G1_Ship* ship, G1_GameOverReason reason)
{
    uint8_t target_met = (world->docked_total >= world->mission_target_docks) ? 1u : 0u;

    if (reason == G1_GAMEOVER_CLEAR && world->crash_count == 0u && world->precision_docks >= 2u && ship->oxygen >= 250u) {
        return 'S';
    }
    if (reason == G1_GAMEOVER_CLEAR && world->crash_count <= 1u) {
        return 'A';
    }
    if (target_met || world->docked_total + 1u >= world->mission_target_docks) {
        return 'B';
    }
    if (world->docked_total >= 2u) {
        return 'C';
    }
    return 'D';
}

#include "G1_Physics.h"

#define G1_ACCEL 58.0f
#define G1_DAMPING 0.985f
#define G1_SPEED_LIMIT 55.0f
#define G1_COLLISION_KICK 24.0f

static float g1_absf(float v)
{
    return (v < 0.0f) ? -v : v;
}

static void G1_Physics_DirectionVector(Direction direction, float* dx, float* dy)
{
    *dx = 0.0f;
    *dy = 0.0f;

    switch (direction) {
        case N:  *dy = -1.0f; break;
        case NE: *dx =  0.7f; *dy = -0.7f; break;
        case E:  *dx =  1.0f; break;
        case SE: *dx =  0.7f; *dy =  0.7f; break;
        case S:  *dy =  1.0f; break;
        case SW: *dx = -0.7f; *dy =  0.7f; break;
        case W:  *dx = -1.0f; break;
        case NW: *dx = -0.7f; *dy = -0.7f; break;
        case CENTRE:
        default:
            break;
    }
}

void G1_Physics_ResetShip(G1_Ship* ship, G1_Difficulty difficulty)
{
    ship->x = 26.0f;
    ship->y = 120.0f;
    ship->vx = 0.0f;
    ship->vy = 0.0f;
    ship->hx = 1.0f;
    ship->hy = 0.0f;
    ship->health = (difficulty == G1_DIFFICULTY_EXTREME) ? 3u : 4u;
    ship->oxygen = (difficulty == G1_DIFFICULTY_EXTREME) ? 760u : 900u;
    ship->carrying = 0u;
    ship->score = 0u;
    ship->invuln_ms = 0u;
    ship->shield_ms = 0u;
    ship->shield_cooldown_ms = 0u;
}

void G1_Physics_UpdateShip(G1_Ship* ship, Direction direction, float dt_s)
{
    float ax = 0.0f;
    float ay = 0.0f;
    float limit = G1_SPEED_LIMIT;

    G1_Physics_DirectionVector(direction, &ax, &ay);

    ship->vx += ax * G1_ACCEL * dt_s;
    ship->vy += ay * G1_ACCEL * dt_s;

    if (ship->shield_ms > 0u) {
        ship->vx *= 0.97f;
        ship->vy *= 0.97f;
        limit = 38.0f;
    } else {
        ship->vx *= G1_DAMPING;
        ship->vy *= G1_DAMPING;
    }

    if (ship->vx > limit) ship->vx = limit;
    if (ship->vx < -limit) ship->vx = -limit;
    if (ship->vy > limit) ship->vy = limit;
    if (ship->vy < -limit) ship->vy = -limit;

    ship->x += ship->vx * dt_s;
    ship->y += ship->vy * dt_s;

    if (direction != CENTRE) {
        ship->hx = ax;
        ship->hy = ay;
    } else if (g1_absf(ship->vx) > 2.0f || g1_absf(ship->vy) > 2.0f) {
        ship->hx = ship->vx;
        ship->hy = ship->vy;
    }
}

void G1_Physics_KeepInBounds(G1_Ship* ship)
{
    if (ship->x < (float)(G1_PLAY_MIN_X + G1_SHIP_RADIUS)) {
        ship->x = (float)(G1_PLAY_MIN_X + G1_SHIP_RADIUS);
        if (ship->vx < 0.0f) ship->vx = -ship->vx * 0.35f;
    }
    if (ship->x > (float)(G1_PLAY_MAX_X - G1_SHIP_RADIUS)) {
        ship->x = (float)(G1_PLAY_MAX_X - G1_SHIP_RADIUS);
        if (ship->vx > 0.0f) ship->vx = -ship->vx * 0.35f;
    }
    if (ship->y < (float)(G1_PLAY_MIN_Y + G1_SHIP_RADIUS)) {
        ship->y = (float)(G1_PLAY_MIN_Y + G1_SHIP_RADIUS);
        if (ship->vy < 0.0f) ship->vy = -ship->vy * 0.35f;
    }
    if (ship->y > (float)(G1_PLAY_MAX_Y - G1_SHIP_RADIUS)) {
        ship->y = (float)(G1_PLAY_MAX_Y - G1_SHIP_RADIUS);
        if (ship->vy > 0.0f) ship->vy = -ship->vy * 0.35f;
    }
}

void G1_Physics_ApplyCollisionKick(G1_Ship* ship, float hit_x, float hit_y)
{
    float dx = ship->x - hit_x;
    float dy = ship->y - hit_y;

    if (dx > -0.1f && dx < 0.1f) dx = 1.0f;
    if (dy > -0.1f && dy < 0.1f) dy = -1.0f;

    ship->vx = (dx > 0.0f) ? G1_COLLISION_KICK : -G1_COLLISION_KICK;
    ship->vy = (dy > 0.0f) ? G1_COLLISION_KICK : -G1_COLLISION_KICK;
}

uint16_t G1_Physics_GetSpeedScore(const G1_Ship* ship)
{
    float speed = g1_absf(ship->vx) + g1_absf(ship->vy);
    return (uint16_t)(speed * 10.0f);
}

uint8_t G1_Physics_IsPrecisionDock(const G1_Ship* ship)
{
    return (G1_Physics_GetSpeedScore(ship) <= 140u) ? 1u : 0u;
}

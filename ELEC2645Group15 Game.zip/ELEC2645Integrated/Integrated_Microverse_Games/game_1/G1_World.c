#include "G1_World.h"
#include <string.h>

#define G1_RESCUE_RADIUS 4u
#define G1_SUPPLY_RADIUS 4u

static uint32_t g1_rng_state = 0x13572468u;

static uint32_t g1_rand_next(void)
{
    g1_rng_state = (1103515245u * g1_rng_state + 12345u);
    return g1_rng_state;
}

static uint16_t g1_rand_range(uint16_t min, uint16_t max)
{
    uint32_t span = (uint32_t)(max - min + 1u);
    return (uint16_t)(min + (g1_rand_next() % span));
}

static void g1_wrap_entity(float* x, float* y)
{
    if (*x < (float)G1_PLAY_MIN_X) *x = (float)G1_PLAY_MAX_X;
    if (*x > (float)G1_PLAY_MAX_X) *x = (float)G1_PLAY_MIN_X;
    if (*y < (float)G1_PLAY_MIN_Y) *y = (float)G1_PLAY_MAX_Y;
    if (*y > (float)G1_PLAY_MAX_Y) *y = (float)G1_PLAY_MIN_Y;
}

static uint32_t g1_dist2(float x1, float y1, float x2, float y2)
{
    int32_t dx = (int32_t)(x1 - x2);
    int32_t dy = (int32_t)(y1 - y2);
    return (uint32_t)(dx * dx + dy * dy);
}

static void g1_spawn_asteroid(G1_Asteroid* asteroid, uint8_t wave)
{
    asteroid->active = 1u;
    asteroid->x = (float)g1_rand_range(80u, 225u);
    asteroid->y = (float)g1_rand_range(G1_PLAY_MIN_Y + 6u, G1_PLAY_MAX_Y - 6u);
    asteroid->vx = (float)((int16_t)g1_rand_range(8u, 24u) - 16);
    asteroid->vy = (float)((int16_t)g1_rand_range(8u, 24u) - 16);
    asteroid->radius = (uint8_t)(3u + (wave % 3u) + (g1_rand_next() % 3u));
}

static void g1_spawn_drone(G1_Drone* drone)
{
    drone->active = 1u;
    drone->x = (float)g1_rand_range(140u, 230u);
    drone->y = (float)g1_rand_range(G1_PLAY_MIN_Y + 10u, G1_PLAY_MAX_Y - 10u);
    drone->vx = 0.0f;
    drone->vy = 0.0f;
    drone->radius = 5u;
}

static void g1_spawn_rescue(G1_Pickup* rescue)
{
    rescue->active = 1u;
    rescue->kind = G1_PICKUP_RESCUE;
    rescue->x = (float)g1_rand_range(90u, 228u);
    rescue->y = (float)g1_rand_range(G1_PLAY_MIN_Y + 10u, G1_PLAY_MAX_Y - 10u);
    rescue->radius = G1_RESCUE_RADIUS;
}

static void g1_spawn_supply(G1_Pickup* supply)
{
    supply->active = 1u;
    supply->kind = G1_PICKUP_OXYGEN;
    supply->x = (float)g1_rand_range(70u, 210u);
    supply->y = (float)g1_rand_range(G1_PLAY_MIN_Y + 10u, G1_PLAY_MAX_Y - 10u);
    supply->radius = G1_SUPPLY_RADIUS;
}

static void g1_prepare_wave(G1_World* world)
{
    uint8_t i;
    uint8_t asteroid_count;
    uint8_t drone_count;

    for (i = 0u; i < G1_MAX_ASTEROIDS; i++) {
        world->asteroids[i].active = 0u;
    }
    for (i = 0u; i < G1_MAX_DRONES; i++) {
        world->drones[i].active = 0u;
    }
    for (i = 0u; i < G1_MAX_RESCUES; i++) {
        world->rescues[i].active = 0u;
    }
    for (i = 0u; i < G1_MAX_SUPPLIES; i++) {
        world->supplies[i].active = 0u;
    }

    asteroid_count = (uint8_t)(2u + world->wave);
    if (world->difficulty == G1_DIFFICULTY_EXTREME) {
        asteroid_count++;
    }
    if (asteroid_count > G1_MAX_ASTEROIDS) {
        asteroid_count = G1_MAX_ASTEROIDS;
    }

    drone_count = (world->wave >= 2u) ? 1u : 0u;
    if (world->wave >= 4u) {
        drone_count = 2u;
    }
    if (world->difficulty == G1_DIFFICULTY_EXTREME && drone_count < G1_MAX_DRONES) {
        drone_count++;
    }
    if (drone_count > G1_MAX_DRONES) {
        drone_count = G1_MAX_DRONES;
    }

    for (i = 0u; i < asteroid_count; i++) {
        g1_spawn_asteroid(&world->asteroids[i], world->wave);
    }
    for (i = 0u; i < drone_count; i++) {
        g1_spawn_drone(&world->drones[i]);
    }

    g1_spawn_rescue(&world->rescues[0]);
    if (world->wave >= 3u) {
        g1_spawn_rescue(&world->rescues[1]);
    }

    if (world->wave >= 2u || world->difficulty == G1_DIFFICULTY_EXTREME) {
        g1_spawn_supply(&world->supplies[0]);
    }
}

void G1_World_Seed(uint32_t seed)
{
    if (seed == 0u) {
        seed = 0x24681357u;
    }
    g1_rng_state = seed;
}

void G1_World_Init(G1_World* world, G1_Difficulty difficulty)
{
    memset(world, 0, sizeof(*world));
    world->difficulty = (uint8_t)difficulty;
    world->wave = 1u;
    world->mission_target_docks = (difficulty == G1_DIFFICULTY_EXTREME) ? 6u : 4u;
    world->mothership_x = 6u;
    world->mothership_y = 88u;
    world->mothership_w = 24u;
    world->mothership_h = 64u;
    g1_prepare_wave(world);
}

void G1_World_Update(G1_World* world, const G1_Ship* ship, float dt_s)
{
    uint8_t i;

    for (i = 0u; i < G1_MAX_ASTEROIDS; i++) {
        if (!world->asteroids[i].active) continue;
        world->asteroids[i].x += world->asteroids[i].vx * dt_s;
        world->asteroids[i].y += world->asteroids[i].vy * dt_s;
        g1_wrap_entity(&world->asteroids[i].x, &world->asteroids[i].y);
    }

    for (i = 0u; i < G1_MAX_DRONES; i++) {
        float dx;
        float dy;
        float chase = (world->difficulty == G1_DIFFICULTY_EXTREME) ? 7.0f : 5.0f;
        if (!world->drones[i].active) continue;

        dx = ship->x - world->drones[i].x;
        dy = ship->y - world->drones[i].y;

        if (dx > 2.0f) world->drones[i].vx += chase * dt_s;
        if (dx < -2.0f) world->drones[i].vx -= chase * dt_s;
        if (dy > 2.0f) world->drones[i].vy += chase * dt_s;
        if (dy < -2.0f) world->drones[i].vy -= chase * dt_s;

        if (world->drones[i].vx > 24.0f) world->drones[i].vx = 24.0f;
        if (world->drones[i].vx < -24.0f) world->drones[i].vx = -24.0f;
        if (world->drones[i].vy > 24.0f) world->drones[i].vy = 24.0f;
        if (world->drones[i].vy < -24.0f) world->drones[i].vy = -24.0f;

        world->drones[i].x += world->drones[i].vx * dt_s;
        world->drones[i].y += world->drones[i].vy * dt_s;
        g1_wrap_entity(&world->drones[i].x, &world->drones[i].y);
    }
}

uint8_t G1_World_HandlePickups(G1_World* world, G1_Ship* ship, uint8_t precision_dock)
{
    uint8_t i;
    uint8_t event_mask = G1_EVENT_NONE;
    uint8_t all_rescues_done = 1u;
    const uint32_t ship_pick_radius_sq = (uint32_t)((G1_SHIP_RADIUS + G1_RESCUE_RADIUS) * (G1_SHIP_RADIUS + G1_RESCUE_RADIUS));
    const uint32_t ship_supply_radius_sq = (uint32_t)((G1_SHIP_RADIUS + G1_SUPPLY_RADIUS) * (G1_SHIP_RADIUS + G1_SUPPLY_RADIUS));

    for (i = 0u; i < G1_MAX_RESCUES; i++) {
        if (world->rescues[i].active) {
            all_rescues_done = 0u;
        }
        if (!world->rescues[i].active || ship->carrying) continue;
        if (g1_dist2(ship->x, ship->y, world->rescues[i].x, world->rescues[i].y) <= ship_pick_radius_sq) {
            world->rescues[i].active = 0u;
            ship->carrying = 1u;
            world->rescued_total++;
            event_mask |= G1_EVENT_RESCUE;
            all_rescues_done = 1u;
        }
    }

    for (i = 0u; i < G1_MAX_RESCUES; i++) {
        if (world->rescues[i].active) {
            all_rescues_done = 0u;
        }
    }

    for (i = 0u; i < G1_MAX_SUPPLIES; i++) {
        if (!world->supplies[i].active) continue;
        if (g1_dist2(ship->x, ship->y, world->supplies[i].x, world->supplies[i].y) <= ship_supply_radius_sq) {
            world->supplies[i].active = 0u;
            if (ship->oxygen < 820u) ship->oxygen = (uint16_t)(ship->oxygen + 180u);
            else ship->oxygen = 999u;
            event_mask |= G1_EVENT_OXYGEN;
        }
    }

    if (ship->x >= world->mothership_x &&
        ship->x <= (float)(world->mothership_x + world->mothership_w) &&
        ship->y >= world->mothership_y &&
        ship->y <= (float)(world->mothership_y + world->mothership_h) &&
        ship->carrying) {
        ship->carrying = 0u;
        world->docked_total++;
        world->dock_streak++;
        if (world->dock_streak > world->best_dock_streak) {
            world->best_dock_streak = world->dock_streak;
        }
        if (precision_dock) {
            world->precision_docks++;
            event_mask |= G1_EVENT_PRECISION;
        }
        ship->oxygen = (ship->oxygen > 820u) ? 999u : (uint16_t)(ship->oxygen + 170u);
        event_mask |= G1_EVENT_DOCK;

        if (world->docked_total >= world->mission_target_docks) {
            event_mask |= G1_EVENT_CLEAR;
        } else {
            world->wave++;
            g1_prepare_wave(world);
        }
    } else if (all_rescues_done && !ship->carrying) {
        g1_spawn_rescue(&world->rescues[0]);
    }

    return event_mask;
}

uint8_t G1_World_CheckHazardHit(G1_World* world, const G1_Ship* ship, float* hit_x, float* hit_y)
{
    uint8_t i;

    for (i = 0u; i < G1_MAX_ASTEROIDS; i++) {
        uint8_t rsum;
        uint32_t limit_sq;
        if (!world->asteroids[i].active) continue;
        rsum = (uint8_t)(G1_SHIP_RADIUS + world->asteroids[i].radius);
        limit_sq = (uint32_t)(rsum * rsum);
        if (g1_dist2(ship->x, ship->y, world->asteroids[i].x, world->asteroids[i].y) <= limit_sq) {
            *hit_x = world->asteroids[i].x;
            *hit_y = world->asteroids[i].y;
            world->crash_count++;
            return 1u;
        }
    }

    for (i = 0u; i < G1_MAX_DRONES; i++) {
        uint8_t rsum;
        uint32_t limit_sq;
        if (!world->drones[i].active) continue;
        rsum = (uint8_t)(G1_SHIP_RADIUS + world->drones[i].radius);
        limit_sq = (uint32_t)(rsum * rsum);
        if (g1_dist2(ship->x, ship->y, world->drones[i].x, world->drones[i].y) <= limit_sq) {
            *hit_x = world->drones[i].x;
            *hit_y = world->drones[i].y;
            world->crash_count++;
            return 1u;
        }
    }

    return 0u;
}

uint8_t G1_World_CountActiveRescues(const G1_World* world)
{
    uint8_t i;
    uint8_t count = 0u;

    for (i = 0u; i < G1_MAX_RESCUES; i++) {
        if (world->rescues[i].active) {
            count++;
        }
    }
    return count;
}

void G1_World_GetPrimaryTarget(const G1_World* world, const G1_Ship* ship, float* tx, float* ty, uint8_t* has_target, uint8_t* is_home_target)
{
    uint8_t i;
    uint8_t found = 0u;
    uint32_t best_dist = 0u;

    if (ship->carrying) {
        *tx = (float)(world->mothership_x + (world->mothership_w / 2u));
        *ty = (float)(world->mothership_y + (world->mothership_h / 2u));
        *has_target = 1u;
        *is_home_target = 1u;
        return;
    }

    for (i = 0u; i < G1_MAX_RESCUES; i++) {
        if (!world->rescues[i].active) continue;
        if (!found) {
            *tx = world->rescues[i].x;
            *ty = world->rescues[i].y;
            best_dist = g1_dist2(ship->x, ship->y, world->rescues[i].x, world->rescues[i].y);
            found = 1u;
        } else {
            uint32_t dist = g1_dist2(ship->x, ship->y, world->rescues[i].x, world->rescues[i].y);
            if (dist < best_dist) {
                best_dist = dist;
                *tx = world->rescues[i].x;
                *ty = world->rescues[i].y;
            }
        }
    }

    *has_target = found;
    *is_home_target = 0u;
}

uint8_t G1_World_GetHazardWarning(const G1_World* world, const G1_Ship* ship)
{
    uint8_t i;
    uint32_t alert_near = 28u * 28u;
    uint32_t alert_mid = 44u * 44u;
    uint8_t warning = 0u;

    for (i = 0u; i < G1_MAX_ASTEROIDS; i++) {
        if (!world->asteroids[i].active) continue;
        if (g1_dist2(ship->x, ship->y, world->asteroids[i].x, world->asteroids[i].y) <= alert_near) {
            return 2u;
        }
        if (g1_dist2(ship->x, ship->y, world->asteroids[i].x, world->asteroids[i].y) <= alert_mid) {
            warning = 1u;
        }
    }

    for (i = 0u; i < G1_MAX_DRONES; i++) {
        if (!world->drones[i].active) continue;
        if (g1_dist2(ship->x, ship->y, world->drones[i].x, world->drones[i].y) <= alert_near) {
            return 2u;
        }
        if (g1_dist2(ship->x, ship->y, world->drones[i].x, world->drones[i].y) <= alert_mid) {
            warning = 1u;
        }
    }

    return warning;
}

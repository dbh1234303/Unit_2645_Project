#ifndef G1_PHYSICS_H
#define G1_PHYSICS_H

#include <stdint.h>
#include "G1_Types.h"
#include "Joystick.h"

void G1_Physics_ResetShip(G1_Ship* ship, G1_Difficulty difficulty);
void G1_Physics_UpdateShip(G1_Ship* ship, Direction direction, float dt_s);
void G1_Physics_KeepInBounds(G1_Ship* ship);
void G1_Physics_ApplyCollisionKick(G1_Ship* ship, float hit_x, float hit_y);
uint16_t G1_Physics_GetSpeedScore(const G1_Ship* ship);
uint8_t G1_Physics_IsPrecisionDock(const G1_Ship* ship);

#endif

#ifndef G1_WORLD_H
#define G1_WORLD_H

#include <stdint.h>
#include "G1_Types.h"

void G1_World_Seed(uint32_t seed);
void G1_World_Init(G1_World* world, G1_Difficulty difficulty);
void G1_World_Update(G1_World* world, const G1_Ship* ship, float dt_s);
uint8_t G1_World_HandlePickups(G1_World* world, G1_Ship* ship, uint8_t precision_dock);
uint8_t G1_World_CheckHazardHit(G1_World* world, const G1_Ship* ship, float* hit_x, float* hit_y);
uint8_t G1_World_CountActiveRescues(const G1_World* world);
void G1_World_GetPrimaryTarget(const G1_World* world, const G1_Ship* ship, float* tx, float* ty, uint8_t* has_target, uint8_t* is_home_target);
uint8_t G1_World_GetHazardWarning(const G1_World* world, const G1_Ship* ship);

#endif

#ifndef G1_SCORING_H
#define G1_SCORING_H

#include <stdint.h>
#include "G1_Types.h"

uint16_t G1_Scoring_RescueBonus(const G1_World* world);
uint16_t G1_Scoring_DockBonus(const G1_World* world, const G1_Ship* ship, uint8_t precision_dock);
void G1_Scoring_OnCrash(G1_World* world, G1_Ship* ship);
char G1_Scoring_Grade(const G1_World* world, const G1_Ship* ship, G1_GameOverReason reason);

#endif

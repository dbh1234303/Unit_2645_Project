#ifndef G1_TYPES_H
#define G1_TYPES_H

#include <stdint.h>

typedef enum {
    G1_DIFFICULTY_NORMAL = 0,
    G1_DIFFICULTY_EXTREME = 1
} G1_Difficulty;

typedef enum {
    G1_GAMEOVER_NONE = 0,
    G1_GAMEOVER_OXYGEN,
    G1_GAMEOVER_HULL,
    G1_GAMEOVER_CLEAR
} G1_GameOverReason;

typedef enum {
    G1_PICKUP_RESCUE = 0,
    G1_PICKUP_OXYGEN = 1
} G1_PickupKind;

#define G1_SCREEN_W 240
#define G1_SCREEN_H 240
#define G1_HUD_H 24
#define G1_PLAY_MIN_X 4
#define G1_PLAY_MAX_X 235
#define G1_PLAY_MIN_Y 28
#define G1_PLAY_MAX_Y 235

#define G1_SHIP_RADIUS 5
#define G1_MAX_ASTEROIDS 7
#define G1_MAX_DRONES 3
#define G1_MAX_RESCUES 2
#define G1_MAX_SUPPLIES 1

#define G1_EVENT_NONE      0x00u
#define G1_EVENT_RESCUE    0x01u
#define G1_EVENT_DOCK      0x02u
#define G1_EVENT_OXYGEN    0x04u
#define G1_EVENT_HIT       0x08u
#define G1_EVENT_CLEAR     0x10u
#define G1_EVENT_PRECISION 0x20u

typedef struct {
    float x;
    float y;
    float vx;
    float vy;
    float hx;
    float hy;
    uint8_t health;
    uint16_t oxygen;
    uint8_t carrying;
    uint16_t score;
    uint16_t invuln_ms;
    uint16_t shield_ms;
    uint16_t shield_cooldown_ms;
} G1_Ship;

typedef struct {
    uint8_t active;
    float x;
    float y;
    float vx;
    float vy;
    uint8_t radius;
} G1_Asteroid;

typedef struct {
    uint8_t active;
    float x;
    float y;
    float vx;
    float vy;
    uint8_t radius;
} G1_Drone;

typedef struct {
    uint8_t active;
    uint8_t kind;
    float x;
    float y;
    uint8_t radius;
} G1_Pickup;

typedef struct {
    G1_Asteroid asteroids[G1_MAX_ASTEROIDS];
    G1_Drone drones[G1_MAX_DRONES];
    G1_Pickup rescues[G1_MAX_RESCUES];
    G1_Pickup supplies[G1_MAX_SUPPLIES];
    uint8_t wave;
    uint8_t difficulty;
    uint8_t mission_target_docks;
    uint8_t dock_streak;
    uint8_t best_dock_streak;
    uint8_t precision_docks;
    uint16_t rescued_total;
    uint16_t docked_total;
    uint16_t crash_count;
    uint8_t mothership_x;
    uint8_t mothership_y;
    uint8_t mothership_w;
    uint8_t mothership_h;
} G1_World;

#endif

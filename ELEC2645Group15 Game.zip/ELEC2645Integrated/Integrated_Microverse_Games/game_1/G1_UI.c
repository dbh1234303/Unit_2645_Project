#include "G1_UI.h"
#include "G1_World.h"
#include "G1_Physics.h"
#include "LCD.h"
#include <stdio.h>

extern ST7789V2_cfg_t cfg0;

static void g1_draw_bar(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t value, uint16_t max_value, uint8_t outline_colour, uint8_t fill_colour)
{
    uint16_t fill_w;
    if (max_value == 0u) {
        max_value = 1u;
    }
    fill_w = (uint16_t)(((uint32_t)(w - 2u) * value) / max_value);
    LCD_Draw_Rect(x, y, w, h, outline_colour, 0);
    LCD_Draw_Rect((uint16_t)(x + 1u), (uint16_t)(y + 1u), (uint16_t)(w - 2u), (uint16_t)(h - 2u), 0, 1);
    if (fill_w > 0u) {
        LCD_Draw_Rect((uint16_t)(x + 1u), (uint16_t)(y + 1u), fill_w, (uint16_t)(h - 2u), fill_colour, 1);
    }
}

static void g1_draw_panel(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t border_colour, uint8_t accent_colour)
{
    LCD_Draw_Rect(x, y, w, h, border_colour, 0);
    if (w > 6u && h > 6u) {
        LCD_Draw_Rect((uint16_t)(x + 2u), (uint16_t)(y + 2u), (uint16_t)(w - 4u), (uint16_t)(h - 4u), accent_colour, 0);
    }
    LCD_Draw_Line(x, y, (uint16_t)(x + 12u), y, accent_colour);
    LCD_Draw_Line((uint16_t)(x + w - 13u), y, (uint16_t)(x + w - 1u), y, accent_colour);
    LCD_Draw_Line(x, (uint16_t)(y + h - 1u), (uint16_t)(x + 12u), (uint16_t)(y + h - 1u), accent_colour);
    LCD_Draw_Line((uint16_t)(x + w - 13u), (uint16_t)(y + h - 1u), (uint16_t)(x + w - 1u), (uint16_t)(y + h - 1u), accent_colour);
}

static void g1_draw_background_grid(uint16_t elapsed_ms)
{
    uint16_t x;
    uint16_t y;
    uint16_t shift = (uint16_t)((elapsed_ms / 70u) % 12u);

    for (x = 0u; x < G1_SCREEN_W; x += 24u) {
        LCD_Draw_Line(x, G1_HUD_H + 1u, x, G1_SCREEN_H - 1u, 13u);
    }
    for (y = (uint16_t)(G1_HUD_H + 8u); y < G1_SCREEN_H; y = (uint16_t)(y + 24u)) {
        LCD_Draw_Line(0u, y, G1_SCREEN_W - 1u, y, 13u);
    }

    for (y = (uint16_t)(G1_HUD_H + 6u); y < G1_SCREEN_H; y = (uint16_t)(y + 20u)) {
        uint16_t px = (uint16_t)((shift + (y * 7u)) % G1_SCREEN_W);
        LCD_Set_Pixel(px, y, 1u);
        if (px + 1u < G1_SCREEN_W) {
            LCD_Set_Pixel((uint16_t)(px + 1u), y, 1u);
        }
    }

    for (x = 14u; x < G1_SCREEN_W; x = (uint16_t)(x + 37u)) {
        uint16_t py = (uint16_t)(G1_HUD_H + 12u + ((x + shift * 3u) % 34u));
        if (py < G1_SCREEN_H) {
            LCD_Set_Pixel(x, py, 3u);
        }
    }
}

static void g1_draw_dotted_line(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t colour)
{
    int16_t dx = (int16_t)x1 - (int16_t)x0;
    int16_t dy = (int16_t)y1 - (int16_t)y0;
    uint16_t steps = (uint16_t)((dx < 0 ? -dx : dx) > (dy < 0 ? -dy : dy) ? (dx < 0 ? -dx : dx) : (dy < 0 ? -dy : dy));
    uint16_t i;

    if (steps == 0u) {
        LCD_Set_Pixel(x0, y0, colour);
        return;
    }

    for (i = 0u; i <= steps; i = (uint16_t)(i + 3u)) {
        uint16_t px = (uint16_t)(x0 + ((int32_t)dx * (int32_t)i) / (int32_t)steps);
        uint16_t py = (uint16_t)(y0 + ((int32_t)dy * (int32_t)i) / (int32_t)steps);
        if (px < G1_SCREEN_W && py < G1_SCREEN_H) {
            LCD_Set_Pixel(px, py, colour);
        }
    }
}

static void g1_draw_ship(const G1_Ship* ship)
{
    uint16_t sx = (uint16_t)ship->x;
    uint16_t sy = (uint16_t)ship->y;
    uint8_t body_colour = ship->shield_ms ? 14u : 1u;
    int8_t dir_x = 0;
    int8_t dir_y = -1;
    int8_t side_x;
    int8_t side_y;
    uint16_t nose_x;
    uint16_t nose_y;
    uint16_t left_x;
    uint16_t left_y;
    uint16_t right_x;
    uint16_t right_y;

    if (ship->hx > 0.4f) {
        dir_x = 1;
        dir_y = 0;
    } else if (ship->hx < -0.4f) {
        dir_x = -1;
        dir_y = 0;
    } else if (ship->hy > 0.4f) {
        dir_x = 0;
        dir_y = 1;
    }

    side_x = (int8_t)(-dir_y);
    side_y = (int8_t)(dir_x);

    nose_x = (uint16_t)(sx + dir_x * 7);
    nose_y = (uint16_t)(sy + dir_y * 7);
    left_x = (uint16_t)(sx + side_x * 5 - dir_x * 3);
    left_y = (uint16_t)(sy + side_y * 5 - dir_y * 3);
    right_x = (uint16_t)(sx - side_x * 5 - dir_x * 3);
    right_y = (uint16_t)(sy - side_y * 5 - dir_y * 3);

    LCD_Draw_Circle(sx, sy, 3u, body_colour, 1);
    LCD_Draw_Line(nose_x, nose_y, left_x, left_y, body_colour);
    LCD_Draw_Line(nose_x, nose_y, right_x, right_y, body_colour);
    LCD_Draw_Line(left_x, left_y, right_x, right_y, body_colour);
    LCD_Draw_Line((uint16_t)(sx + side_x * 6), (uint16_t)(sy + side_y * 6), (uint16_t)(sx + side_x * 2), (uint16_t)(sy + side_y * 2), body_colour);
    LCD_Draw_Line((uint16_t)(sx - side_x * 6), (uint16_t)(sy - side_y * 6), (uint16_t)(sx - side_x * 2), (uint16_t)(sy - side_y * 2), body_colour);

    if ((ship->hx > 0.1f) || (ship->hx < -0.1f) || (ship->hy > 0.1f) || (ship->hy < -0.1f)) {
        uint16_t thr_x = (uint16_t)(sx - dir_x * 6);
        uint16_t thr_y = (uint16_t)(sy - dir_y * 6);
        LCD_Draw_Line(thr_x, thr_y, (uint16_t)(thr_x - dir_x * 3 + side_x * 2), (uint16_t)(thr_y - dir_y * 3 + side_y * 2), 14u);
        LCD_Draw_Line(thr_x, thr_y, (uint16_t)(thr_x - dir_x * 3 - side_x * 2), (uint16_t)(thr_y - dir_y * 3 - side_y * 2), 14u);
    }

    if (ship->carrying) {
        uint16_t pod_x = (uint16_t)(sx - dir_x * 9);
        uint16_t pod_y = (uint16_t)(sy - dir_y * 9);
        LCD_Draw_Circle(pod_x, pod_y, 2u, 6u, 1);
        LCD_Draw_Line(pod_x, pod_y, (uint16_t)(sx - dir_x * 5), (uint16_t)(sy - dir_y * 5), 13u);
    }

    if (ship->shield_ms) {
        LCD_Draw_Circle(sx, sy, 8u, 11u, 0);
        LCD_Draw_Circle(sx, sy, 10u, 11u, 0);
        LCD_Set_Pixel((uint16_t)(sx + 9u), sy, 11u);
        LCD_Set_Pixel((uint16_t)(sx - 9u), sy, 11u);
        LCD_Set_Pixel(sx, (uint16_t)(sy + 9u), 11u);
        LCD_Set_Pixel(sx, (uint16_t)(sy - 9u), 11u);
    }
}

static void g1_draw_mothership(const G1_World* world)
{
    uint16_t x = world->mothership_x;
    uint16_t y = world->mothership_y;
    uint16_t w = world->mothership_w;
    uint16_t h = world->mothership_h;

    LCD_Draw_Rect(x, y, w, h, 3u, 0);
    LCD_Draw_Rect((uint16_t)(x + 4u), (uint16_t)(y + 5u), (uint16_t)(w - 8u), (uint16_t)(h - 10u), 13u, 0);
    LCD_Draw_Rect((uint16_t)(x + w - 9u), (uint16_t)(y + 8u), 6u, (uint16_t)(h - 16u), 3u, 0);
    LCD_Draw_Line((uint16_t)(x + 3u), (uint16_t)(y + h / 2u), (uint16_t)(x + 10u), (uint16_t)(y + h / 2u), 3u);
    LCD_Draw_Line((uint16_t)(x + 3u), (uint16_t)(y + h / 2u + 6u), (uint16_t)(x + 12u), (uint16_t)(y + h / 2u + 6u), 13u);
    LCD_Draw_Circle((uint16_t)(x + 14u), (uint16_t)(y + 12u), 3u, 1u, 0);
    LCD_printString("M", (uint16_t)(x + 12u), (uint16_t)(y + 24u), 3u, 2u);
}

static void g1_draw_asteroid(const G1_Asteroid* asteroid)
{
    uint16_t x = (uint16_t)asteroid->x;
    uint16_t y = (uint16_t)asteroid->y;
    uint16_t r = asteroid->radius;

    LCD_Draw_Circle(x, y, r, 13u, 0);
    if (r > 3u) {
        LCD_Draw_Circle((uint16_t)(x + 2u), (uint16_t)(y - 1u), (uint16_t)(r / 2u), 13u, 0);
        LCD_Draw_Circle((uint16_t)(x - 2u), (uint16_t)(y + 2u), 1u, 1u, 0);
        LCD_Draw_Circle((uint16_t)(x + 1u), (uint16_t)(y - 3u), 1u, 1u, 0);
        LCD_Draw_Line((uint16_t)(x - r), y, (uint16_t)(x - r - 3u), (uint16_t)(y + 1u), 13u);
        LCD_Draw_Line((uint16_t)(x + r), y, (uint16_t)(x + r + 2u), (uint16_t)(y - 2u), 13u);
    }
}

static void g1_draw_drone(const G1_Drone* drone)
{
    uint16_t x = (uint16_t)drone->x;
    uint16_t y = (uint16_t)drone->y;

    LCD_Draw_Line(x, (uint16_t)(y - 5u), (uint16_t)(x + 5u), y, 2u);
    LCD_Draw_Line((uint16_t)(x + 5u), y, x, (uint16_t)(y + 5u), 2u);
    LCD_Draw_Line(x, (uint16_t)(y + 5u), (uint16_t)(x - 5u), y, 2u);
    LCD_Draw_Line((uint16_t)(x - 5u), y, x, (uint16_t)(y - 5u), 2u);
    LCD_Draw_Line((uint16_t)(x - 7u), (uint16_t)(y - 7u), (uint16_t)(x - 2u), (uint16_t)(y - 2u), 13u);
    LCD_Draw_Line((uint16_t)(x + 7u), (uint16_t)(y - 7u), (uint16_t)(x + 2u), (uint16_t)(y - 2u), 13u);
    LCD_Draw_Line((uint16_t)(x - 7u), (uint16_t)(y + 7u), (uint16_t)(x - 2u), (uint16_t)(y + 2u), 13u);
    LCD_Draw_Line((uint16_t)(x + 7u), (uint16_t)(y + 7u), (uint16_t)(x + 2u), (uint16_t)(y + 2u), 13u);
    LCD_Draw_Circle(x, y, 1u, 2u, 1);
}

static void g1_draw_rescue(const G1_Pickup* pickup)
{
    uint16_t x = (uint16_t)pickup->x;
    uint16_t y = (uint16_t)pickup->y;

    LCD_Draw_Circle(x, y, 4u, 6u, 0);
    LCD_Draw_Circle(x, (uint16_t)(y - 2u), 1u, 6u, 1);
    LCD_Draw_Line(x, (uint16_t)(y - 1u), x, (uint16_t)(y + 3u), 6u);
    LCD_Draw_Line((uint16_t)(x - 2u), y, (uint16_t)(x + 2u), y, 6u);
    LCD_Draw_Line((uint16_t)(x - 2u), (uint16_t)(y + 4u), (uint16_t)(x + 2u), (uint16_t)(y + 4u), 1u);
    LCD_Draw_Circle(x, y, 7u, 13u, 0);
}

static void g1_draw_supply(const G1_Pickup* pickup)
{
    uint16_t x = (uint16_t)pickup->x;
    uint16_t y = (uint16_t)pickup->y;

    LCD_Draw_Rect((uint16_t)(x - 5u), (uint16_t)(y - 6u), 10u, 12u, 14u, 0);
    LCD_Draw_Rect((uint16_t)(x - 2u), (uint16_t)(y - 8u), 4u, 3u, 14u, 0);
    LCD_printString("O2", (uint16_t)(x - 5u), (uint16_t)(y - 2u), 14u, 1u);
}

static void g1_draw_radar(const G1_Ship* ship, const G1_World* world)
{
    uint16_t rx = 176u;
    uint16_t ry = 28u;
    uint16_t rw = 58u;
    uint16_t rh = 44u;
    uint8_t i;

    LCD_Draw_Rect(rx, ry, rw, rh, 13u, 0);
    LCD_Draw_Line((uint16_t)(rx + rw / 2u), (uint16_t)(ry + 1u), (uint16_t)(rx + rw / 2u), (uint16_t)(ry + rh - 2u), 13u);
    LCD_Draw_Line((uint16_t)(rx + 1u), (uint16_t)(ry + rh / 2u), (uint16_t)(rx + rw - 2u), (uint16_t)(ry + rh / 2u), 13u);
    LCD_printString("SCAN", (uint16_t)(rx + 14u), (uint16_t)(ry + 2u), 13u, 1u);

    LCD_Set_Pixel((uint16_t)(rx + (uint16_t)(((ship->x * (float)(rw - 6u)) / (float)G1_SCREEN_W)) + 3u),
                  (uint16_t)(ry + (uint16_t)(((ship->y * (float)(rh - 8u)) / (float)G1_SCREEN_H)) + 5u), 3u);

    for (i = 0u; i < G1_MAX_RESCUES; i++) {
        if (world->rescues[i].active) {
            LCD_Set_Pixel((uint16_t)(rx + (uint16_t)(((world->rescues[i].x * (float)(rw - 6u)) / (float)G1_SCREEN_W)) + 3u),
                          (uint16_t)(ry + (uint16_t)(((world->rescues[i].y * (float)(rh - 8u)) / (float)G1_SCREEN_H)) + 5u), 6u);
        }
    }
    for (i = 0u; i < G1_MAX_DRONES; i++) {
        if (world->drones[i].active) {
            LCD_Set_Pixel((uint16_t)(rx + (uint16_t)(((world->drones[i].x * (float)(rw - 6u)) / (float)G1_SCREEN_W)) + 3u),
                          (uint16_t)(ry + (uint16_t)(((world->drones[i].y * (float)(rh - 8u)) / (float)G1_SCREEN_H)) + 5u), 2u);
        }
    }
}

static void g1_draw_world(const G1_World* world, const G1_Ship* ship, uint16_t elapsed_ms)
{
    uint8_t i;
    float tx = 0.0f;
    float ty = 0.0f;
    uint8_t has_target = 0u;
    uint8_t is_home = 0u;

    g1_draw_background_grid(elapsed_ms);
    g1_draw_mothership(world);

    for (i = 0u; i < G1_MAX_ASTEROIDS; i++) {
        if (!world->asteroids[i].active) continue;
        g1_draw_asteroid(&world->asteroids[i]);
    }
    for (i = 0u; i < G1_MAX_DRONES; i++) {
        if (!world->drones[i].active) continue;
        g1_draw_drone(&world->drones[i]);
    }
    for (i = 0u; i < G1_MAX_RESCUES; i++) {
        if (!world->rescues[i].active) continue;
        g1_draw_rescue(&world->rescues[i]);
    }
    for (i = 0u; i < G1_MAX_SUPPLIES; i++) {
        if (!world->supplies[i].active) continue;
        g1_draw_supply(&world->supplies[i]);
    }

    G1_World_GetPrimaryTarget(world, ship, &tx, &ty, &has_target, &is_home);
    if (has_target) {
        g1_draw_dotted_line((uint16_t)ship->x, (uint16_t)ship->y, (uint16_t)tx, (uint16_t)ty, is_home ? 3u : 11u);
        LCD_Draw_Circle((uint16_t)tx, (uint16_t)ty, is_home ? 6u : 5u, is_home ? 3u : 11u, 0);
        if (is_home) {
            LCD_printString("DOCK", (uint16_t)(tx - 12u), (uint16_t)(ty - 14u), 3u, 1u);
        } else {
            LCD_printString("SOS", (uint16_t)(tx - 9u), (uint16_t)(ty - 14u), 6u, 1u);
        }
    }

    g1_draw_radar(ship, world);
}

void G1_UI_RenderTitle(uint8_t selected_option, G1_Difficulty preview_difficulty, uint16_t session_best, uint8_t blink_on)
{
    char line[32];
    uint8_t i;
    const char* options[4] = {"Start: Normal", "Start: Extreme", "How to Play", "Return Menu"};

    LCD_Fill_Buffer(0);
    LCD_Draw_Circle(198, 36, 18u, 13u, 0);
    LCD_Draw_Circle(198, 36, 9u, 13u, 0);
    LCD_Draw_Line(18, 54, 220, 54, 13u);
    g1_draw_panel(16, 80, 208, 104, 1u, 13u);
    g1_draw_panel(16, 190, 208, 34, 13u, 1u);

    LCD_printString("ZERO-G", 68, 12, 1, 3);
    LCD_printString("RESCUE", 60, 38, 1, 3);
    LCD_printString("Arcade inertia mission", 28, 60, 3u, 1u);

    g1_draw_ship(&(G1_Ship){.x = 38.0f, .y = 45.0f, .hx = 1.0f, .hy = 0.0f, .shield_ms = 1u});
    g1_draw_rescue(&(G1_Pickup){.x = 124.0f, .y = 43.0f, .radius = 4u});
    g1_draw_drone(&(G1_Drone){.x = 156.0f, .y = 43.0f});

    for (i = 0u; i < 4u; i++) {
        LCD_printString((i == selected_option) ? ">" : " ", 32, (uint16_t)(96u + i * 20u), i == selected_option ? 3u : 13u, 1u);
        LCD_printString((char*)options[i], 46, (uint16_t)(96u + i * 20u), (i == selected_option) ? 1u : 13u, 1u);
    }

    snprintf(line, sizeof(line), "Session Best:%u", session_best);
    LCD_printString(line, 26, 198, 6u, 1u);
    LCD_printString(preview_difficulty == G1_DIFFICULTY_EXTREME ? "Difficulty Preview: EXTREME" : "Difficulty Preview: NORMAL", 26, 210, preview_difficulty == G1_DIFFICULTY_EXTREME ? 2u : 3u, 1u);

    if (blink_on) {
        LCD_printString("Joystick move   BT3 confirm", 22, 226, 13u, 1u);
    }
    LCD_Refresh(&cfg0);
}

void G1_UI_RenderTutorial(uint8_t blink_on)
{
    LCD_Fill_Buffer(0);
    LCD_printString("HOW TO PLAY", 44, 10, 1, 3);
    g1_draw_panel(10, 38, 220, 154, 1u, 13u);
    g1_draw_panel(10, 198, 220, 30, 13u, 1u);

    g1_draw_ship(&(G1_Ship){.x = 26.0f, .y = 58.0f, .hx = 1.0f, .hy = 0.0f});
    LCD_printString("Thrust with joystick", 42, 52, 1u, 1u);
    g1_draw_rescue(&(G1_Pickup){.x = 24.0f, .y = 82.0f, .radius = 4u});
    LCD_printString("Collect SOS survivors", 42, 76, 6u, 1u);
    g1_draw_mothership(&(G1_World){.mothership_x = 14u, .mothership_y = 96u, .mothership_w = 20u, .mothership_h = 30u});
    LCD_printString("Return to mothership to dock", 42, 100, 3u, 1u);
    g1_draw_supply(&(G1_Pickup){.x = 24.0f, .y = 132.0f});
    LCD_printString("Pick O2 tanks before empty", 42, 124, 14u, 1u);
    g1_draw_drone(&(G1_Drone){.x = 24.0f, .y = 156.0f});
    LCD_printString("Avoid drones and asteroids", 42, 148, 2u, 1u);
    LCD_printString("BT2 shield   BT3 pause/confirm", 24, 172, 13u, 1u);

    if (blink_on) {
        LCD_printString("BT2 or BT3 return", 58, 208, 13u, 1u);
    }
    LCD_Refresh(&cfg0);
}

void G1_UI_RenderGameplay(const G1_Ship* ship, const G1_World* world, uint32_t elapsed_ms)
{
    char line[40];
    uint16_t oxygen_colour = (ship->oxygen < 240u) ? 2u : 3u;
    uint16_t shield_fill = ship->shield_cooldown_ms ? (uint16_t)(5000u - ship->shield_cooldown_ms) : 5000u;
    uint8_t warning = G1_World_GetHazardWarning(world, ship);
    uint8_t active_rescues = G1_World_CountActiveRescues(world);

    LCD_Fill_Buffer(0);

    g1_draw_panel(0, 0, G1_SCREEN_W, G1_HUD_H, 1u, 13u);
    LCD_printString("HP", 4, 4, 1, 1);
    g1_draw_bar(20, 3, 34, 8, ship->health, (world->difficulty == G1_DIFFICULTY_EXTREME) ? 3u : 4u, 1u, 2u);

    LCD_printString("O2", 60, 4, 1, 1);
    g1_draw_bar(76, 3, 46, 8, ship->oxygen, 999u, 1u, (uint8_t)oxygen_colour);

    LCD_printString("W", 128, 4, 13u, 1u);
    snprintf(line, sizeof(line), "%u", world->wave);
    LCD_printString(line, 138, 4, 1u, 1u);
    LCD_printString("S", 164, 4, 13u, 1u);
    snprintf(line, sizeof(line), "%u", ship->score);
    LCD_printString(line, 174, 4, 1u, 1u);

    g1_draw_world(world, ship, (uint16_t)(elapsed_ms & 0xFFFFu));
    g1_draw_ship(ship);

    g1_draw_panel(6, 200, 166, 34, 13u, 1u);
    g1_draw_panel(176, 200, 58, 34, 13u, 1u);

    snprintf(line, sizeof(line), "Dock %u/%u", world->docked_total, world->mission_target_docks);
    LCD_printString(line, 14, 206, 1, 1);
    snprintf(line, sizeof(line), "SOS:%u", active_rescues + (ship->carrying ? 1u : 0u));
    LCD_printString(line, 14, 218, ship->carrying ? 6u : 13u, 1);
    snprintf(line, sizeof(line), "Streak:%u", world->dock_streak);
    LCD_printString(line, 76, 218, world->dock_streak ? 11u : 13u, 1);
    LCD_printString(ship->shield_ms ? "Shield ON" : (ship->shield_cooldown_ms == 0u ? "Shield READY" : "Shield COOL"), 76, 206, ship->shield_ms ? 14u : (ship->shield_cooldown_ms == 0u ? 3u : 2u), 1);

    snprintf(line, sizeof(line), "%lus", (unsigned long)(elapsed_ms / 1000u));
    LCD_printString(line, 188, 206, 1u, 1u);
    snprintf(line, sizeof(line), "V:%u", G1_Physics_GetSpeedScore(ship) / 10u);
    LCD_printString(line, 184, 218, 13u, 1u);

    g1_draw_bar(146, 218, 20, 6, shield_fill, 5000u, 1u, 11u);

    if (warning == 2u) {
        g1_draw_panel(74, 82, 92, 18, 2u, 13u);
        LCD_printString("!! DANGER !!", 84, 87, 2u, 1u);
    } else if (warning == 1u) {
        g1_draw_panel(78, 82, 84, 18, 13u, 1u);
        LCD_printString("CAUTION", 98, 87, 13u, 1u);
    }
    if (ship->carrying) {
        g1_draw_panel(46, 104, 148, 18, 3u, 13u);
        LCD_printString("Escort pod home for score", 54, 109, 3u, 1u);
    }

    LCD_Refresh(&cfg0);
}

void G1_UI_RenderPause(uint8_t selected_option)
{
    LCD_Fill_Buffer(0);
    g1_draw_panel(24, 44, 192, 148, 1u, 13u);
    LCD_printString("PAUSED", 74, 58, 1, 3);
    LCD_Draw_Line(42, 86, 198, 86, 13u);
    LCD_printString(selected_option == 0u ? "> Resume Mission" : "  Resume Mission", 44, 106, selected_option == 0u ? 3u : 13u, 1);
    LCD_printString(selected_option == 1u ? "> Restart Mission" : "  Restart Mission", 44, 130, selected_option == 1u ? 6u : 13u, 1);
    LCD_printString(selected_option == 2u ? "> Exit to Menu" : "  Exit to Menu", 44, 154, selected_option == 2u ? 2u : 13u, 1);
    LCD_printString("Joystick select   BT3 confirm", 26, 178, 13u, 1);
    LCD_Refresh(&cfg0);
}

void G1_UI_RenderResult(const G1_Ship* ship, const G1_World* world, G1_GameOverReason reason, uint8_t selected_option, uint16_t session_best, char grade)
{
    char line[40];
    const char* reason_text = "Reason: HULL FAILURE";

    if (reason == G1_GAMEOVER_OXYGEN) {
        reason_text = "Reason: OXYGEN EMPTY";
    } else if (reason == G1_GAMEOVER_CLEAR) {
        reason_text = "Reason: MISSION CLEAR";
    }

    LCD_Fill_Buffer(0);
    g1_draw_panel(12, 14, 216, 172, 1u, 13u);
    g1_draw_panel(12, 192, 216, 34, 13u, 1u);
    LCD_printString(reason == G1_GAMEOVER_CLEAR ? "MISSION CLEAR" : "MISSION END", 34, 28, reason == G1_GAMEOVER_CLEAR ? 3u : 1u, 3u);
    LCD_printString((char*)reason_text, 28, 54, reason == G1_GAMEOVER_CLEAR ? 3u : 2u, 1u);
    LCD_Draw_Line(28, 74, 210, 74, 13u);

    snprintf(line, sizeof(line), "Score : %u", ship->score);
    LCD_printString(line, 26, 86, 1, 2);
    snprintf(line, sizeof(line), "Best  : %u", session_best);
    LCD_printString(line, 26, 104, 6, 2);
    snprintf(line, sizeof(line), "Dock  : %u/%u", world->docked_total, world->mission_target_docks);
    LCD_printString(line, 26, 122, 3, 2);
    snprintf(line, sizeof(line), "Crash : %u", world->crash_count);
    LCD_printString(line, 26, 140, 2, 2);
    snprintf(line, sizeof(line), "Precision : %u", world->precision_docks);
    LCD_printString(line, 26, 158, 11u, 1u);
    snprintf(line, sizeof(line), "Rank %c", grade);
    LCD_printString(line, 158, 156, grade == 'S' ? 14u : (grade == 'A' ? 3u : 13u), 2u);

    LCD_printString(selected_option == 0u ? "> Retry Mission" : "  Retry Mission", 34, 200, selected_option == 0u ? 3u : 13u, 1);
    LCD_printString(selected_option == 1u ? "> Return Menu" : "  Return Menu", 128, 200, selected_option == 1u ? 6u : 13u, 1);
    LCD_Refresh(&cfg0);
}

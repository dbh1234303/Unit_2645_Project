#include "Game_1.h"
#include "G1_Types.h"
#include "G1_Physics.h"
#include "G1_World.h"
#include "G1_UI.h"
#include "G1_Scoring.h"
#include "G1_Audio.h"
#include "InputHandler.h"
#include "Joystick.h"
#include "LCD.h"
#include "PWM.h"
#include "stm32l4xx_hal.h"
#include <string.h>

extern PWM_cfg_t pwm_cfg;
extern Joystick_cfg_t joystick_cfg;
extern Joystick_t joystick_data;

typedef enum {
    G1_STATE_TITLE = 0,
    G1_STATE_TUTORIAL,
    G1_STATE_PLAYING,
    G1_STATE_PAUSED,
    G1_STATE_RESULT
} G1_State;

typedef struct {
    G1_State state;
    G1_Difficulty difficulty;
    G1_GameOverReason reason;
    G1_Ship ship;
    G1_World world;
    G1_AudioState audio;
    uint8_t title_selection;
    uint8_t pause_selection;
    uint8_t result_selection;
    uint32_t elapsed_ms;
    uint32_t oxygen_accum;
    uint16_t led_blink_ms;
    uint16_t session_best_score;
} G1_Context;

#define G1_FRAME_TIME_MS 33u

static void g1_reset_run(G1_Context* ctx)
{
    G1_Physics_ResetShip(&ctx->ship, ctx->difficulty);
    G1_World_Seed(HAL_GetTick() + ((uint32_t)ctx->difficulty * 97u));
    G1_World_Init(&ctx->world, ctx->difficulty);
    ctx->elapsed_ms = 0u;
    ctx->oxygen_accum = 0u;
    ctx->pause_selection = 0u;
    ctx->result_selection = 0u;
    ctx->reason = G1_GAMEOVER_NONE;
    ctx->led_blink_ms = 0u;
    G1_Audio_Init(&ctx->audio);
    G1_Audio_PlayStart(&ctx->audio);
    PWM_SetDuty(&pwm_cfg, 0u);
}

static void g1_stop_outputs(G1_Context* ctx)
{
    G1_Audio_Stop(&ctx->audio);
    PWM_SetDuty(&pwm_cfg, 0u);
}

static void g1_tick_timers(G1_Context* ctx)
{
    if (ctx->ship.invuln_ms > G1_FRAME_TIME_MS) ctx->ship.invuln_ms = (uint16_t)(ctx->ship.invuln_ms - G1_FRAME_TIME_MS);
    else ctx->ship.invuln_ms = 0u;

    if (ctx->ship.shield_ms > G1_FRAME_TIME_MS) ctx->ship.shield_ms = (uint16_t)(ctx->ship.shield_ms - G1_FRAME_TIME_MS);
    else ctx->ship.shield_ms = 0u;

    if (ctx->ship.shield_cooldown_ms > G1_FRAME_TIME_MS) ctx->ship.shield_cooldown_ms = (uint16_t)(ctx->ship.shield_cooldown_ms - G1_FRAME_TIME_MS);
    else ctx->ship.shield_cooldown_ms = 0u;
}

static void g1_update_oxygen(G1_Context* ctx)
{
    uint16_t drain_per_second = (ctx->difficulty == G1_DIFFICULTY_EXTREME) ? 20u : 14u;
    if (ctx->ship.carrying) {
        drain_per_second = (uint16_t)(drain_per_second + 4u);
    }
    ctx->oxygen_accum += drain_per_second * G1_FRAME_TIME_MS;
    while (ctx->oxygen_accum >= 1000u) {
        ctx->oxygen_accum -= 1000u;
        if (ctx->ship.oxygen > 0u) {
            ctx->ship.oxygen--;
        }
    }
}

static void g1_update_led(G1_Context* ctx)
{
    uint8_t duty = 0u;
    if (ctx->ship.oxygen < 220u) {
        ctx->led_blink_ms = (uint16_t)(ctx->led_blink_ms + G1_FRAME_TIME_MS);
        duty = ((ctx->led_blink_ms / 200u) % 2u == 0u) ? 100u : 0u;
    } else if (ctx->ship.shield_ms) {
        duty = 70u;
    } else if (ctx->world.dock_streak >= 2u) {
        duty = (uint8_t)(30u + ctx->world.dock_streak * 10u);
        if (duty > 90u) duty = 90u;
    } else if (ctx->ship.carrying) {
        duty = 35u;
    }
    PWM_SetDuty(&pwm_cfg, duty);
}

static void g1_finalize_run(G1_Context* ctx, G1_GameOverReason reason)
{
    ctx->reason = reason;
    ctx->state = G1_STATE_RESULT;
    ctx->result_selection = 0u;
    if (ctx->ship.score > ctx->session_best_score) {
        ctx->session_best_score = ctx->ship.score;
    }
    if (reason == G1_GAMEOVER_CLEAR) {
        G1_Audio_PlayClear(&ctx->audio);
    } else {
        g1_stop_outputs(ctx);
    }
}

static G1_Difficulty g1_title_preview(uint8_t selection)
{
    return (selection == 1u) ? G1_DIFFICULTY_EXTREME : G1_DIFFICULTY_NORMAL;
}

static void g1_handle_title(G1_Context* ctx, Direction direction, Direction* last_direction, MenuState* exit_state)
{
    if (direction == N && *last_direction != N) {
        if (ctx->title_selection == 0u) ctx->title_selection = 3u;
        else ctx->title_selection--;
    } else if (direction == S && *last_direction != S) {
        ctx->title_selection = (uint8_t)((ctx->title_selection + 1u) % 4u);
    }
    *last_direction = direction;
    ctx->difficulty = g1_title_preview(ctx->title_selection);

    if (current_input.btn3_pressed) {
        if (ctx->title_selection == 0u || ctx->title_selection == 1u) {
            ctx->difficulty = g1_title_preview(ctx->title_selection);
            g1_reset_run(ctx);
            ctx->state = G1_STATE_PLAYING;
        } else if (ctx->title_selection == 2u) {
            ctx->state = G1_STATE_TUTORIAL;
        } else {
            *exit_state = MENU_STATE_HOME;
            ctx->reason = G1_GAMEOVER_NONE;
            ctx->state = G1_STATE_RESULT;
        }
        *last_direction = CENTRE;
    }
}

static void g1_handle_pause(G1_Context* ctx, Direction direction, Direction* last_direction, MenuState* exit_state)
{
    if (direction == N && *last_direction != N) {
        if (ctx->pause_selection == 0u) ctx->pause_selection = 2u;
        else ctx->pause_selection--;
    } else if (direction == S && *last_direction != S) {
        ctx->pause_selection = (uint8_t)((ctx->pause_selection + 1u) % 3u);
    }
    *last_direction = direction;

    if (current_input.btn3_pressed) {
        if (ctx->pause_selection == 0u) {
            ctx->state = G1_STATE_PLAYING;
        } else if (ctx->pause_selection == 1u) {
            g1_reset_run(ctx);
            ctx->state = G1_STATE_PLAYING;
        } else {
            *exit_state = MENU_STATE_HOME;
            ctx->reason = G1_GAMEOVER_NONE;
            ctx->state = G1_STATE_RESULT;
        }
        *last_direction = CENTRE;
    }
}

static void g1_handle_result(G1_Context* ctx, Direction direction, Direction* last_direction, MenuState* exit_state)
{
    if (ctx->reason == G1_GAMEOVER_NONE) {
        *exit_state = MENU_STATE_HOME;
        return;
    }

    if ((direction == N && *last_direction != N) || (direction == S && *last_direction != S)) {
        ctx->result_selection = (uint8_t)((ctx->result_selection + 1u) % 2u);
    }
    *last_direction = direction;

    if (current_input.btn3_pressed) {
        if (ctx->result_selection == 0u) {
            g1_reset_run(ctx);
            ctx->state = G1_STATE_PLAYING;
        } else {
            *exit_state = MENU_STATE_HOME;
        }
        *last_direction = CENTRE;
    }
}

static void g1_handle_playing(G1_Context* ctx, Direction direction)
{
    uint8_t events;
    float hit_x = 0.0f;
    float hit_y = 0.0f;
    uint8_t precision_dock;

    if (current_input.btn3_pressed) {
        ctx->state = G1_STATE_PAUSED;
        ctx->pause_selection = 0u;
        G1_Audio_Stop(&ctx->audio);
        return;
    }

    if (current_input.btn2_pressed && ctx->ship.shield_cooldown_ms == 0u) {
        ctx->ship.shield_ms = 1200u;
        ctx->ship.shield_cooldown_ms = 5000u;
        G1_Audio_PlayShield(&ctx->audio);
    }

    g1_tick_timers(ctx);
    G1_Physics_UpdateShip(&ctx->ship, direction, 0.033f);
    G1_Physics_KeepInBounds(&ctx->ship);
    G1_World_Update(&ctx->world, &ctx->ship, 0.033f);
    g1_update_oxygen(ctx);

    precision_dock = G1_Physics_IsPrecisionDock(&ctx->ship);
    events = G1_World_HandlePickups(&ctx->world, &ctx->ship, precision_dock);

    if (events & G1_EVENT_RESCUE) {
        ctx->ship.score = (uint16_t)(ctx->ship.score + G1_Scoring_RescueBonus(&ctx->world));
        G1_Audio_PlayRescue(&ctx->audio);
    }
    if (events & G1_EVENT_OXYGEN) {
        G1_Audio_PlaySupply(&ctx->audio);
    }
    if (events & G1_EVENT_DOCK) {
        ctx->ship.score = (uint16_t)(ctx->ship.score + G1_Scoring_DockBonus(&ctx->world, &ctx->ship, (events & G1_EVENT_PRECISION) ? 1u : 0u));
        if (events & G1_EVENT_PRECISION) {
            G1_Audio_PlayPrecision(&ctx->audio);
        } else {
            G1_Audio_PlayDock(&ctx->audio);
        }
    }

    if (ctx->ship.shield_ms == 0u && ctx->ship.invuln_ms == 0u && G1_World_CheckHazardHit(&ctx->world, &ctx->ship, &hit_x, &hit_y)) {
        if (ctx->ship.health > 0u) {
            ctx->ship.health--;
        }
        ctx->ship.invuln_ms = 1200u;
        G1_Physics_ApplyCollisionKick(&ctx->ship, hit_x, hit_y);
        G1_Scoring_OnCrash(&ctx->world, &ctx->ship);
        G1_Audio_PlayCrash(&ctx->audio);
    }

    if (ctx->ship.oxygen < 170u && ctx->audio.low_o2_cooldown_ms == 0u) {
        G1_Audio_PlayWarning(&ctx->audio);
    }

    ctx->elapsed_ms += G1_FRAME_TIME_MS;
    g1_update_led(ctx);

    if (events & G1_EVENT_CLEAR) {
        ctx->ship.score = (uint16_t)(ctx->ship.score + 200u + (ctx->ship.oxygen / 8u));
        g1_finalize_run(ctx, G1_GAMEOVER_CLEAR);
    } else if (ctx->ship.oxygen == 0u) {
        g1_finalize_run(ctx, G1_GAMEOVER_OXYGEN);
    } else if (ctx->ship.health == 0u) {
        g1_finalize_run(ctx, G1_GAMEOVER_HULL);
    }
}

MenuState Game1_Run(void)
{
    G1_Context ctx;
    MenuState exit_state = MENU_STATE_HOME;
    Direction last_direction = CENTRE;

    memset(&ctx, 0, sizeof(ctx));
    ctx.state = G1_STATE_TITLE;
    ctx.title_selection = 0u;
    ctx.difficulty = G1_DIFFICULTY_NORMAL;
    G1_Audio_Init(&ctx.audio);

    while (1) {
        uint32_t frame_start = HAL_GetTick();

        Input_Read();
        Joystick_Read(&joystick_cfg, &joystick_data);

        switch (ctx.state) {
            case G1_STATE_TITLE:
                g1_handle_title(&ctx, joystick_data.direction, &last_direction, &exit_state);
                if (ctx.reason == G1_GAMEOVER_NONE && ctx.state == G1_STATE_RESULT) {
                    g1_stop_outputs(&ctx);
                    return exit_state;
                }
                G1_UI_RenderTitle(ctx.title_selection, g1_title_preview(ctx.title_selection), ctx.session_best_score, (uint8_t)(((HAL_GetTick() / 250u) % 2u) == 0u));
                break;

            case G1_STATE_TUTORIAL:
                if (current_input.btn2_pressed || current_input.btn3_pressed) {
                    ctx.state = G1_STATE_TITLE;
                    last_direction = CENTRE;
                }
                G1_UI_RenderTutorial((uint8_t)(((HAL_GetTick() / 250u) % 2u) == 0u));
                break;

            case G1_STATE_PLAYING:
                g1_handle_playing(&ctx, joystick_data.direction);
                if (ctx.state == G1_STATE_PLAYING) {
                    G1_UI_RenderGameplay(&ctx.ship, &ctx.world, ctx.elapsed_ms);
                }
                break;

            case G1_STATE_PAUSED:
                g1_handle_pause(&ctx, joystick_data.direction, &last_direction, &exit_state);
                if (ctx.reason == G1_GAMEOVER_NONE && ctx.state == G1_STATE_RESULT) {
                    g1_stop_outputs(&ctx);
                    return exit_state;
                }
                G1_UI_RenderPause(ctx.pause_selection);
                break;

            case G1_STATE_RESULT:
            default:
                g1_handle_result(&ctx, joystick_data.direction, &last_direction, &exit_state);
                if (ctx.reason == G1_GAMEOVER_NONE) {
                    g1_stop_outputs(&ctx);
                    return exit_state;
                }
                G1_UI_RenderResult(&ctx.ship, &ctx.world, ctx.reason, ctx.result_selection, ctx.session_best_score, G1_Scoring_Grade(&ctx.world, &ctx.ship, ctx.reason));
                break;
        }

        G1_Audio_Tick(&ctx.audio, G1_FRAME_TIME_MS);

        {
            uint32_t frame_time = HAL_GetTick() - frame_start;
            if (frame_time < G1_FRAME_TIME_MS) {
                HAL_Delay(G1_FRAME_TIME_MS - frame_time);
            }
        }
    }
}

#ifndef G1_UI_H
#define G1_UI_H

#include <stdint.h>
#include "G1_Types.h"

void G1_UI_RenderTitle(uint8_t selected_option, G1_Difficulty preview_difficulty, uint16_t session_best, uint8_t blink_on);
void G1_UI_RenderTutorial(uint8_t blink_on);
void G1_UI_RenderGameplay(const G1_Ship* ship, const G1_World* world, uint32_t elapsed_ms);
void G1_UI_RenderPause(uint8_t selected_option);
void G1_UI_RenderResult(const G1_Ship* ship, const G1_World* world, G1_GameOverReason reason, uint8_t selected_option, uint16_t session_best, char grade);

#endif

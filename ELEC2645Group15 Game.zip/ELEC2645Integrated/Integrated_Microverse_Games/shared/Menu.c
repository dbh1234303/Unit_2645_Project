#include "Menu.h"
#include "LCD.h"
#include "InputHandler.h"
#include "Joystick.h"
#include "stm32l4xx_hal.h"
#include <stdio.h>

extern ST7789V2_cfg_t cfg0;  // LCD configuration from main.c
extern Joystick_cfg_t joystick_cfg;  // Joystick configuration
extern Joystick_t joystick_data;     // Current joystick readings

// Menu options
static const char* menu_options[] = {
    "Zero-G Rescue",
    "Pulse Track",
    "Magnetic Maze"
};
#define NUM_MENU_OPTIONS 3

// Frame rate for menu (in milliseconds)
#define MENU_FRAME_TIME_MS 30  // ~33 FPS

#define MENU_SCREEN_W 240
#define MENU_SCREEN_H 240
#define MENU_CARD_X   18
#define MENU_CARD_W   204
#define MENU_CARD_H   37
#define MENU_CARD_GAP 12
#define MENU_CARD_Y0  84

typedef struct {
    const char* subtitle;
    const char* tag;
    uint8_t accent;
} MenuOptionMeta;

static const MenuOptionMeta menu_meta[NUM_MENU_OPTIONS] = {
    {"Zero gravity survival", "ACTION", 14},
    {"Beat timing challenge", "MUSIC", 10},
    {"Magnetic path puzzle",  "PUZZLE", 11}
};

static void draw_safe_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t colour, uint8_t fill) {
    if (x >= MENU_SCREEN_W || y >= MENU_SCREEN_H || w == 0 || h == 0) {
        return;
    }
    if (x + w > MENU_SCREEN_W) {
        w = MENU_SCREEN_W - x;
    }
    if (y + h > MENU_SCREEN_H) {
        h = MENU_SCREEN_H - y;
    }
    LCD_Draw_Rect(x, y, w, h, colour, fill);
}

static void draw_scanline_background(uint32_t tick) {
    // Deep space base colour with subtle animated grid / particles.
    LCD_Fill_Buffer(9);

    for (uint16_t y = 0; y < MENU_SCREEN_H; y += 16) {
        LCD_Draw_Line(0, y, MENU_SCREEN_W - 1, y, 8);
    }
    for (uint16_t x = 0; x < MENU_SCREEN_W; x += 24) {
        LCD_Draw_Line(x, 0, x, MENU_SCREEN_H - 1, 0);
    }

    for (uint8_t i = 0; i < 20; i++) {
        uint16_t x = (uint16_t)((i * 37 + (tick / 45)) % MENU_SCREEN_W);
        uint16_t y = (uint16_t)((i * 53 + 14) % MENU_SCREEN_H);
        uint8_t colour = (i % 3 == 0) ? 14 : ((i % 3 == 1) ? 10 : 13);
        LCD_Set_Pixel(x, y, colour);
        if ((i % 4) == 0 && x + 1 < MENU_SCREEN_W) {
            LCD_Set_Pixel(x + 1, y, colour);
        }
    }

    // Header and footer panels.
    draw_safe_rect(0, 0, MENU_SCREEN_W, 54, 0, 1);
    draw_safe_rect(0, 54, MENU_SCREEN_W, 2, 14, 1);
    draw_safe_rect(0, 212, MENU_SCREEN_W, 28, 0, 1);
    draw_safe_rect(0, 212, MENU_SCREEN_W, 2, 8, 1);
}

static void draw_title(uint32_t tick) {
    uint8_t pulse = ((tick / 260) % 2) ? 10 : 14;

    LCD_printString("MICROVERSE", 27, 8, 1, 3);
    LCD_printString("GAME HUB", 69, 36, pulse, 1);

    // Small animated orbit decoration around the title.
    uint16_t orbit_x = 180 + (uint16_t)((tick / 120) % 26);
    LCD_Draw_Circle(orbit_x, 39, 3, pulse, 0);
    LCD_Set_Pixel(orbit_x, 39, 1);

    LCD_printString("SELECT A GAME", 66, 62, 13, 1);
}

static void draw_card_icon(uint16_t x, uint16_t y, uint8_t index, uint8_t accent) {
    draw_safe_rect(x, y, 28, 28, accent, 1);
    draw_safe_rect(x + 2, y + 2, 24, 24, 0, 0);

    if (index == 0) {
        LCD_Draw_Circle(x + 14, y + 13, 7, 1, 0);
        LCD_Draw_Line(x + 7, y + 21, x + 21, y + 21, 1);
        LCD_Draw_Line(x + 14, y + 5, x + 14, y + 21, 1);
    } else if (index == 1) {
        LCD_Draw_Line(x + 7, y + 20, x + 7, y + 8, 1);
        LCD_Draw_Line(x + 14, y + 22, x + 14, y + 5, 1);
        LCD_Draw_Line(x + 21, y + 20, x + 21, y + 11, 1);
        LCD_Draw_Circle(x + 7, y + 21, 3, 1, 1);
        LCD_Draw_Circle(x + 14, y + 23, 3, 1, 1);
        LCD_Draw_Circle(x + 21, y + 21, 3, 1, 1);
    } else {
        LCD_Draw_Rect(x + 6, y + 6, 16, 16, 1, 0);
        LCD_Draw_Line(x + 6, y + 14, x + 22, y + 14, 1);
        LCD_Draw_Line(x + 14, y + 6, x + 14, y + 22, 1);
        LCD_Draw_Circle(x + 14, y + 14, 3, accent, 1);
    }
}

static void draw_menu_card(MenuSystem* menu, uint8_t index, uint32_t tick) {
    uint16_t y = MENU_CARD_Y0 + (index * (MENU_CARD_H + MENU_CARD_GAP));
    uint8_t selected = (index == menu->selected_option);
    uint8_t accent = menu_meta[index].accent;
    uint8_t blink = ((tick / 180) % 2) ? 1 : accent;

    if (selected) {
        // Outer glow / focus frame.
        draw_safe_rect(MENU_CARD_X - 4, y - 4, MENU_CARD_W + 8, MENU_CARD_H + 8, accent, 0);
        draw_safe_rect(MENU_CARD_X - 2, y - 2, MENU_CARD_W + 4, MENU_CARD_H + 4, blink, 0);
        draw_safe_rect(MENU_CARD_X, y, MENU_CARD_W, MENU_CARD_H, 13, 1);
        draw_safe_rect(MENU_CARD_X, y, 5, MENU_CARD_H, accent, 1);
        LCD_printString(">", 7, y + 10, blink, 2);
    } else {
        draw_safe_rect(MENU_CARD_X, y, MENU_CARD_W, MENU_CARD_H, 0, 1);
        draw_safe_rect(MENU_CARD_X, y, MENU_CARD_W, MENU_CARD_H, 8, 0);
        draw_safe_rect(MENU_CARD_X, y, 3, MENU_CARD_H, 8, 1);
    }

    draw_card_icon(MENU_CARD_X + 10, y + 5, index, selected ? accent : 8);

    LCD_printString((char*)menu_options[index], MENU_CARD_X + 46, y + 6, selected ? 1 : 13, 1);
    LCD_printString((char*)menu_meta[index].subtitle, MENU_CARD_X + 46, y + 20, selected ? 0 : 13, 1);

    draw_safe_rect(MENU_CARD_X + 154, y + 8, 44, 13, selected ? accent : 8, selected ? 1 : 0);
    LCD_printString((char*)menu_meta[index].tag, MENU_CARD_X + 158, y + 11, selected ? 0 : 13, 1);
}

static void draw_bottom_hint(MenuSystem* menu) {
    char page_text[20];
    snprintf(page_text, sizeof(page_text), "%d/%d", menu->selected_option + 1, NUM_MENU_OPTIONS);

    LCD_printString("UP/DOWN", 12, 219, 14, 1);
    LCD_printString("MOVE", 66, 219, 1, 1);
    LCD_printString("BTN3", 116, 219, 10, 1);
    LCD_printString("START", 153, 219, 1, 1);
    LCD_printString(page_text, 210, 219, 13, 1);

    for (uint8_t i = 0; i < NUM_MENU_OPTIONS; i++) {
        uint16_t x = 104 + i * 12;
        LCD_Draw_Circle(x, 204, 3, (i == menu->selected_option) ? menu_meta[i].accent : 13, (i == menu->selected_option));
    }
}

/**
 * @brief Render the home menu screen
 */
static void render_home_menu(MenuSystem* menu) {
    uint32_t tick = HAL_GetTick();

    draw_scanline_background(tick);
    draw_title(tick);

    for (uint8_t i = 0; i < NUM_MENU_OPTIONS; i++) {
        draw_menu_card(menu, i, tick);
    }

    draw_bottom_hint(menu);

    LCD_Refresh(&cfg0);
}

// ==============================================
// PUBLIC API IMPLEMENTATION
// ==============================================

void Menu_Init(MenuSystem* menu) {
    menu->selected_option = 0;
}

MenuState Menu_Run(MenuSystem* menu) {
    static Direction last_direction = CENTRE;  // Track last direction for debouncing
    MenuState selected_game = MENU_STATE_HOME;  // Which game was selected

    // Menu's own loop - runs until game is selected
    while (1) {
        uint32_t frame_start = HAL_GetTick();

        // Read input
        Input_Read();

        // Read current joystick position
        Joystick_Read(&joystick_cfg, &joystick_data);

        // Handle joystick navigation (up/down to select option)
        Direction current_direction = joystick_data.direction;

        if (current_direction == S && last_direction != S) {  // Joystick pushed DOWN
            // Move selection down
            menu->selected_option++;
            if (menu->selected_option >= NUM_MENU_OPTIONS) {
                menu->selected_option = 0;  // Wrap around
            }
        }
        else if (current_direction == N && last_direction != N) {  // Joystick pushed UP
            // Move selection up
            if (menu->selected_option == 0) {
                menu->selected_option = NUM_MENU_OPTIONS - 1;  // Wrap around
            } else {
                menu->selected_option--;
            }
        }

        last_direction = current_direction;

        // Handle button press to select current option
        if (current_input.btn3_pressed) {
            // User pressed button - select the highlighted option
            if (menu->selected_option == 0) {
                selected_game = MENU_STATE_GAME_1;
            } else if (menu->selected_option == 1) {
                selected_game = MENU_STATE_GAME_2;
            } else if (menu->selected_option == 2) {
                selected_game = MENU_STATE_GAME_3;
            }
            break;  // Exit menu loop - game selected!
        }

        // Render menu
        render_home_menu(menu);

        // Frame timing - wait for remainder of frame time
        uint32_t frame_time = HAL_GetTick() - frame_start;
        if (frame_time < MENU_FRAME_TIME_MS) {
            HAL_Delay(MENU_FRAME_TIME_MS - frame_time);
        }
    }

    return selected_game;  // Return which game was selected
}

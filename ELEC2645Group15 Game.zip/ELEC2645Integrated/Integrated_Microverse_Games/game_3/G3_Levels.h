#ifndef G3_LEVELS_H
#define G3_LEVELS_H

#include "G3_Types.h"

const G3_LevelDef *G3_Levels_Get(uint8_t index);
uint8_t G3_Levels_Count(void);

#endif

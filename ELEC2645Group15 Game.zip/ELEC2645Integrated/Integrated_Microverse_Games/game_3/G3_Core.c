#include "G3_Core.h"
#include "G3_Levels.h"
#include "stm32l4xx_hal.h"
#include <stddef.h>
#include <stdio.h>
#include <string.h>

static uint8_t g3_in_bounds(const G3_GameState *state, int16_t x, int16_t y)
{
    return (x >= 0 && y >= 0 && x < state->width && y < state->height) ? 1u : 0u;
}

static void g3_set_hint(G3_GameState *state, const char *text)
{
    snprintf(state->hint, sizeof(state->hint), "%s", text);
}

static int8_t g3_find_box_at(const G3_GameState *state, int16_t x, int16_t y)
{
    uint8_t i;
    for (i = 0; i < state->box_count; ++i) {
        if (state->boxes[i].x == x && state->boxes[i].y == y) {
            return (int8_t)i;
        }
    }
    return -1;
}

static void g3_save_undo(G3_GameState *state)
{
    uint8_t i;

    state->undo.valid = 1u;
    state->undo.player = state->player;
    state->undo.box_count = state->box_count;
    for (i = 0; i < G3_MAX_BOXES; ++i) {
        state->undo.boxes[i] = state->boxes[i];
    }
    state->undo.polarity = state->polarity;
    state->undo.gate_open = state->gate_open;
    state->undo.steps = state->steps;
    state->undo.result = state->result;
}

uint8_t G3_Core_CanUndo(const G3_GameState *state)
{
    if (state == NULL) {
        return 0u;
    }
    return (state->undo.valid && state->result == G3_RESULT_NONE) ? 1u : 0u;
}

G3_Event G3_Core_Undo(G3_GameState *state)
{
    uint8_t i;

    if (!G3_Core_CanUndo(state)) {
        if (state != NULL) {
            g3_set_hint(state, "Nothing to undo yet.");
        }
        return G3_EVENT_BLOCKED;
    }

    state->player = state->undo.player;
    state->box_count = state->undo.box_count;
    for (i = 0; i < G3_MAX_BOXES; ++i) {
        state->boxes[i] = state->undo.boxes[i];
    }
    state->polarity = state->undo.polarity;
    state->gate_open = state->undo.gate_open;
    state->steps = state->undo.steps;
    state->result = state->undo.result;
    state->undo.valid = 0u;
    g3_set_hint(state, "Undo restored the previous move.");
    return G3_EVENT_UNDO;
}

static uint8_t g3_switch_has_box(const G3_GameState *state, int16_t x, int16_t y)
{
    return g3_find_box_at(state, x, y) >= 0 ? 1u : 0u;
}

uint8_t G3_Core_IsBoxOnSwitch(const G3_GameState *state, uint8_t switch_index)
{
    if (switch_index >= state->switch_count) {
        return 0;
    }
    return g3_switch_has_box(state, state->switches[switch_index].x, state->switches[switch_index].y);
}

static uint8_t g3_is_gate_open(const G3_GameState *state)
{
    uint8_t i;
    if (state->switch_count == 0) {
        return 1;
    }
    for (i = 0; i < state->switch_count; ++i) {
        if (!G3_Core_IsBoxOnSwitch(state, i)) {
            return 0;
        }
    }
    return 1;
}

static void g3_update_gate_state(G3_GameState *state)
{
    state->gate_open = g3_is_gate_open(state);
}

static uint8_t g3_tile_blocks_player(const G3_GameState *state, int16_t x, int16_t y)
{
    G3_Tile tile;

    if (!g3_in_bounds(state, x, y)) {
        return 1;
    }
    tile = state->tiles[y][x];
    if (tile == G3_TILE_WALL) {
        return 1;
    }
    if (tile == G3_TILE_GATE && !state->gate_open) {
        return 1;
    }
    return 0;
}

static uint8_t g3_tile_blocks_box(const G3_GameState *state, int16_t x, int16_t y)
{
    G3_Tile tile;

    if (!g3_in_bounds(state, x, y)) {
        return 1;
    }
    tile = state->tiles[y][x];
    if (tile == G3_TILE_WALL || tile == G3_TILE_EXIT) {
        return 1;
    }
    if (tile == G3_TILE_GATE) {
        return 1;
    }
    return 0;
}

static uint8_t g3_box_can_move_to(const G3_GameState *state, int16_t box_index, int16_t x, int16_t y)
{
    uint8_t i;
    if (g3_tile_blocks_box(state, x, y)) {
        return 0;
    }
    for (i = 0; i < state->box_count; ++i) {
        if ((int16_t)i == box_index) {
            continue;
        }
        if (state->boxes[i].x == x && state->boxes[i].y == y) {
            return 0;
        }
    }
    if (state->player.x == x && state->player.y == y) {
        return 0;
    }
    return 1;
}

static void g3_resolve_result(G3_GameState *state)
{
    uint8_t i;

    for (i = 0; i < state->box_count; ++i) {
        if (state->tiles[state->boxes[i].y][state->boxes[i].x] == G3_TILE_TRAP) {
            state->result = G3_RESULT_FAIL;
            g3_set_hint(state, "The energy box fell into a trap.");
            return;
        }
    }

    if (state->tiles[state->player.y][state->player.x] == G3_TILE_TRAP) {
        state->result = G3_RESULT_FAIL;
        g3_set_hint(state, "Trap triggered. Restart the level.");
        return;
    }

    if (state->tiles[state->player.y][state->player.x] == G3_TILE_EXIT) {
        state->result = G3_RESULT_WIN;
        g3_set_hint(state, "Exit reached. Level cleared.");
    }
}

void G3_Core_LoadLevel(G3_GameState *state, uint8_t level_index)
{
    const G3_LevelDef *level;
    uint8_t x;
    uint8_t y;

    memset(state, 0, sizeof(*state));
    level = G3_Levels_Get(level_index);
    if (level == NULL) {
        return;
    }

    state->level_def = level;
    state->level_index = level_index;
    state->width = level->width;
    state->height = level->height;
    state->polarity = G3_POLARITY_NORTH;
    state->level_start_tick = HAL_GetTick();
    g3_set_hint(state, "BTN3 toggles N/S. Pause has Undo.");

    for (y = 0; y < level->height; ++y) {
        for (x = 0; x < level->width; ++x) {
            char symbol = level->rows[y][x];
            switch (symbol) {
                case '#':
                    state->tiles[y][x] = G3_TILE_WALL;
                    break;
                case 'M':
                    state->tiles[y][x] = G3_TILE_SWITCH;
                    if (state->switch_count < G3_MAX_SWITCHES) {
                        state->switches[state->switch_count].x = (int8_t)x;
                        state->switches[state->switch_count].y = (int8_t)y;
                        state->switch_count++;
                    }
                    break;
                case 'G':
                    state->tiles[y][x] = G3_TILE_GATE;
                    break;
                case 'E':
                    state->tiles[y][x] = G3_TILE_EXIT;
                    break;
                case 'T':
                    state->tiles[y][x] = G3_TILE_TRAP;
                    break;
                case 'P':
                    state->tiles[y][x] = G3_TILE_FLOOR;
                    state->player.x = (int8_t)x;
                    state->player.y = (int8_t)y;
                    break;
                case 'B':
                    state->tiles[y][x] = G3_TILE_FLOOR;
                    if (state->box_count < G3_MAX_BOXES) {
                        state->boxes[state->box_count].x = (int8_t)x;
                        state->boxes[state->box_count].y = (int8_t)y;
                        state->box_count++;
                    }
                    break;
                case '.':
                default:
                    state->tiles[y][x] = G3_TILE_FLOOR;
                    break;
            }
        }
    }

    g3_update_gate_state(state);
}

G3_Event G3_Core_MovePlayer(G3_GameState *state, int8_t dx, int8_t dy)
{
    int16_t next_x;
    int16_t next_y;
    int8_t box_index;
    uint8_t gate_before;
    G3_Event event;

    if (state->result != G3_RESULT_NONE || (dx == 0 && dy == 0)) {
        return G3_EVENT_NONE;
    }

    next_x = state->player.x + dx;
    next_y = state->player.y + dy;
    if (g3_tile_blocks_player(state, next_x, next_y)) {
        g3_set_hint(state, "Blocked by wall or closed gate.");
        return G3_EVENT_BLOCKED;
    }

    box_index = g3_find_box_at(state, next_x, next_y);
    if (box_index >= 0) {
        int16_t box_next_x = next_x + dx;
        int16_t box_next_y = next_y + dy;
        if (!g3_box_can_move_to(state, box_index, box_next_x, box_next_y)) {
            g3_set_hint(state, "No space to push the energy box.");
            return G3_EVENT_BLOCKED;
        }
        g3_save_undo(state);
        state->boxes[(uint8_t)box_index].x = (int8_t)box_next_x;
        state->boxes[(uint8_t)box_index].y = (int8_t)box_next_y;
        event = G3_EVENT_PUSH_BOX;
        g3_set_hint(state, "Box pushed forward.");
    } else {
        g3_save_undo(state);
        event = G3_EVENT_MOVE;
        g3_set_hint(state, "Move carefully through the tower.");
    }

    state->player.x = (int8_t)next_x;
    state->player.y = (int8_t)next_y;
    state->steps++;

    gate_before = state->gate_open;
    g3_update_gate_state(state);
    g3_resolve_result(state);

    if (state->result == G3_RESULT_WIN) {
        return G3_EVENT_WIN;
    }
    if (state->result == G3_RESULT_FAIL) {
        return G3_EVENT_FAIL;
    }
    if (!gate_before && state->gate_open) {
        g3_set_hint(state, "Gate unlocked. Path to exit opened.");
        return G3_EVENT_GATE_OPEN;
    }
    if (gate_before && !state->gate_open) {
        g3_set_hint(state, "Gate closed again.");
        return G3_EVENT_GATE_CLOSE;
    }
    return event;
}

G3_Event G3_Core_TogglePolarity(G3_GameState *state)
{
    static const int8_t dir_x[4] = {0, 1, 0, -1};
    static const int8_t dir_y[4] = {-1, 0, 1, 0};
    uint8_t d;
    uint8_t gate_before;

    if (state->result != G3_RESULT_NONE) {
        return G3_EVENT_NONE;
    }

    g3_save_undo(state);
    state->polarity = (state->polarity == G3_POLARITY_NORTH) ? G3_POLARITY_SOUTH : G3_POLARITY_NORTH;
    state->steps++;

    for (d = 0; d < 4; ++d) {
        int8_t distance;
        for (distance = 1; distance <= 3; ++distance) {
            int16_t box_x = state->player.x + dir_x[d] * distance;
            int16_t box_y = state->player.y + dir_y[d] * distance;
            int8_t box_index = g3_find_box_at(state, box_x, box_y);
            if (!g3_in_bounds(state, box_x, box_y) || g3_tile_blocks_player(state, box_x, box_y)) {
                break;
            }
            if (box_index >= 0) {
                int16_t target_x;
                int16_t target_y;
                G3_Event event;

                if (state->polarity == G3_POLARITY_NORTH) {
                    if (distance <= 1) {
                        break;
                    }
                    target_x = box_x - dir_x[d];
                    target_y = box_y - dir_y[d];
                    if (!g3_box_can_move_to(state, box_index, target_x, target_y)) {
                        break;
                    }
                    state->boxes[(uint8_t)box_index].x = (int8_t)target_x;
                    state->boxes[(uint8_t)box_index].y = (int8_t)target_y;
                    event = G3_EVENT_PULL_BOX;
                    g3_set_hint(state, "North polarity pulled the box closer.");
                } else {
                    target_x = box_x + dir_x[d];
                    target_y = box_y + dir_y[d];
                    if (!g3_box_can_move_to(state, box_index, target_x, target_y)) {
                        break;
                    }
                    state->boxes[(uint8_t)box_index].x = (int8_t)target_x;
                    state->boxes[(uint8_t)box_index].y = (int8_t)target_y;
                    event = G3_EVENT_REPEL_BOX;
                    g3_set_hint(state, "South polarity pushed the box away.");
                }

                gate_before = state->gate_open;
                g3_update_gate_state(state);
                g3_resolve_result(state);
                if (state->result == G3_RESULT_FAIL) {
                    return G3_EVENT_FAIL;
                }
                if (!gate_before && state->gate_open) {
                    g3_set_hint(state, "Gate unlocked. Path to exit opened.");
                    return G3_EVENT_GATE_OPEN;
                }
                if (gate_before && !state->gate_open) {
                    g3_set_hint(state, "Gate closed again.");
                    return G3_EVENT_GATE_CLOSE;
                }
                return event;
            }
        }
    }

    if (state->polarity == G3_POLARITY_NORTH) {
        g3_set_hint(state, "North selected: pull boxes at range 2-3.");
    } else {
        g3_set_hint(state, "South selected: push boxes away.");
    }
    g3_update_gate_state(state);
    return G3_EVENT_TOGGLE_ONLY;
}

void G3_Core_Pause(G3_GameState *state)
{
    if (!state->paused) {
        state->paused = 1;
        state->pause_start_tick = HAL_GetTick();
    }
}

void G3_Core_Resume(G3_GameState *state)
{
    if (state->paused) {
        state->paused = 0;
        state->paused_accum_ms += (HAL_GetTick() - state->pause_start_tick);
    }
}

uint16_t G3_Core_GetElapsedSeconds(const G3_GameState *state)
{
    uint32_t now = state->paused ? state->pause_start_tick : HAL_GetTick();
    uint32_t elapsed_ms = now - state->level_start_tick;
    if (elapsed_ms > state->paused_accum_ms) {
        elapsed_ms -= state->paused_accum_ms;
    } else {
        elapsed_ms = 0;
    }
    return (uint16_t)(elapsed_ms / 1000u);
}

uint8_t G3_Core_ComputeStars(const G3_GameState *state)
{
    uint8_t stars = 0;
    uint16_t elapsed = G3_Core_GetElapsedSeconds(state);

    if (state->result != G3_RESULT_WIN || state->level_def == NULL) {
        return 0;
    }

    stars = 1;
    if (state->steps <= state->level_def->par_steps) {
        stars++;
    }
    if (elapsed <= state->level_def->par_time_s) {
        stars++;
    }
    return stars;
}

uint16_t G3_Core_ComputeScore(const G3_GameState *state)
{
    int32_t score;
    uint16_t elapsed;
    uint8_t stars;

    if (state->result != G3_RESULT_WIN || state->level_def == NULL) {
        return 0u;
    }

    elapsed = G3_Core_GetElapsedSeconds(state);
    stars = G3_Core_ComputeStars(state);
    score = 1000 + ((int32_t)stars * 150);

    if (state->steps <= state->level_def->par_steps) {
        score += 200 + ((int32_t)(state->level_def->par_steps - state->steps) * 10);
    } else {
        score -= ((int32_t)(state->steps - state->level_def->par_steps) * 8);
    }

    if (elapsed <= state->level_def->par_time_s) {
        score += 200 + ((int32_t)(state->level_def->par_time_s - elapsed) * 2);
    } else {
        score -= ((int32_t)(elapsed - state->level_def->par_time_s) * 3);
    }

    if (score < 100) {
        score = 100;
    }
    if (score > 9999) {
        score = 9999;
    }
    return (uint16_t)score;
}

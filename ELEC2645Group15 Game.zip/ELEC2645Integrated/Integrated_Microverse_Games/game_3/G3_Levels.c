#include "G3_Levels.h"

static const G3_LevelDef g3_levels[G3_LEVEL_COUNT] = {
    {
        .title = "Level 1",
        .subtitle = "Polarity Basics",
        .width = 10,
        .height = 5,
        .par_steps = 8,
        .par_time_s = 20,
        .rows = {
            "##########",
            "#P.BMGE..#",
            "#........#",
            "#........#",
            "##########"
        }
    },
    {
        .title = "Level 2",
        .subtitle = "Push the Box",
        .width = 10,
        .height = 7,
        .par_steps = 18,
        .par_time_s = 45,
        .rows = {
            "##########",
            "#P.......#",
            "#.###.##.#",
            "#.#B.MGE.#",
            "#.#....#.#",
            "#........#",
            "##########"
        }
    },
    {
        .title = "Level 3",
        .subtitle = "Cross Platforms",
        .width = 10,
        .height = 8,
        .par_steps = 28,
        .par_time_s = 70,
        .rows = {
            "##########",
            "#P..#...E#",
            "#.###.#G##",
            "#...#.#..#",
            "#.B.M.#..#",
            "#...T....#",
            "#........#",
            "##########"
        }
    },
    {
        .title = "Level 4",
        .subtitle = "Twin Relays",
        .width = 10,
        .height = 7,
        .par_steps = 34,
        .par_time_s = 85,
        .rows = {
            "##########",
            "#P.B.M...#",
            "#..###...#",
            "#..M.B...#",
            "#.....GE.#",
            "#........#",
            "##########"
        }
    },
    {
        .title = "Level 5",
        .subtitle = "Repel the Trap",
        .width = 10,
        .height = 6,
        .par_steps = 20,
        .par_time_s = 55,
        .rows = {
            "##########",
            "#P..B.MGE#",
            "#..T.....#",
            "#........#",
            "#........#",
            "##########"
        }
    },
    {
        .title = "Level 6",
        .subtitle = "Final Circuit",
        .width = 10,
        .height = 8,
        .par_steps = 44,
        .par_time_s = 110,
        .rows = {
            "##########",
            "#P..B.M..#",
            "#.##.##..#",
            "#..B.MG.E#",
            "#........#",
            "#..T.....#",
            "#........#",
            "##########"
        }
    }
};

const G3_LevelDef *G3_Levels_Get(uint8_t index)
{
    if (index >= G3_LEVEL_COUNT) {
        return 0;
    }
    return &g3_levels[index];
}

uint8_t G3_Levels_Count(void)
{
    return G3_LEVEL_COUNT;
}

#ifndef G3_RENDER_H
#define G3_RENDER_H

#include <stdint.h>
#include "G3_Types.h"

void G3_Render_LevelSelect(uint8_t selected_level, const G3_LevelProgress progress[G3_LEVEL_COUNT]);
void G3_Render_Game(const G3_GameState *state);
void G3_Render_Pause(const G3_GameState *state, uint8_t selected_option);
void G3_Render_Result(const G3_GameState *state, uint8_t selected_option, const G3_LevelProgress progress[G3_LEVEL_COUNT]);

#endif

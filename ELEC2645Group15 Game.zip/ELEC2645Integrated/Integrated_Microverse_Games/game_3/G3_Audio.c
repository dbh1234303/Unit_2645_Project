#include "G3_Audio.h"
#include "PWM.h"
#include "Buzzer.h"
#include "stm32l4xx_hal.h"

extern PWM_cfg_t pwm_cfg;
extern Buzzer_cfg_t buzzer_cfg;

typedef struct {
    uint32_t freq;
    uint8_t volume;
    uint16_t duration_ms;
} G3_AudioTone;

#define G3_AUDIO_MAX_TONES 4u

static G3_AudioTone g3_audio_queue[G3_AUDIO_MAX_TONES];
static uint8_t g3_audio_count = 0u;
static uint8_t g3_audio_index = 0u;
static uint8_t g3_audio_active = 0u;
static uint32_t g3_audio_tone_start = 0u;

static const G3_AudioTone g3_tones_enter[]      = {{988u, 28u, 35u}, {1319u, 28u, 35u}};
static const G3_AudioTone g3_tones_move[]       = {{740u, 12u, 8u}};
static const G3_AudioTone g3_tones_push[]       = {{523u, 22u, 25u}};
static const G3_AudioTone g3_tones_pull[]       = {{659u, 22u, 25u}};
static const G3_AudioTone g3_tones_repel[]      = {{392u, 22u, 25u}};
static const G3_AudioTone g3_tones_toggle[]     = {{880u, 20u, 18u}};
static const G3_AudioTone g3_tones_gate_open[]  = {{988u, 25u, 20u}, {1319u, 25u, 45u}};
static const G3_AudioTone g3_tones_gate_close[] = {{440u, 16u, 20u}};
static const G3_AudioTone g3_tones_undo[]       = {{880u, 18u, 20u}, {659u, 18u, 20u}};
static const G3_AudioTone g3_tones_win[]        = {{1047u, 30u, 35u}, {1319u, 30u, 35u}, {1568u, 30u, 65u}};
static const G3_AudioTone g3_tones_fail[]       = {{330u, 30u, 70u}};
static const G3_AudioTone g3_tones_blocked[]    = {{247u, 12u, 15u}};

static void g3_audio_start_current_tone(void)
{
    if (g3_audio_index >= g3_audio_count) {
        buzzer_off(&buzzer_cfg);
        g3_audio_active = 0u;
        return;
    }

    buzzer_tone(&buzzer_cfg, g3_audio_queue[g3_audio_index].freq, g3_audio_queue[g3_audio_index].volume);
    g3_audio_tone_start = HAL_GetTick();
    g3_audio_active = 1u;
}

static void g3_audio_queue_sequence(const G3_AudioTone *tones, uint8_t count)
{
    uint8_t i;

    if (tones == 0 || count == 0u) {
        return;
    }
    if (count > G3_AUDIO_MAX_TONES) {
        count = G3_AUDIO_MAX_TONES;
    }

    buzzer_off(&buzzer_cfg);
    for (i = 0u; i < count; ++i) {
        g3_audio_queue[i] = tones[i];
    }
    g3_audio_count = count;
    g3_audio_index = 0u;
    g3_audio_start_current_tone();
}

void G3_Audio_Update(void)
{
    if (!g3_audio_active) {
        return;
    }

    if ((HAL_GetTick() - g3_audio_tone_start) >= g3_audio_queue[g3_audio_index].duration_ms) {
        buzzer_off(&buzzer_cfg);
        g3_audio_index++;
        g3_audio_start_current_tone();
    }
}

void G3_Audio_SetPolarityVisual(const G3_GameState *state)
{
    if (state == 0) {
        return;
    }

    if (state->result == G3_RESULT_FAIL) {
        PWM_SetDuty(&pwm_cfg, 100);
        return;
    }

    if (state->gate_open) {
        PWM_SetDuty(&pwm_cfg, 85);
        return;
    }

    if (state->polarity == G3_POLARITY_NORTH) {
        PWM_SetDuty(&pwm_cfg, 25);
    } else {
        PWM_SetDuty(&pwm_cfg, 60);
    }
}

void G3_Audio_ShowIdleVisual(void)
{
    g3_audio_active = 0u;
    g3_audio_count = 0u;
    g3_audio_index = 0u;
    buzzer_off(&buzzer_cfg);
    PWM_SetDuty(&pwm_cfg, 15);
}

void G3_Audio_GameEnter(void)
{
    PWM_SetDuty(&pwm_cfg, 15);
    g3_audio_queue_sequence(g3_tones_enter, (uint8_t)(sizeof(g3_tones_enter) / sizeof(g3_tones_enter[0])));
}

void G3_Audio_OnEvent(G3_Event event, const G3_GameState *state)
{
    const G3_AudioTone *tones = 0;
    uint8_t count = 0u;

    switch (event) {
        case G3_EVENT_MOVE:
            tones = g3_tones_move;
            count = (uint8_t)(sizeof(g3_tones_move) / sizeof(g3_tones_move[0]));
            break;
        case G3_EVENT_PUSH_BOX:
            tones = g3_tones_push;
            count = (uint8_t)(sizeof(g3_tones_push) / sizeof(g3_tones_push[0]));
            break;
        case G3_EVENT_PULL_BOX:
            tones = g3_tones_pull;
            count = (uint8_t)(sizeof(g3_tones_pull) / sizeof(g3_tones_pull[0]));
            break;
        case G3_EVENT_REPEL_BOX:
            tones = g3_tones_repel;
            count = (uint8_t)(sizeof(g3_tones_repel) / sizeof(g3_tones_repel[0]));
            break;
        case G3_EVENT_TOGGLE_ONLY:
            tones = g3_tones_toggle;
            count = (uint8_t)(sizeof(g3_tones_toggle) / sizeof(g3_tones_toggle[0]));
            break;
        case G3_EVENT_GATE_OPEN:
            tones = g3_tones_gate_open;
            count = (uint8_t)(sizeof(g3_tones_gate_open) / sizeof(g3_tones_gate_open[0]));
            break;
        case G3_EVENT_GATE_CLOSE:
            tones = g3_tones_gate_close;
            count = (uint8_t)(sizeof(g3_tones_gate_close) / sizeof(g3_tones_gate_close[0]));
            break;
        case G3_EVENT_UNDO:
            tones = g3_tones_undo;
            count = (uint8_t)(sizeof(g3_tones_undo) / sizeof(g3_tones_undo[0]));
            break;
        case G3_EVENT_WIN:
            tones = g3_tones_win;
            count = (uint8_t)(sizeof(g3_tones_win) / sizeof(g3_tones_win[0]));
            break;
        case G3_EVENT_FAIL:
            tones = g3_tones_fail;
            count = (uint8_t)(sizeof(g3_tones_fail) / sizeof(g3_tones_fail[0]));
            break;
        case G3_EVENT_BLOCKED:
            tones = g3_tones_blocked;
            count = (uint8_t)(sizeof(g3_tones_blocked) / sizeof(g3_tones_blocked[0]));
            break;
        case G3_EVENT_NONE:
        default:
            break;
    }

    if (tones != 0 && count > 0u) {
        g3_audio_queue_sequence(tones, count);
    }

    G3_Audio_SetPolarityVisual(state);
}

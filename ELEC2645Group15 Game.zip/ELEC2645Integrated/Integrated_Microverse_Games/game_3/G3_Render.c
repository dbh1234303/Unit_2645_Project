#include "G3_Render.h"
#include "G3_Core.h"
#include "G3_Levels.h"
#include "LCD.h"
#include <stdio.h>
#include <string.h>

extern ST7789V2_cfg_t cfg0;

#define G3_COL_BG         0
#define G3_COL_TEXT       1
#define G3_COL_PLAYER     14
#define G3_COL_WALL       13
#define G3_COL_FLOOR      9
#define G3_COL_SWITCH     8
#define G3_COL_GATE_CLS   5
#define G3_COL_GATE_OPN   3
#define G3_COL_EXIT       6
#define G3_COL_TRAP       2
#define G3_COL_BOX        10
#define G3_COL_ACCENT     7
#define G3_COL_DIM        13
#define G3_COL_MAGNET_N   11
#define G3_COL_MAGNET_S   4

static void g3_draw_panel(uint16_t x, uint16_t y, uint16_t w, uint16_t h)
{
    LCD_Draw_Rect(x, y, w, h, G3_COL_DIM, 0);
}

static void g3_draw_centered_text(const char *text, uint16_t y, uint8_t colour, uint8_t size)
{
    uint16_t width = (uint16_t)(strlen(text) * 6u * size);
    uint16_t x = (240u > width) ? (uint16_t)((240u - width) / 2u) : 0u;
    LCD_printString(text, x, y, colour, size);
}

static void g3_format_time(uint16_t seconds, char *out, uint16_t out_len)
{
    uint16_t mins = (uint16_t)(seconds / 60u);
    uint16_t secs = (uint16_t)(seconds % 60u);
    snprintf(out, out_len, "%02u:%02u", mins, secs);
}

static void g3_format_best_time(uint16_t seconds, char *out, uint16_t out_len)
{
    if (seconds == 0u) {
        snprintf(out, out_len, "--:--");
    } else {
        g3_format_time(seconds, out, out_len);
    }
}

static int8_t g3_render_find_box_at(const G3_GameState *state, int16_t x, int16_t y)
{
    uint8_t i;
    for (i = 0; i < state->box_count; ++i) {
        if (state->boxes[i].x == x && state->boxes[i].y == y) {
            return (int8_t)i;
        }
    }
    return -1;
}

static uint8_t g3_render_magnet_blocked(const G3_GameState *state, int16_t x, int16_t y)
{
    G3_Tile tile;

    if (x < 0 || y < 0 || x >= state->width || y >= state->height) {
        return 1u;
    }
    tile = state->tiles[y][x];
    if (tile == G3_TILE_WALL) {
        return 1u;
    }
    if (tile == G3_TILE_GATE && !state->gate_open) {
        return 1u;
    }
    return 0u;
}

static void g3_draw_tile(const G3_GameState *state, uint8_t tx, uint8_t ty, uint16_t tile_size, uint16_t ox, uint16_t oy)
{
    uint16_t px = ox + (uint16_t)(tx * tile_size);
    uint16_t py = oy + (uint16_t)(ty * tile_size);
    G3_Tile tile = state->tiles[ty][tx];
    uint8_t colour = G3_COL_FLOOR;

    switch (tile) {
        case G3_TILE_WALL:
            colour = G3_COL_WALL;
            break;
        case G3_TILE_SWITCH:
            colour = G3_COL_SWITCH;
            break;
        case G3_TILE_GATE:
            colour = state->gate_open ? G3_COL_GATE_OPN : G3_COL_GATE_CLS;
            break;
        case G3_TILE_EXIT:
            colour = G3_COL_EXIT;
            break;
        case G3_TILE_TRAP:
            colour = G3_COL_TRAP;
            break;
        case G3_TILE_FLOOR:
        default:
            colour = G3_COL_FLOOR;
            break;
    }

    LCD_Draw_Rect(px, py, tile_size - 1u, tile_size - 1u, colour, 1);
    LCD_Draw_Rect(px, py, tile_size - 1u, tile_size - 1u, G3_COL_TEXT, 0);

    if (tile == G3_TILE_SWITCH) {
        LCD_printString("M", px + 5u, py + 5u, G3_COL_TEXT, 1);
    } else if (tile == G3_TILE_GATE) {
        LCD_printString("G", px + 5u, py + 5u, G3_COL_TEXT, 1);
    } else if (tile == G3_TILE_EXIT) {
        LCD_printString("E", px + 5u, py + 5u, G3_COL_TEXT, 1);
    } else if (tile == G3_TILE_TRAP) {
        LCD_printString("T", px + 5u, py + 5u, G3_COL_TEXT, 1);
    }
}

static void g3_draw_magnetic_range(const G3_GameState *state, uint16_t tile_size, uint16_t ox, uint16_t oy)
{
    static const int8_t dir_x[4] = {0, 1, 0, -1};
    static const int8_t dir_y[4] = {-1, 0, 1, 0};
    uint8_t d;

    for (d = 0; d < 4u; ++d) {
        int8_t distance;
        for (distance = 1; distance <= 3; ++distance) {
            int16_t tx = state->player.x + dir_x[d] * distance;
            int16_t ty = state->player.y + dir_y[d] * distance;
            uint16_t px;
            uint16_t py;
            uint8_t colour;
            int16_t arrow_dx;
            int16_t arrow_dy;
            int16_t cx;
            int16_t cy;
            int16_t ex;
            int16_t ey;

            if (g3_render_magnet_blocked(state, tx, ty)) {
                break;
            }

            px = ox + (uint16_t)(tx * tile_size);
            py = oy + (uint16_t)(ty * tile_size);
            colour = (state->polarity == G3_POLARITY_NORTH) ? G3_COL_MAGNET_N : G3_COL_MAGNET_S;
            if (state->polarity == G3_POLARITY_NORTH && distance == 1) {
                colour = G3_COL_DIM;
            }

            LCD_Draw_Rect(px + 3u, py + 3u, tile_size - 7u, tile_size - 7u, colour, 0);

            arrow_dx = (state->polarity == G3_POLARITY_NORTH) ? (int16_t)(-dir_x[d]) : (int16_t)dir_x[d];
            arrow_dy = (state->polarity == G3_POLARITY_NORTH) ? (int16_t)(-dir_y[d]) : (int16_t)dir_y[d];
            cx = (int16_t)(px + tile_size / 2u);
            cy = (int16_t)(py + tile_size / 2u);
            ex = (int16_t)(cx + arrow_dx * 5);
            ey = (int16_t)(cy + arrow_dy * 5);
            LCD_Draw_Line((uint16_t)cx, (uint16_t)cy, (uint16_t)ex, (uint16_t)ey, colour);

            if (g3_render_find_box_at(state, tx, ty) >= 0) {
                LCD_Draw_Circle((uint16_t)cx, (uint16_t)cy, 5u, colour, 0);
            }
        }
    }
}

static void g3_draw_map(const G3_GameState *state)
{
    uint16_t tile_size = 18u;
    uint16_t ox = (uint16_t)((240u - state->width * tile_size) / 2u);
    uint16_t oy = 34u;
    uint8_t x;
    uint8_t y;
    uint8_t i;

    for (y = 0; y < state->height; ++y) {
        for (x = 0; x < state->width; ++x) {
            g3_draw_tile(state, x, y, tile_size, ox, oy);
        }
    }

    g3_draw_magnetic_range(state, tile_size, ox, oy);

    for (i = 0; i < state->box_count; ++i) {
        uint16_t px = ox + (uint16_t)(state->boxes[i].x * tile_size) + 3u;
        uint16_t py = oy + (uint16_t)(state->boxes[i].y * tile_size) + 3u;
        LCD_Draw_Rect(px, py, tile_size - 7u, tile_size - 7u, G3_COL_BOX, 1);
        LCD_Draw_Rect(px, py, tile_size - 7u, tile_size - 7u, G3_COL_TEXT, 0);
        LCD_printString("B", px + 4u, py + 3u, G3_COL_BG, 1);
    }

    {
        uint16_t px = ox + (uint16_t)(state->player.x * tile_size) + 4u;
        uint16_t py = oy + (uint16_t)(state->player.y * tile_size) + 4u;
        LCD_Draw_Circle(px + 4u, py + 4u, 6u, G3_COL_PLAYER, 1);
        LCD_printString(state->polarity == G3_POLARITY_NORTH ? "N" : "S", px + 2u, py + 1u, G3_COL_BG, 1);
    }
}

void G3_Render_LevelSelect(uint8_t selected_level, const G3_LevelProgress progress[G3_LEVEL_COUNT])
{
    uint8_t i;
    LCD_Fill_Buffer(G3_COL_BG);
    g3_draw_centered_text("MAGNETIC MAZE", 6u, G3_COL_TEXT, 2u);
    g3_draw_centered_text("Research Tower", 24u, G3_COL_ACCENT, 1u);
    g3_draw_panel(14u, 38u, 212u, 150u);

    for (i = 0; i < G3_LEVEL_COUNT; ++i) {
        const G3_LevelDef *level = G3_Levels_Get(i);
        char line[48];
        char stars[8] = "---";
        uint16_t y = (uint16_t)(46u + i * 23u);
        uint8_t colour = progress[i].unlocked ? G3_COL_TEXT : G3_COL_DIM;
        uint8_t s;

        for (s = 0; s < 3u; ++s) {
            stars[s] = (s < progress[i].stars) ? '*' : '-';
        }
        stars[3] = '\0';

        snprintf(line, sizeof(line), "%c L%u %s", (i == selected_level) ? '>' : ' ', (unsigned)(i + 1u), progress[i].unlocked ? level->subtitle : "LOCKED");
        LCD_printString(line, 24u, y, colour, 1u);
        LCD_printString(progress[i].unlocked ? stars : "LOCK", 188u, y, colour, 1u);
    }

    LCD_printString("JOY: Select level", 24u, 198u, G3_COL_TEXT, 1u);
    LCD_printString("BTN3: Start", 24u, 212u, G3_COL_TEXT, 1u);
    LCD_printString("BTN2: Back", 24u, 226u, G3_COL_TEXT, 1u);
    LCD_Refresh(&cfg0);
}

void G3_Render_Game(const G3_GameState *state)
{
    char top_line[48];
    char time_str[8];
    char par_time[8];
    uint16_t par_steps = 0u;
    uint16_t par_time_s = 0u;

    if (state->level_def != NULL) {
        par_steps = state->level_def->par_steps;
        par_time_s = state->level_def->par_time_s;
    }

    LCD_Fill_Buffer(G3_COL_BG);
    g3_format_time(G3_Core_GetElapsedSeconds(state), time_str, sizeof(time_str));
    g3_format_time(par_time_s, par_time, sizeof(par_time));
    snprintf(top_line, sizeof(top_line), "L%u S:%03u/%03u T:%s/%s %c", (unsigned)(state->level_index + 1u), (unsigned)state->steps, (unsigned)par_steps, time_str, par_time, state->polarity == G3_POLARITY_NORTH ? 'N' : 'S');
    LCD_printString(top_line, 6u, 8u, G3_COL_TEXT, 1u);
    LCD_Draw_Line(6u, 24u, 233u, 24u, G3_COL_DIM);

    g3_draw_map(state);

    LCD_Draw_Line(6u, 216u, 233u, 216u, G3_COL_DIM);
    LCD_printString(state->hint, 8u, 220u, G3_COL_TEXT, 1u);
    LCD_Refresh(&cfg0);
}

void G3_Render_Pause(const G3_GameState *state, uint8_t selected_option)
{
    const char *options[4] = {"Resume", "Undo", "Restart", "Menu"};
    uint8_t i;
    char line[24];
    char time_str[8];

    LCD_Fill_Buffer(G3_COL_BG);
    g3_draw_centered_text("PAUSED", 14u, G3_COL_TEXT, 3u);
    g3_draw_panel(32u, 56u, 176u, 128u);

    for (i = 0; i < 4u; ++i) {
        uint8_t colour = G3_COL_TEXT;
        if (i == 1u && !G3_Core_CanUndo(state)) {
            colour = G3_COL_DIM;
        }
        snprintf(line, sizeof(line), "%c %s", (i == selected_option) ? '>' : ' ', options[i]);
        LCD_printString(line, 60u, (uint16_t)(72u + i * 22u), colour, 2u);
    }

    g3_format_time(G3_Core_GetElapsedSeconds(state), time_str, sizeof(time_str));
    LCD_printString(state->polarity == G3_POLARITY_NORTH ? "Polarity: N" : "Polarity: S", 52u, 160u, G3_COL_TEXT, 1u);
    snprintf(line, sizeof(line), "Steps: %u  %s", (unsigned)state->steps, time_str);
    LCD_printString(line, 52u, 174u, G3_COL_TEXT, 1u);
    LCD_Refresh(&cfg0);
}

static void g3_result_options(const G3_GameState *state, const G3_LevelProgress progress[G3_LEVEL_COUNT], const char **options)
{
    uint8_t has_next = (state->result == G3_RESULT_WIN && (state->level_index + 1u) < G3_LEVEL_COUNT && progress[state->level_index + 1u].unlocked) ? 1u : 0u;

    if (state->result == G3_RESULT_WIN && has_next) {
        options[0] = "Next";
        options[1] = "Replay";
        options[2] = "Menu";
    } else if (state->result == G3_RESULT_WIN) {
        options[0] = "Level Select";
        options[1] = "Replay";
        options[2] = "Menu";
    } else {
        options[0] = "Replay";
        options[1] = "Level Select";
        options[2] = "Menu";
    }
}

void G3_Render_Result(const G3_GameState *state, uint8_t selected_option, const G3_LevelProgress progress[G3_LEVEL_COUNT])
{
    const char *options[3];
    char line[48];
    char time_str[8];
    char par_time[8];
    char best_time[8];
    char stars[8] = "---";
    char best_stars[8] = "---";
    uint8_t i;
    uint8_t star_count = G3_Core_ComputeStars(state);
    uint16_t score = G3_Core_ComputeScore(state);
    uint16_t par_steps = 0u;
    uint16_t par_time_s = 0u;
    const G3_LevelProgress *p = &progress[state->level_index];

    if (state->level_def != NULL) {
        par_steps = state->level_def->par_steps;
        par_time_s = state->level_def->par_time_s;
    }

    g3_result_options(state, progress, options);

    LCD_Fill_Buffer(G3_COL_BG);
    if (state->result == G3_RESULT_WIN) {
        g3_draw_centered_text("LEVEL COMPLETE", 8u, G3_COL_TEXT, 2u);
    } else {
        g3_draw_centered_text("LEVEL FAILED", 8u, G3_COL_TRAP, 2u);
    }

    g3_draw_panel(18u, 34u, 204u, 160u);
    g3_format_time(G3_Core_GetElapsedSeconds(state), time_str, sizeof(time_str));
    g3_format_time(par_time_s, par_time, sizeof(par_time));
    g3_format_best_time(p->best_time_s, best_time, sizeof(best_time));

    for (i = 0; i < 3u; ++i) {
        stars[i] = (i < star_count) ? '*' : '-';
        best_stars[i] = (i < p->stars) ? '*' : '-';
    }
    stars[3] = '\0';
    best_stars[3] = '\0';

    snprintf(line, sizeof(line), "Score: %u   Best: %u", (unsigned)score, (unsigned)p->best_score);
    LCD_printString(line, 32u, 48u, G3_COL_TEXT, 1u);
    snprintf(line, sizeof(line), "Steps: %u / %u", (unsigned)state->steps, (unsigned)par_steps);
    LCD_printString(line, 32u, 62u, G3_COL_TEXT, 1u);
    snprintf(line, sizeof(line), "Time : %s / %s", time_str, par_time);
    LCD_printString(line, 32u, 76u, G3_COL_TEXT, 1u);
    snprintf(line, sizeof(line), "Stars: %s   Best: %s", stars, best_stars);
    LCD_printString(line, 32u, 90u, G3_COL_ACCENT, 1u);
    snprintf(line, sizeof(line), "Best run: %u st  %s", (unsigned)p->best_steps, best_time);
    LCD_printString(line, 32u, 104u, G3_COL_TEXT, 1u);

    for (i = 0; i < 3u; ++i) {
        snprintf(line, sizeof(line), "%c %s", (i == selected_option) ? '>' : ' ', options[i]);
        LCD_printString(line, 52u, (uint16_t)(128u + i * 20u), G3_COL_TEXT, 2u);
    }
    LCD_Refresh(&cfg0);
}

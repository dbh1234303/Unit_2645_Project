#ifndef G3_CORE_H
#define G3_CORE_H

#include <stdint.h>
#include "G3_Types.h"

void G3_Core_LoadLevel(G3_GameState *state, uint8_t level_index);
G3_Event G3_Core_MovePlayer(G3_GameState *state, int8_t dx, int8_t dy);
G3_Event G3_Core_TogglePolarity(G3_GameState *state);
G3_Event G3_Core_Undo(G3_GameState *state);
uint8_t G3_Core_CanUndo(const G3_GameState *state);
void G3_Core_Pause(G3_GameState *state);
void G3_Core_Resume(G3_GameState *state);
uint16_t G3_Core_GetElapsedSeconds(const G3_GameState *state);
uint8_t G3_Core_ComputeStars(const G3_GameState *state);
uint16_t G3_Core_ComputeScore(const G3_GameState *state);
uint8_t G3_Core_IsBoxOnSwitch(const G3_GameState *state, uint8_t switch_index);

#endif

#ifndef G2_AUDIOFX_H
#define G2_AUDIOFX_H

#include <stdint.h>
#include "G2_Types.h"

/* Audio/light effect lifecycle. */
void G2_Audio_Init(G2_AudioState *audio);
void G2_Audio_Update(G2_AudioState *audio, uint32_t now_ms, uint16_t combo, G2_JudgeResult last_result);

/* One-shot cues requested by the game state machine. */
void G2_Audio_PlayStart(G2_AudioState *audio, uint32_t now_ms);
void G2_Audio_PlayBeat(G2_AudioState *audio, uint32_t now_ms, uint8_t accent);
void G2_Audio_PlayJudge(G2_AudioState *audio, uint32_t now_ms, G2_JudgeResult result, uint16_t combo);

/* Safety cleanup when leaving Game 2 or restarting. */
void G2_Audio_StopAll(G2_AudioState *audio);

#endif

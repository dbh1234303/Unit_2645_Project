#ifndef G2_RENDER_H
#define G2_RENDER_H

#include <stdint.h>
#include "G2_Types.h"

/* Screen-specific render entry points; each draws into the LCD back buffer. */
void G2_Render_DifficultyMenu(const G2_GameState *state, uint32_t now_ms);
void G2_Render_Countdown(const G2_GameState *state, uint32_t now_ms);
void G2_Render_Play(const G2_GameState *state, uint32_t now_ms);
void G2_Render_Pause(const G2_GameState *state);
void G2_Render_Result(const G2_GameState *state);

#endif

#ifndef G2_TYPES_H
#define G2_TYPES_H

#include <stdint.h>
#include "Menu.h"
#include "Joystick.h"

/*
 * Shared Game 2 constants and data types.
 * These definitions are used across chart, core, judgement, audio, and render
 * modules so each module can communicate through the same state structures.
 */

/* Gameplay dimensions, timing windows, and input thresholds. */
#define G2_LANE_COUNT            3u
#define G2_MAX_NOTES             96u
#define G2_PERFECT_WINDOW_MS     90u
#define G2_GOOD_WINDOW_MS        180u
#define G2_RESULT_FLASH_MS       450u
#define G2_FRAME_TIME_MS         20u
#define G2_HOLD_GRACE_MS         70u
#define G2_COUNTDOWN_MS          3200u
#define G2_TUTORIAL_MS           2600u
#define G2_OBSTACLE_WINDOW_MS    110u
#define G2_OBSTACLE_WARNING_MS   300u
#define G2_INPUT_OFFSET_MS       40
#define G2_FEVER_COMBO           30u

#define G2_LANE_ENTER_THRESHOLD  420
#define G2_LANE_RELEASE_THRESHOLD 210

#define G2_PLAYFIELD_TOP         34u
#define G2_PLAYFIELD_BOTTOM      212u
#define G2_NOTE_SPAWN_Y          42u
#define G2_HIT_LINE_Y            188u
#define G2_LANE_CENTER_LEFT      60u
#define G2_LANE_CENTER_MID       120u
#define G2_LANE_CENTER_RIGHT     180u
#define G2_NOTE_RADIUS           9u

/* High-level scenes controlled by the core state machine. */
typedef enum {
    G2_SCENE_DIFFICULTY = 0,
    G2_SCENE_COUNTDOWN,
    G2_SCENE_PLAY,
    G2_SCENE_PAUSE,
    G2_SCENE_RESULT,
    G2_SCENE_EXIT
} G2_Scene;

/* Available chart difficulties. */
typedef enum {
    G2_DIFF_PRACTICE = 0,
    G2_DIFF_STANDARD,
    G2_DIFF_FRENZY,
    G2_DIFF_COUNT
} G2_Difficulty;

/* Static chart note categories. */
typedef enum {
    G2_NOTE_TAP = 0,
    G2_NOTE_HOLD = 1,
    G2_NOTE_OBSTACLE = 2
} G2_NoteType;

/* Possible judgement outcomes after resolving a note or obstacle. */
typedef enum {
    G2_JUDGE_NONE = 0,
    G2_JUDGE_PERFECT,
    G2_JUDGE_GOOD,
    G2_JUDGE_MISS,
    G2_JUDGE_DODGE
} G2_JudgeResult;

/* Per-note runtime state stored separately from immutable chart data. */
typedef enum {
    G2_NOTE_STATE_PENDING = 0,
    G2_NOTE_STATE_RESOLVED = 1,
    G2_NOTE_STATE_HOLDING = 2
} G2_NoteRuntimeState;

/* One chart event: time, lane, note type, and optional hold/accent metadata. */
typedef struct {
    uint16_t hit_time_ms;
    uint16_t duration_ms;
    uint8_t lane;
    uint8_t type;
    uint8_t accent;
} G2_NoteEvent;

/* Immutable chart metadata and pointer to its note array. */
typedef struct {
    const char *name;
    uint16_t bpm;
    uint16_t beat_interval_ms;
    uint16_t scroll_time_ms;
    uint16_t song_length_ms;
    uint16_t note_count;
    const G2_NoteEvent *notes;
} G2_Chart;

/* Runtime scoring counters shown on HUD/result screens. */
typedef struct {
    uint32_t score;
    uint16_t combo;
    uint16_t max_combo;
    uint16_t perfect_count;
    uint16_t good_count;
    uint16_t miss_count;
    uint16_t hold_count;
    uint16_t obstacle_clear_count;
    uint8_t multiplier_tenths;
    uint8_t fever_active;
    G2_JudgeResult last_result;
    uint32_t last_result_ms;
} G2_ScoreState;

/* Transient buzzer/LED/PWM state managed by G2_AudioFX. */
typedef struct {
    uint8_t buzzer_active;
    uint32_t buzzer_stop_ms;
    uint32_t led_flash_until_ms;
    uint32_t combo_pulse_until_ms;
} G2_AudioState;

/* Complete mutable game state owned by G2_Core_Run. */
typedef struct {
    G2_Scene scene;
    MenuState exit_state;
    G2_Difficulty difficulty;
    const G2_Chart *chart;
    G2_ScoreState scoring;
    G2_AudioState audio;
    uint8_t selected_lane;
    uint8_t difficulty_index;
    uint8_t pause_index;
    uint8_t result_index;
    uint8_t note_state[G2_MAX_NOTES];
    uint8_t active_hold;
    uint8_t hold_note_index;
    G2_JudgeResult hold_result;
    uint32_t hold_end_ms;
    uint32_t scene_enter_ms;
    uint32_t play_start_ms;
    uint32_t pause_started_ms;
    uint32_t elapsed_ms;
    uint32_t next_beat_ms;
    uint32_t result_high_score;
    uint8_t result_new_record;
    Direction last_direction;
} G2_GameState;

#endif

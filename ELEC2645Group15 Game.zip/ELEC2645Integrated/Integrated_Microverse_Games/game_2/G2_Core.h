#ifndef G2_CORE_H
#define G2_CORE_H

#include "Menu.h"

/* Runs the complete Game 2 state machine and returns the next menu state. */
MenuState G2_Core_Run(void);

#endif

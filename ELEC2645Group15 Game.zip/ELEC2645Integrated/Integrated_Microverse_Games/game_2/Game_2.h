#ifndef GAME_2_H
#define GAME_2_H

#include "Menu.h"


/* Public entry point used by the shared menu system to launch Game 2. */
MenuState Game2_Run(void);

#endif

#include "G2_Core.h"
#include "G2_Chart.h"
#include "G2_Judge.h"
#include "G2_AudioFX.h"
#include "G2_Render.h"
#include "InputHandler.h"
#include "LCD.h"
#include "Joystick.h"
#include "main.h"
#include "stm32l4xx_hal.h"
#include <string.h>

/*
 * Game 2 core module.
 * Owns the scene state machine, input routing, chart progression, note timing,
 * hold/obstacle resolution, and the per-frame update/render loop.
 */
extern ST7789V2_cfg_t cfg0;
extern Joystick_cfg_t joystick_cfg;
extern Joystick_t joystick_data;

/* Session-local high scores are kept per difficulty while the firmware is running. */
static uint32_t g2_high_scores[G2_DIFF_COUNT] = {0u, 0u, 0u};

/* Direction helpers collapse diagonals into the four menu/navigation axes. */
static uint8_t G2_IsUp(Direction d)
{
    return (uint8_t)((d == N) || (d == NE) || (d == NW));
}

static uint8_t G2_IsDown(Direction d)
{
    return (uint8_t)((d == S) || (d == SE) || (d == SW));
}

static uint8_t G2_IsLeft(Direction d)
{
    return (uint8_t)((d == W) || (d == NW) || (d == SW));
}

static uint8_t G2_IsRight(Direction d)
{
    return (uint8_t)((d == E) || (d == NE) || (d == SE));
}

/* BTN3 is the primary tap/hold input and is active-low on this board. */
static uint8_t G2_IsHitHeld(void)
{
    return (uint8_t)(HAL_GPIO_ReadPin(BTN3_GPIO_Port, BTN3_Pin) == GPIO_PIN_RESET);
}

/* BTN2 doubles as an alternate hit button when the selected lane is not center. */
static uint8_t G2_IsAltHitHeld(void)
{
    return (uint8_t)(HAL_GPIO_ReadPin(BTN2_GPIO_Port, BTN2_Pin) == GPIO_PIN_RESET);
}

/* Practice mode widens timing windows so new players can learn the chart. */
static uint16_t G2_PerfectWindowMs(const G2_GameState *state)
{
    return (state->difficulty == G2_DIFF_PRACTICE) ? 120u : G2_PERFECT_WINDOW_MS;
}

static uint16_t G2_GoodWindowMs(const G2_GameState *state)
{
    return (state->difficulty == G2_DIFF_PRACTICE) ? 240u : G2_GOOD_WINDOW_MS;
}

static uint16_t G2_HoldGraceMs(const G2_GameState *state)
{
    return (state->difficulty == G2_DIFF_PRACTICE) ? 110u : G2_HOLD_GRACE_MS;
}

/* Applies a small input offset before comparing player input to chart time. */
static int32_t G2_AdjustedTimingDeltaAt(uint32_t elapsed_ms, const G2_NoteEvent *note)
{
    return ((int32_t)elapsed_ms + (int32_t)G2_INPUT_OFFSET_MS) - (int32_t)note->hit_time_ms;
}

/* Initializes the full game state and returns to the difficulty selection scene. */
static void G2_ResetState(G2_GameState *state)
{
    memset(state, 0, sizeof(*state));
    state->scene = G2_SCENE_DIFFICULTY;
    state->exit_state = MENU_STATE_HOME;
    state->difficulty = G2_DIFF_PRACTICE;
    state->difficulty_index = 0u;
    state->pause_index = 0u;
    state->result_index = 0u;
    state->selected_lane = 1u;
    state->hold_note_index = 0xFFu;
    state->scene_enter_ms = HAL_GetTick();
    state->last_direction = CENTRE;
    G2_Judge_Reset(&state->scoring);
    G2_Audio_Init(&state->audio);
}

/* Loads the selected chart and clears all runtime fields for a fresh attempt. */
static void G2_PrepareGameplay(G2_GameState *state, uint32_t now_ms)
{
    state->difficulty = (G2_Difficulty)state->difficulty_index;
    state->chart = G2_Chart_Get(state->difficulty);
    state->selected_lane = 1u;
    state->pause_index = 0u;
    state->result_index = 0u;
    state->play_start_ms = now_ms;
    state->pause_started_ms = 0u;
    state->elapsed_ms = 0u;
    state->next_beat_ms = 0u;
    state->last_direction = CENTRE;
    state->active_hold = 0u;
    state->hold_note_index = 0xFFu;
    state->hold_result = G2_JUDGE_NONE;
    state->hold_end_ms = 0u;
    state->result_high_score = g2_high_scores[state->difficulty];
    state->result_new_record = 0u;
    G2_Chart_ResetRuntime(state);
    G2_Judge_Reset(&state->scoring);
}

/* Transitions from menus/result into the pre-play countdown. */
static void G2_BeginCountdown(G2_GameState *state, uint32_t now_ms)
{
    G2_PrepareGameplay(state, now_ms);
    state->scene = G2_SCENE_COUNTDOWN;
    state->scene_enter_ms = now_ms;
    G2_Audio_PlayStart(&state->audio, now_ms);
}

/* Starts song time at zero after countdown finishes or is skipped. */
static void G2_StartGameplay(G2_GameState *state, uint32_t now_ms)
{
    state->play_start_ms = now_ms;
    state->elapsed_ms = 0u;
    state->next_beat_ms = 0u;
    state->scene = G2_SCENE_PLAY;
    state->scene_enter_ms = now_ms;
    state->last_direction = CENTRE;
    G2_Audio_PlayStart(&state->audio, now_ms);
}

/* Enters the pause scene and records the pause start time for later compensation. */
static void G2_OpenPause(G2_GameState *state, uint32_t now_ms)
{
    state->scene = G2_SCENE_PAUSE;
    state->pause_index = 0u;
    state->pause_started_ms = now_ms;
    state->scene_enter_ms = now_ms;
    state->last_direction = CENTRE;
}

/* Shifts play_start_ms forward so elapsed song time ignores paused duration. */
static void G2_ResumeFromPause(G2_GameState *state, uint32_t now_ms)
{
    if (state->pause_started_ms != 0u) {
        state->play_start_ms += (now_ms - state->pause_started_ms);
    }
    state->pause_started_ms = 0u;
    state->scene = G2_SCENE_PLAY;
    state->scene_enter_ms = now_ms;
    state->last_direction = CENTRE;
}

/* Finalizes the run, updates per-difficulty high score, and opens results. */
static void G2_ShowResult(G2_GameState *state, uint32_t now_ms)
{
    uint8_t diff = (uint8_t)state->difficulty;

    state->scene = G2_SCENE_RESULT;
    state->result_index = 0u;
    state->scene_enter_ms = now_ms;
    state->last_direction = CENTRE;
    state->result_new_record = 0u;

    if (diff < G2_DIFF_COUNT) {
        if (state->scoring.score > g2_high_scores[diff]) {
            g2_high_scores[diff] = state->scoring.score;
            state->result_new_record = 1u;
        }
        state->result_high_score = g2_high_scores[diff];
    }

    G2_Audio_StopAll(&state->audio);
}

/* Requests return to the shared menu loop. */
static void G2_RequestExit(G2_GameState *state, uint32_t now_ms)
{
    state->scene = G2_SCENE_EXIT;
    state->scene_enter_ms = now_ms;
}

/* Marks a normal note as resolved, updates score, and triggers feedback. */
static void G2_RegisterResult(G2_GameState *state, uint16_t note_index, G2_JudgeResult result, uint32_t now_ms)
{
    if (note_index >= G2_MAX_NOTES) {
        return;
    }

    state->note_state[note_index] = G2_NOTE_STATE_RESOLVED;
    G2_Judge_Apply(&state->scoring, result, now_ms);
    G2_Audio_PlayJudge(&state->audio, now_ms, result, state->scoring.combo);
}

/* Begins a hold note after its head is judged; completion is checked each frame. */
static void G2_StartHold(G2_GameState *state, uint16_t note_index, G2_JudgeResult result, uint32_t now_ms)
{
    state->active_hold = 1u;
    state->hold_note_index = (uint8_t)note_index;
    state->hold_result = result;
    state->hold_end_ms = (uint32_t)state->chart->notes[note_index].hit_time_ms + (uint32_t)state->chart->notes[note_index].duration_ms;
    state->note_state[note_index] = G2_NOTE_STATE_HOLDING;


    G2_Judge_Apply(&state->scoring, result, now_ms);
    G2_Audio_PlayJudge(&state->audio, now_ms, result, state->scoring.combo);
}

/* Cancels an active hold and applies a Miss when the player releases/moves early. */
static void G2_FailHold(G2_GameState *state, uint32_t now_ms)
{
    if (state->active_hold == 0u) {
        return;
    }

    state->note_state[state->hold_note_index] = G2_NOTE_STATE_RESOLVED;
    state->active_hold = 0u;
    state->hold_note_index = 0xFFu;
    state->hold_end_ms = 0u;
    state->hold_result = G2_JUDGE_NONE;
    G2_Judge_Apply(&state->scoring, G2_JUDGE_MISS, now_ms);
    G2_Audio_PlayJudge(&state->audio, now_ms, G2_JUDGE_MISS, state->scoring.combo);
}

/* Resolves a hold note successfully and awards the hold completion bonus. */
static void G2_CompleteHold(G2_GameState *state, uint32_t now_ms)
{
    if (state->active_hold == 0u) {
        return;
    }

    state->note_state[state->hold_note_index] = G2_NOTE_STATE_RESOLVED;
    state->active_hold = 0u;
    state->hold_note_index = 0xFFu;
    state->hold_end_ms = 0u;
    state->hold_result = G2_JUDGE_NONE;
    state->scoring.hold_count++;


    G2_Judge_AddBonus(&state->scoring, 120u);
    G2_Audio_PlayJudge(&state->audio, now_ms, G2_JUDGE_PERFECT, state->scoring.combo);
}

/*
 * Finds the closest pending tap/hold note in the selected lane.
 * The search ignores obstacles and notes outside the Good timing window, then
 * upgrades the result to Perfect if the closest note is inside the tighter window.
 */
static void G2_HandleHitAttemptAt(G2_GameState *state, uint32_t event_elapsed_ms, uint32_t now_ms)
{
    uint16_t i;
    uint16_t good_window = G2_GoodWindowMs(state);
    uint16_t perfect_window = G2_PerfectWindowMs(state);
    int32_t best_delta = 0x7FFFFFFF;
    int16_t best_index = -1;
    G2_JudgeResult result;

    if (state->chart == 0 || state->active_hold != 0u) {
        return;
    }

    /* Scan all pending notes to choose the nearest valid candidate. */
    for (i = 0u; i < state->chart->note_count; ++i) {
        int32_t delta;
        const G2_NoteEvent *note = &state->chart->notes[i];

        if (state->note_state[i] != G2_NOTE_STATE_PENDING) {
            continue;
        }
        if (note->type == G2_NOTE_OBSTACLE) {
            continue;
        }
        if (note->lane != state->selected_lane) {
            continue;
        }

        /* Signed delta allows the same logic to handle early and late hits. */
        delta = G2_AdjustedTimingDeltaAt(event_elapsed_ms, note);
        if (delta < 0) {
            if ((uint32_t)(-delta) > good_window) {
                continue;
            }
        } else if ((uint32_t)delta > good_window) {
            continue;
        }

        if (delta < 0) {
            delta = -delta;
        }

        if (delta < best_delta) {
            best_delta = delta;
            best_index = (int16_t)i;
        }
    }

    if (best_index < 0) {
        return;
    }

    result = (best_delta <= (int32_t)perfect_window) ? G2_JUDGE_PERFECT : G2_JUDGE_GOOD;

    if (state->chart->notes[best_index].type == G2_NOTE_HOLD) {
        G2_StartHold(state, (uint16_t)best_index, result, now_ms);
        return;
    }

    G2_RegisterResult(state, (uint16_t)best_index, result, now_ms);
}

/* Convenience wrapper that judges input against the current elapsed song time. */
static void G2_HandleHitAttempt(G2_GameState *state, uint32_t now_ms)
{
    G2_HandleHitAttemptAt(state, state->elapsed_ms, now_ms);
}

/*
 * Validates an active hold every frame.
 * The player must stay in the note lane and keep holding a valid button until
 * hold_end_ms, with a small grace period to avoid accidental edge releases.
 */
static void G2_UpdateHoldState(G2_GameState *state, uint32_t now_ms)
{
    const G2_NoteEvent *note;

    if (state->active_hold == 0u || state->chart == 0) {
        return;
    }

    note = &state->chart->notes[state->hold_note_index];

    if (state->selected_lane != note->lane) {
        G2_FailHold(state, now_ms);
        return;
    }

    {
        uint8_t hold_input = G2_IsHitHeld();

        /* Side-lane holds can use BTN2, while center keeps BTN2 reserved for pause. */
        if (note->lane != 1u && G2_IsAltHitHeld() != 0u) {
            hold_input = 1u;
        }

        if (hold_input == 0u && state->elapsed_ms + G2_HoldGraceMs(state) < state->hold_end_ms) {
            G2_FailHold(state, now_ms);
            return;
        }
    }

    if (state->elapsed_ms >= state->hold_end_ms) {
        G2_CompleteHold(state, now_ms);
    }
}

/* Resolves obstacles when their hit time reaches the judgement line. */
static void G2_UpdateObstacles(G2_GameState *state, uint32_t now_ms)
{
    uint16_t i;

    if (state->chart == 0) {
        return;
    }

    for (i = 0u; i < state->chart->note_count; ++i) {
        const G2_NoteEvent *note = &state->chart->notes[i];

        if (state->note_state[i] != G2_NOTE_STATE_PENDING || note->type != G2_NOTE_OBSTACLE) {
            continue;
        }

        if (state->elapsed_ms + (G2_FRAME_TIME_MS / 2u) < note->hit_time_ms) {
            continue;
        }

        state->note_state[i] = G2_NOTE_STATE_RESOLVED;
        /* Being in the obstacle lane is a Miss; any other lane counts as a dodge. */
        if (state->selected_lane == note->lane) {
            G2_Judge_Apply(&state->scoring, G2_JUDGE_MISS, now_ms);
            G2_Audio_PlayJudge(&state->audio, now_ms, G2_JUDGE_MISS, state->scoring.combo);
        } else {
            G2_Judge_Apply(&state->scoring, G2_JUDGE_DODGE, now_ms);
            G2_Audio_PlayJudge(&state->audio, now_ms, G2_JUDGE_DODGE, state->scoring.combo);
        }
    }
}

/* Marks regular notes as Miss once they pass beyond the Good window. */
static void G2_AutoMissExpiredNotes(G2_GameState *state, uint32_t now_ms)
{
    uint16_t i;

    if (state->chart == 0) {
        return;
    }

    for (i = 0u; i < state->chart->note_count; ++i) {
        const G2_NoteEvent *note = &state->chart->notes[i];

        if (state->note_state[i] != G2_NOTE_STATE_PENDING) {
            continue;
        }
        if (note->type == G2_NOTE_OBSTACLE) {
            continue;
        }

        if (state->elapsed_ms > (uint32_t)note->hit_time_ms + G2_GoodWindowMs(state)) {
            G2_RegisterResult(state, i, G2_JUDGE_MISS, now_ms);
        }
    }
}

/* Converts joystick X position into a sticky three-lane selector. */
static void G2_UpdateSelectedLane(G2_GameState *state)
{
    int16_t x = joystick_data.x_processed;

    // Side lanes stay latched until the stick comes back close to neutral.
    if (state->selected_lane == 0u) {
        if (x >= G2_LANE_ENTER_THRESHOLD) {
            state->selected_lane = (uint8_t)(G2_LANE_COUNT - 1u);
        } else if (x > -G2_LANE_RELEASE_THRESHOLD) {
            state->selected_lane = 1u;
        }
        return;
    }

    if (state->selected_lane == (uint8_t)(G2_LANE_COUNT - 1u)) {
        if (x <= -G2_LANE_ENTER_THRESHOLD) {
            state->selected_lane = 0u;
        } else if (x < G2_LANE_RELEASE_THRESHOLD) {
            state->selected_lane = 1u;
        }
        return;
    }

    if (x <= -G2_LANE_ENTER_THRESHOLD) {
        state->selected_lane = 0u;
    } else if (x >= G2_LANE_ENTER_THRESHOLD) {
        state->selected_lane = (uint8_t)(G2_LANE_COUNT - 1u);
    }
}

/* Handles difficulty menu navigation and start/exit buttons. */
static void G2_HandleDifficultyInput(G2_GameState *state, Direction dir, uint32_t now_ms)
{
    if (G2_IsDown(dir) && !G2_IsDown(state->last_direction)) {
        state->difficulty_index = (uint8_t)((state->difficulty_index + 1u) % G2_DIFF_COUNT);
    } else if (G2_IsUp(dir) && !G2_IsUp(state->last_direction)) {
        if (state->difficulty_index == 0u) {
            state->difficulty_index = (uint8_t)(G2_DIFF_COUNT - 1u);
        } else {
            state->difficulty_index--;
        }
    }

    if (current_input.btn3_pressed != 0u) {
        G2_BeginCountdown(state, now_ms);
        return;
    }

    if (current_input.btn2_pressed != 0u) {
        G2_RequestExit(state, now_ms);
    }
}

/* Advances countdown automatically, with BTN3 as an optional skip. */
static void G2_HandleCountdownInput(G2_GameState *state, uint32_t now_ms)
{
    uint32_t countdown_elapsed = now_ms - state->scene_enter_ms;

    if (current_input.btn2_pressed != 0u) {
        G2_RequestExit(state, now_ms);
        return;
    }

    if ((countdown_elapsed >= G2_COUNTDOWN_MS) || (current_input.btn3_pressed != 0u && countdown_elapsed > 450u)) {
        G2_StartGameplay(state, now_ms);
    }
}

/* Routes gameplay input: lane update, tap/hold attempts, and center-lane pause. */
static void G2_HandlePlayInput(G2_GameState *state, Direction dir, uint32_t now_ms)
{
    (void)dir;

    G2_UpdateSelectedLane(state);

    if (current_input.btn2_pressed != 0u) {
        if (state->selected_lane != 1u) {
            G2_HandleHitAttempt(state, now_ms);
        } else {
            if (state->active_hold != 0u) {
                G2_FailHold(state, now_ms);
            }
            G2_OpenPause(state, now_ms);
            return;
        }
    }

    if (current_input.btn3_pressed != 0u) {
        G2_HandleHitAttempt(state, now_ms);
    }
}

/* Handles pause menu movement and selected action execution. */
static void G2_HandlePauseInput(G2_GameState *state, Direction dir, uint32_t now_ms)
{
    if ((G2_IsDown(dir) && !G2_IsDown(state->last_direction)) || (G2_IsRight(dir) && !G2_IsRight(state->last_direction))) {
        state->pause_index = (uint8_t)((state->pause_index + 1u) % 3u);
    } else if ((G2_IsUp(dir) && !G2_IsUp(state->last_direction)) || (G2_IsLeft(dir) && !G2_IsLeft(state->last_direction))) {
        if (state->pause_index == 0u) {
            state->pause_index = 2u;
        } else {
            state->pause_index--;
        }
    }

    if (current_input.btn2_pressed != 0u) {
        G2_ResumeFromPause(state, now_ms);
        return;
    }

    if (current_input.btn3_pressed != 0u) {
        if (state->pause_index == 0u) {
            G2_ResumeFromPause(state, now_ms);
        } else if (state->pause_index == 1u) {
            G2_BeginCountdown(state, now_ms);
        } else {
            G2_RequestExit(state, now_ms);
        }
    }
}

/* Handles result screen Retry/Menu selection. */
static void G2_HandleResultInput(G2_GameState *state, Direction dir, uint32_t now_ms)
{
    if ((G2_IsRight(dir) && !G2_IsRight(state->last_direction)) || (G2_IsDown(dir) && !G2_IsDown(state->last_direction))) {
        state->result_index = 1u;
    } else if ((G2_IsLeft(dir) && !G2_IsLeft(state->last_direction)) || (G2_IsUp(dir) && !G2_IsUp(state->last_direction))) {
        state->result_index = 0u;
    }

    if (current_input.btn2_pressed != 0u) {
        G2_RequestExit(state, now_ms);
        return;
    }

    if (current_input.btn3_pressed != 0u) {
        if (state->result_index == 0u) {
            G2_BeginCountdown(state, now_ms);
        } else {
            G2_RequestExit(state, now_ms);
        }
    }
}

/*
 * Main Game 2 loop.
 * Each frame reads input, advances the active scene, updates feedback, renders the
 * current screen, refreshes the LCD, then delays to maintain a stable frame rate.
 */
MenuState G2_Core_Run(void)
{
    G2_GameState state;

    G2_ResetState(&state);
    LCD_Set_Palette(PALETTE_CUSTOM);

    while (state.scene != G2_SCENE_EXIT) {
        uint32_t frame_start = HAL_GetTick();
        uint32_t now_ms;
        Direction dir;

        Input_Read();
        Joystick_Read(&joystick_cfg, &joystick_data);
        dir = joystick_data.direction;
        now_ms = HAL_GetTick();

        if (state.scene == G2_SCENE_PLAY && state.chart != 0) {
            state.elapsed_ms = now_ms - state.play_start_ms;
            /* Catch up beat ticks if a frame runs long so the metronome stays aligned. */
            while (state.elapsed_ms >= state.next_beat_ms && state.next_beat_ms <= state.chart->song_length_ms) {
                uint8_t accent = (uint8_t)(((state.next_beat_ms / state.chart->beat_interval_ms) % 4u) == 0u);
                G2_Audio_PlayBeat(&state.audio, now_ms, accent);
                state.next_beat_ms += state.chart->beat_interval_ms;
            }

            G2_HandlePlayInput(&state, dir, now_ms);
            if (state.scene == G2_SCENE_PLAY) {
                G2_UpdateHoldState(&state, now_ms);
                G2_UpdateObstacles(&state, now_ms);
                G2_AutoMissExpiredNotes(&state, now_ms);
                if (G2_Chart_AllResolved(&state) != 0u && state.elapsed_ms > state.chart->song_length_ms) {
                    G2_ShowResult(&state, now_ms);
                }
            }
        } else if (state.scene == G2_SCENE_COUNTDOWN) {
            G2_HandleCountdownInput(&state, now_ms);
        } else if (state.scene == G2_SCENE_DIFFICULTY) {
            G2_HandleDifficultyInput(&state, dir, now_ms);
        } else if (state.scene == G2_SCENE_PAUSE) {
            G2_HandlePauseInput(&state, dir, now_ms);
        } else if (state.scene == G2_SCENE_RESULT) {
            G2_HandleResultInput(&state, dir, now_ms);
        }

        G2_Audio_Update(&state.audio, now_ms, state.scoring.combo, state.scoring.last_result);

        switch (state.scene) {
            case G2_SCENE_DIFFICULTY:
                G2_Render_DifficultyMenu(&state, now_ms);
                break;
            case G2_SCENE_COUNTDOWN:
                G2_Render_Countdown(&state, now_ms);
                break;
            case G2_SCENE_PLAY:
                G2_Render_Play(&state, now_ms);
                break;
            case G2_SCENE_PAUSE:
                G2_Render_Pause(&state);
                break;
            case G2_SCENE_RESULT:
                G2_Render_Result(&state);
                break;
            case G2_SCENE_EXIT:
            default:
                break;
        }

        LCD_Refresh(&cfg0);
        state.last_direction = dir;

        /* Simple fixed-frame pacing keeps rendering/input cadence predictable. */
        if ((HAL_GetTick() - frame_start) < G2_FRAME_TIME_MS) {
            HAL_Delay(G2_FRAME_TIME_MS - (HAL_GetTick() - frame_start));
        }
    }

    G2_Audio_StopAll(&state.audio);
    LCD_Set_Palette(PALETTE_DEFAULT);
    LCD_Fill_Buffer(0u);
    LCD_Refresh(&cfg0);

    return state.exit_state;
}

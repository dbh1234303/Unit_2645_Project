#ifndef G2_CHART_H
#define G2_CHART_H

#include "G2_Types.h"

/* Returns immutable chart data for a difficulty. */
const G2_Chart *G2_Chart_Get(G2_Difficulty difficulty);

/* Resets and checks per-note runtime state stored in G2_GameState. */
void G2_Chart_ResetRuntime(G2_GameState *state);
uint8_t G2_Chart_AllResolved(const G2_GameState *state);

#endif

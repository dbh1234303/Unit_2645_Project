#ifndef G2_ASSETS_H
#define G2_ASSETS_H

#include "G2_Types.h"

/*
 * Shared text assets for Game 2 menus and result screens.
 * The actual strings live in G2_Chart.c with the chart metadata.
 */
extern const char *const G2_DifficultyNames[G2_DIFF_COUNT];
extern const char *const G2_PauseItems[3];
extern const char *const G2_ResultItems[2];

#endif

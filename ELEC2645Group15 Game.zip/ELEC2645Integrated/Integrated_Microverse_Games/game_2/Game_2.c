#include "Game_2.h"
#include "G2_Core.h"

/*
 * Game 2 entry module.
 * Keeps the public Game2_Run symbol stable while delegating implementation to
 * the G2_Core state machine.
 */
MenuState Game2_Run(void)
{
    return G2_Core_Run();
}

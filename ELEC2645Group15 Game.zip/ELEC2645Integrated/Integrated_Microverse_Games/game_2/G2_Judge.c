#include "G2_Judge.h"

/*
 * Game 2 scoring and judgement module.
 * Converts timing results into combo, multiplier, score, accuracy, and labels.
 */

/* Combo thresholds are stored as tenths to avoid floating-point math on MCU. */
static uint8_t G2_Judge_MultiplierTenths(uint16_t combo)
{
    if (combo >= G2_FEVER_COMBO) return 20u;
    if (combo >= 20u) return 15u;
    if (combo >= 10u) return 12u;
    return 10u;
}

/* Applies the current combo multiplier to a base point value. */
static uint32_t G2_Judge_ScaledPoints(const G2_ScoreState *scoring, uint32_t base_points)
{
    uint8_t mult = scoring->multiplier_tenths;
    if (mult == 0u) {
        mult = 10u;
    }
    return (base_points * (uint32_t)mult + 5u) / 10u;
}

/* Refreshes multiplier and fever flags after combo changes. */
static void G2_Judge_UpdateBonusState(G2_ScoreState *scoring)
{
    scoring->multiplier_tenths = G2_Judge_MultiplierTenths(scoring->combo);
    scoring->fever_active = (scoring->combo >= G2_FEVER_COMBO) ? 1u : 0u;
}

/* Clears all scoring counters before a new run starts. */
void G2_Judge_Reset(G2_ScoreState *scoring)
{
    scoring->score = 0u;
    scoring->combo = 0u;
    scoring->max_combo = 0u;
    scoring->perfect_count = 0u;
    scoring->good_count = 0u;
    scoring->miss_count = 0u;
    scoring->hold_count = 0u;
    scoring->obstacle_clear_count = 0u;
    scoring->multiplier_tenths = 10u;
    scoring->fever_active = 0u;
    scoring->last_result = G2_JUDGE_NONE;
    scoring->last_result_ms = 0u;
}

/* Converts a signed timing delta into a judge bucket. */
G2_JudgeResult G2_Judge_FromDelta(int32_t delta_ms)
{
    if (delta_ms < 0) {
        delta_ms = -delta_ms;
    }

    if ((uint32_t)delta_ms <= G2_PERFECT_WINDOW_MS) {
        return G2_JUDGE_PERFECT;
    }
    if ((uint32_t)delta_ms <= G2_GOOD_WINDOW_MS) {
        return G2_JUDGE_GOOD;
    }
    return G2_JUDGE_MISS;
}

/*
 * Applies one resolved note result.
 * Perfect/Good extend combo and scale points; Miss resets the combo state.
 */
void G2_Judge_Apply(G2_ScoreState *scoring, G2_JudgeResult result, uint32_t now_ms)
{
    scoring->last_result = result;
    scoring->last_result_ms = now_ms;

    switch (result) {
        case G2_JUDGE_PERFECT:
            scoring->perfect_count++;
            scoring->combo++;
            G2_Judge_UpdateBonusState(scoring);
            scoring->score += G2_Judge_ScaledPoints(scoring, 300u + (uint32_t)(scoring->combo * 6u));
            break;

        case G2_JUDGE_GOOD:
            scoring->good_count++;
            scoring->combo++;
            G2_Judge_UpdateBonusState(scoring);
            scoring->score += G2_Judge_ScaledPoints(scoring, 160u + (uint32_t)(scoring->combo * 4u));
            break;

        case G2_JUDGE_DODGE:
            scoring->obstacle_clear_count++;
            scoring->score += G2_Judge_ScaledPoints(scoring, 50u);
            break;

        case G2_JUDGE_MISS:
        default:
            scoring->miss_count++;
            scoring->combo = 0u;
            scoring->multiplier_tenths = 10u;
            scoring->fever_active = 0u;
            break;
    }

    if (scoring->combo > scoring->max_combo) {
        scoring->max_combo = scoring->combo;
    }
}

/* Adds bonus points, currently used when a hold note is completed. */
void G2_Judge_AddBonus(G2_ScoreState *scoring, uint16_t base_points)
{
    scoring->score += G2_Judge_ScaledPoints(scoring, base_points);
}

/* Returns the number of timing notes judged, excluding obstacle dodges. */
uint16_t G2_Judge_TotalJudged(const G2_ScoreState *scoring)
{
    return (uint16_t)(scoring->perfect_count + scoring->good_count + scoring->miss_count);
}

/*
 * Computes accuracy as percentage x10, e.g. 987 means 98.7%.
 * Perfect contributes 100%, Good contributes 65%, Miss contributes 0%.
 */
uint32_t G2_Judge_AccuracyX10(const G2_ScoreState *scoring)
{
    uint32_t total = (uint32_t)G2_Judge_TotalJudged(scoring);
    uint32_t weighted;

    if (total == 0u) {
        return 0u;
    }

    weighted = (uint32_t)scoring->perfect_count * 1000u + (uint32_t)scoring->good_count * 650u;
    return weighted / total;
}

/* Maps judge enum values to short labels rendered on the HUD. */
const char *G2_Judge_Label(G2_JudgeResult result)
{
    switch (result) {
        case G2_JUDGE_PERFECT:
            return "PERFECT";
        case G2_JUDGE_GOOD:
            return "GOOD";
        case G2_JUDGE_MISS:
            return "MISS";
        case G2_JUDGE_DODGE:
            return "DODGE";
        case G2_JUDGE_NONE:
        default:
            return "READY";
    }
}

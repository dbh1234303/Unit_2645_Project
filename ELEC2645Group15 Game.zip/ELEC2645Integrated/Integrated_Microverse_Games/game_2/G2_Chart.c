#include "G2_Chart.h"
#include "G2_Assets.h"
#include <string.h>

/*
 * Game 2 chart module.
 * Stores static note charts and menu labels; runtime code reads these tables
 * through small accessors so note data stays immutable.
 */

/* Helper macros keep chart rows compact: time, lane, optional hold duration. */
#define G2_TAP(t, l)         { (t), 0u, (l), G2_NOTE_TAP, 0u }
#define G2_TAP_ACC(t, l)     { (t), 0u, (l), G2_NOTE_TAP, 1u }
#define G2_HOLD(t, l, d)     { (t), (d), (l), G2_NOTE_HOLD, 0u }
#define G2_HOLD_ACC(t, l, d) { (t), (d), (l), G2_NOTE_HOLD, 1u }
#define G2_OBS(t, l)         { (t), 0u, (l), G2_NOTE_OBSTACLE, 0u }
#define G2_OBS_ACC(t, l)     { (t), 0u, (l), G2_NOTE_OBSTACLE, 1u }

/* Text assets shared by render/input code for difficulty and submenu labels. */
const char *const G2_DifficultyNames[G2_DIFF_COUNT] = {
    "Practice",
    "Standard",
    "Frenzy"
};

const char *const G2_PauseItems[3] = {
    "Resume",
    "Restart",
    "Return Menu"
};

const char *const G2_ResultItems[2] = {
    "Retry",
    "Menu"
};

/* Practice chart: slower timing windows and a small mix of tap/hold/obstacle notes. */
static const G2_NoteEvent practice_notes[] = {
    G2_TAP_ACC(1200, 1), G2_TAP(1800, 0), G2_HOLD_ACC(2400, 1, 900), G2_OBS(3300, 1),
    G2_TAP(3900, 2), G2_TAP(4500, 0), G2_OBS_ACC(5100, 0), G2_TAP_ACC(5700, 2),
    G2_HOLD(6300, 2, 800), G2_OBS(7300, 2), G2_TAP(7900, 1), G2_TAP_ACC(8500, 0),
    G2_HOLD_ACC(9100, 1, 900), G2_OBS(10100, 1), G2_TAP(10700, 2), G2_TAP_ACC(11300, 1),
    G2_TAP(11900, 0), G2_OBS_ACC(12500, 2), G2_HOLD(13100, 0, 850), G2_TAP_ACC(14100, 2),
    G2_OBS(14700, 0), G2_TAP(15300, 1), G2_TAP(15900, 2), G2_HOLD_ACC(16500, 1, 900),
    G2_OBS_ACC(17500, 1), G2_TAP(18100, 0), G2_TAP_ACC(18700, 2), G2_OBS(19300, 0),
    G2_HOLD_ACC(19900, 2, 850), G2_TAP(21000, 1), G2_OBS(21600, 2), G2_TAP_ACC(22200, 1)
};

/* Standard chart: main balanced chart used for normal play. */
static const G2_NoteEvent standard_notes[] = {
    G2_TAP_ACC(1000, 1), G2_TAP(1450, 0), G2_TAP(1900, 2), G2_OBS(2350, 1),
    G2_HOLD_ACC(2800, 0, 900), G2_TAP(3400, 2), G2_TAP(3850, 1), G2_OBS_ACC(4300, 2),
    G2_TAP(4750, 0), G2_HOLD(5200, 1, 700), G2_TAP_ACC(5700, 2), G2_OBS(6150, 0),
    G2_TAP(6600, 1), G2_TAP(7050, 2), G2_HOLD_ACC(7500, 0, 850), G2_OBS(8200, 1),
    G2_TAP(8650, 2), G2_TAP_ACC(9100, 1), G2_OBS(9550, 2), G2_HOLD(10000, 2, 700),
    G2_TAP(10450, 0), G2_TAP_ACC(10900, 1), G2_OBS_ACC(11350, 0), G2_TAP(11800, 2),
    G2_HOLD_ACC(12250, 1, 800), G2_OBS(12900, 1), G2_TAP(13350, 0), G2_TAP_ACC(13800, 2),
    G2_TAP(14250, 1), G2_OBS_ACC(14700, 2), G2_HOLD(15150, 0, 850), G2_TAP(15750, 1),
    G2_TAP_ACC(16200, 2), G2_OBS(16650, 0), G2_TAP(17100, 1), G2_HOLD_ACC(17550, 2, 800),
    G2_TAP(18150, 0), G2_OBS_ACC(18600, 1), G2_TAP_ACC(19050, 2), G2_TAP(19500, 1),
    G2_HOLD(19950, 0, 750), G2_OBS(20600, 2), G2_TAP(21050, 1), G2_TAP_ACC(21500, 0),
    G2_OBS_ACC(21950, 0), G2_TAP(22400, 2), G2_HOLD_ACC(22850, 1, 900), G2_TAP_ACC(24000, 2)
};

/* Frenzy chart: denser note spacing and faster scroll timing. */
static const G2_NoteEvent frenzy_notes[] = {
    G2_TAP_ACC(800, 1), G2_TAP(1120, 0), G2_TAP(1440, 2), G2_OBS(1760, 1),
    G2_HOLD_ACC(2080, 0, 650), G2_TAP(2440, 2), G2_TAP(2760, 1), G2_OBS_ACC(3080, 2),
    G2_TAP(3400, 0), G2_HOLD(3720, 1, 550), G2_TAP_ACC(4080, 2), G2_OBS(4400, 0),
    G2_TAP(4720, 1), G2_TAP(5040, 2), G2_OBS_ACC(5360, 1), G2_HOLD_ACC(5680, 2, 650),
    G2_TAP(6040, 0), G2_TAP(6360, 1), G2_OBS(6680, 2), G2_TAP_ACC(7000, 0),
    G2_HOLD(7320, 1, 500), G2_TAP(7680, 2), G2_OBS_ACC(8000, 0), G2_TAP(8320, 1),
    G2_TAP_ACC(8640, 2), G2_OBS(8960, 1), G2_HOLD_ACC(9280, 0, 600), G2_TAP(9640, 2),
    G2_TAP(9960, 1), G2_OBS_ACC(10280, 2), G2_TAP(10600, 0), G2_HOLD(10920, 2, 650),
    G2_TAP_ACC(11280, 1), G2_OBS(11600, 0), G2_TAP(11920, 2), G2_TAP_ACC(12240, 1),
    G2_OBS_ACC(12560, 1), G2_HOLD_ACC(12880, 0, 700), G2_TAP(13240, 2), G2_TAP_ACC(13560, 1),
    G2_TAP(13880, 0), G2_OBS(14200, 2), G2_TAP_ACC(14520, 1), G2_HOLD(14840, 2, 600),
    G2_TAP(15200, 0), G2_OBS_ACC(15520, 1), G2_TAP(15840, 2), G2_TAP_ACC(16160, 0),
    G2_HOLD_ACC(16480, 1, 650), G2_OBS(16840, 0), G2_TAP(17160, 2), G2_TAP(17480, 1),
    G2_TAP_ACC(17800, 0), G2_OBS_ACC(18120, 2), G2_HOLD(18440, 0, 600), G2_TAP(18800, 1),
    G2_TAP_ACC(19120, 2), G2_OBS(19440, 1), G2_TAP(19760, 0), G2_HOLD_ACC(20080, 2, 700),
    G2_TAP(20440, 1), G2_OBS_ACC(20760, 0), G2_TAP_ACC(21080, 2), G2_TAP(21400, 1)
};

/* Metadata ties each difficulty to BPM, scroll speed, length, and note table. */
static const G2_Chart charts[G2_DIFF_COUNT] = {
    {
        .name = "Pulse Orbit / Practice",
        .bpm = 100,
        .beat_interval_ms = 600,
        .scroll_time_ms = 1500,
        .song_length_ms = 23800,
        .note_count = (uint16_t)(sizeof(practice_notes) / sizeof(practice_notes[0])),
        .notes = practice_notes
    },
    {
        .name = "Pulse Orbit / Standard",
        .bpm = 124,
        .beat_interval_ms = 480,
        .scroll_time_ms = 1360,
        .song_length_ms = 26000,
        .note_count = (uint16_t)(sizeof(standard_notes) / sizeof(standard_notes[0])),
        .notes = standard_notes
    },
    {
        .name = "Pulse Orbit / Frenzy",
        .bpm = 156,
        .beat_interval_ms = 385,
        .scroll_time_ms = 1220,
        .song_length_ms = 24600,
        .note_count = (uint16_t)(sizeof(frenzy_notes) / sizeof(frenzy_notes[0])),
        .notes = frenzy_notes
    }
};

/* Returns a valid chart for the requested difficulty, falling back to Practice. */
const G2_Chart *G2_Chart_Get(G2_Difficulty difficulty)
{
    if ((uint32_t)difficulty >= G2_DIFF_COUNT) {
        return &charts[G2_DIFF_PRACTICE];
    }
    return &charts[difficulty];
}

/* Resets per-note runtime flags without touching the immutable chart data. */
void G2_Chart_ResetRuntime(G2_GameState *state)
{
    memset(state->note_state, 0, sizeof(state->note_state));
}

/* Checks whether every note/obstacle in the active chart has been processed. */
uint8_t G2_Chart_AllResolved(const G2_GameState *state)
{
    uint16_t i;

    if (state->chart == 0) {
        return 1u;
    }

    for (i = 0u; i < state->chart->note_count; ++i) {
        if (state->note_state[i] != G2_NOTE_STATE_RESOLVED) {
            return 0u;
        }
    }

    return 1u;
}

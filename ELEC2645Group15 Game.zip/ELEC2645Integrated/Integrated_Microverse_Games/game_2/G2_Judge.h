#ifndef G2_JUDGE_H
#define G2_JUDGE_H

#include <stdint.h>
#include "G2_Types.h"

/* Scoring state setup and note-result application. */
void G2_Judge_Reset(G2_ScoreState *scoring);
G2_JudgeResult G2_Judge_FromDelta(int32_t delta_ms);
void G2_Judge_Apply(G2_ScoreState *scoring, G2_JudgeResult result, uint32_t now_ms);
void G2_Judge_AddBonus(G2_ScoreState *scoring, uint16_t base_points);

/* Result-screen helpers for accuracy, totals, and display labels. */
uint32_t G2_Judge_AccuracyX10(const G2_ScoreState *scoring);
uint16_t G2_Judge_TotalJudged(const G2_ScoreState *scoring);
const char *G2_Judge_Label(G2_JudgeResult result);

#endif

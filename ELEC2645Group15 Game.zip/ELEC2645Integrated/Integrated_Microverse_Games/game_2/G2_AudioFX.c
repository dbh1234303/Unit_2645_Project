#include "G2_AudioFX.h"
#include "Buzzer.h"
#include "PWM.h"
#include "main.h"

/*
 * Game 2 audio/light effects module.
 * Encapsulates buzzer tones, LED feedback, and PWM brightness so the core
 * gameplay state machine only needs to request semantic events such as beat,
 * judge result, or combo pulse.
 */
extern Buzzer_cfg_t buzzer_cfg;
extern PWM_cfg_t pwm_cfg;

/* Maps the current combo to the base LED PWM duty cycle. */
static uint8_t G2_ComboBrightness(uint16_t combo)
{
    if (combo >= G2_FEVER_COMBO) return 100u;
    if (combo >= 20u) return 84u;
    if (combo >= 12u) return 68u;
    if (combo >= 6u)  return 46u;
    if (combo >= 1u)  return 22u;
    return 0u;
}

/* Starts a buzzer tone and records when it should be turned off. */
static void G2_PlayTimedTone(G2_AudioState *audio, uint32_t now_ms, uint32_t freq_hz, uint8_t volume, uint16_t duration_ms)
{
    buzzer_tone(&buzzer_cfg, freq_hz, volume);
    audio->buzzer_active = 1u;
    audio->buzzer_stop_ms = now_ms + duration_ms;
}

/* Initializes all transient audio and LED state before entering Game 2. */
void G2_Audio_Init(G2_AudioState *audio)
{
    audio->buzzer_active = 0u;
    audio->buzzer_stop_ms = 0u;
    audio->led_flash_until_ms = 0u;
    audio->combo_pulse_until_ms = 0u;
    PWM_SetDuty(&pwm_cfg, 0u);
    HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
    buzzer_off(&buzzer_cfg);
}

/*
 * Runs once per frame to stop expired tones and update LED/PWM effects.
 * Visual priority is combo pulse > result flash > steady combo indicator.
 */
void G2_Audio_Update(G2_AudioState *audio, uint32_t now_ms, uint16_t combo, G2_JudgeResult last_result)
{
    uint8_t duty = G2_ComboBrightness(combo);

    /* Turn off short sound effects without blocking the main loop. */
    if (audio->buzzer_active != 0u && now_ms >= audio->buzzer_stop_ms) {
        buzzer_off(&buzzer_cfg);
        audio->buzzer_active = 0u;
    }

    /* Fever combo deliberately alternates brightness to make the state obvious. */
    if (combo >= G2_FEVER_COMBO) {
        duty = (uint8_t)(((now_ms / 70u) & 1u) ? 100u : 72u);
    }

    /* Combo pulses override result flashes so milestone feedback is not hidden. */
    if (audio->combo_pulse_until_ms > now_ms) {
        duty = (uint8_t)(((now_ms / 45u) & 1u) ? 100u : duty);
        HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, ((now_ms / 45u) & 1u) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    } else if (audio->led_flash_until_ms > now_ms) {
        if (last_result == G2_JUDGE_MISS) {
            HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, (now_ms & 0x60u) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        } else {
            HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
        }
    } else {
        HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, (combo >= 10u) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }

    PWM_SetDuty(&pwm_cfg, duty);
}

/* Plays the short confirmation cue used by countdown/game start. */
void G2_Audio_PlayStart(G2_AudioState *audio, uint32_t now_ms)
{
    G2_PlayTimedTone(audio, now_ms, NOTE_C5, 30u, 90u);
    audio->led_flash_until_ms = now_ms + 90u;
}

/* Plays lightweight metronome ticks; accented beats use a brighter tone. */
void G2_Audio_PlayBeat(G2_AudioState *audio, uint32_t now_ms, uint8_t accent)
{

    if (audio->buzzer_active != 0u && audio->buzzer_stop_ms > now_ms) {
        return;
    }

    if (accent != 0u) {
        G2_PlayTimedTone(audio, now_ms, NOTE_A5, 16u, 28u);
    } else {
        G2_PlayTimedTone(audio, now_ms, NOTE_E5, 10u, 18u);
    }
}

/* Chooses the tone/flash pattern for each judge result and combo milestone. */
void G2_Audio_PlayJudge(G2_AudioState *audio, uint32_t now_ms, G2_JudgeResult result, uint16_t combo)
{
    switch (result) {
        case G2_JUDGE_PERFECT:
            /* Larger combo milestones receive longer pulses to reward streaks. */
            if (combo != 0u && ((combo % G2_FEVER_COMBO) == 0u)) {
                G2_PlayTimedTone(audio, now_ms, NOTE_E6, 56u, 110u);
                audio->combo_pulse_until_ms = now_ms + 360u;
                audio->led_flash_until_ms = now_ms + 260u;
            } else if (combo != 0u && ((combo % 10u) == 0u)) {
                G2_PlayTimedTone(audio, now_ms, NOTE_E6, 48u, 90u);
                audio->combo_pulse_until_ms = now_ms + 260u;
                audio->led_flash_until_ms = now_ms + 200u;
            } else if (combo >= 5u && (combo % 5u) == 0u) {
                G2_PlayTimedTone(audio, now_ms, NOTE_C6, 40u, 75u);
                audio->combo_pulse_until_ms = now_ms + 180u;
                audio->led_flash_until_ms = now_ms + 140u;
            } else {
                G2_PlayTimedTone(audio, now_ms, NOTE_C6, (combo >= 12u) ? 38u : 28u, 55u);
                audio->led_flash_until_ms = now_ms + 100u;
            }
            break;

        case G2_JUDGE_GOOD:
            if (combo != 0u && ((combo % 10u) == 0u)) {
                G2_PlayTimedTone(audio, now_ms, NOTE_D6, 42u, 80u);
                audio->combo_pulse_until_ms = now_ms + 220u;
                audio->led_flash_until_ms = now_ms + 170u;
            } else {
                G2_PlayTimedTone(audio, now_ms, NOTE_G5, 24u, 45u);
                audio->led_flash_until_ms = now_ms + 80u;
            }
            break;

        case G2_JUDGE_DODGE:
            G2_PlayTimedTone(audio, now_ms, NOTE_A5, 18u, 34u);
            audio->led_flash_until_ms = now_ms + 70u;
            break;

        case G2_JUDGE_MISS:
        default:
            G2_PlayTimedTone(audio, now_ms, NOTE_D4, 32u, 90u);
            audio->led_flash_until_ms = now_ms + 220u;
            audio->combo_pulse_until_ms = 0u;
            break;
    }
}

/* Clears every active audio/light effect when leaving or resetting gameplay. */
void G2_Audio_StopAll(G2_AudioState *audio)
{
    audio->buzzer_active = 0u;
    audio->buzzer_stop_ms = 0u;
    audio->led_flash_until_ms = 0u;
    audio->combo_pulse_until_ms = 0u;
    buzzer_off(&buzzer_cfg);
    PWM_SetDuty(&pwm_cfg, 0u);
    HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
}

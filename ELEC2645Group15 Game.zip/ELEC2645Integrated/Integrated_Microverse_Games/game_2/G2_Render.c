#include "G2_Render.h"
#include "G2_Assets.h"
#include "G2_Judge.h"
#include "LCD.h"
#include <stdio.h>

/*
 * Game 2 rendering module.
 * Draws all screens into the LCD back buffer: menus, countdown, playfield,
 * notes, HUD, pause overlay, and results.
 */

/* Pixel centers for the three rhythm lanes. */
static const uint16_t g_lane_centers[G2_LANE_COUNT] = {
    G2_LANE_CENTER_LEFT,
    G2_LANE_CENTER_MID,
    G2_LANE_CENTER_RIGHT
};

/* Full lane names are used in the HUD; short names fit compact selectors. */
static const char *const g_lane_names[G2_LANE_COUNT] = {
    "LEFT",
    "CENTER",
    "RIGHT"
};

static const char *const g_lane_short[G2_LANE_COUNT] = {
    "L",
    "C",
    "R"
};

/* Draws a small bordered UI panel with an optional inner outline. */
static void G2_DrawPanel(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t fill, uint8_t border)
{
    LCD_Draw_Rect(x, y, w, h, fill, 1u);
    LCD_Draw_Rect(x, y, w, h, border, 0u);
    if (w > 6u && h > 6u) {
        LCD_Draw_Rect((uint16_t)(x + 2u), (uint16_t)(y + 2u), (uint16_t)(w - 4u), (uint16_t)(h - 4u), border, 0u);
    }
}

/* Draws animated corner and status markers around the screen frame. */
static void G2_DrawFrameMarkers(uint8_t accent, uint8_t alt, uint32_t now_ms)
{
    uint8_t pulse = (uint8_t)(((now_ms / 220u) & 1u) ? accent : alt);

    LCD_Draw_Line(8u, 8u, 24u, 8u, accent);
    LCD_Draw_Line(8u, 8u, 8u, 24u, accent);
    LCD_Draw_Line(216u, 8u, 232u, 8u, accent);
    LCD_Draw_Line(232u, 8u, 232u, 24u, accent);
    LCD_Draw_Line(8u, 232u, 24u, 232u, alt);
    LCD_Draw_Line(8u, 216u, 8u, 232u, alt);
    LCD_Draw_Line(216u, 232u, 232u, 232u, alt);
    LCD_Draw_Line(232u, 216u, 232u, 232u, alt);

    LCD_Draw_Rect(206u, 14u, 18u, 4u, pulse, 1u);
    LCD_Draw_Rect(16u, 222u, 18u, 4u, alt, 1u);
}

/* Draws the scrolling grid-style background; alert mode brightens accents. */
static void G2_DrawBackdrop(uint32_t now_ms, uint8_t alert)
{
    uint8_t i;
    uint8_t line_colour = alert ? 8u : 13u;
    uint8_t accent = alert ? 10u : 14u;
    uint16_t phase = (uint16_t)((now_ms / 220u) & 1u);

    for (i = 0u; i < 6u; ++i) {
        uint16_t y = (uint16_t)(58u + i * 26u + phase);
        LCD_Draw_Line(18u, y, 222u, y, (i == 0u || i == 5u) ? accent : line_colour);
    }

    for (i = 0u; i < 4u; ++i) {
        uint16_t x = (uint16_t)(40u + i * 40u);
        LCD_Draw_Line(x, 74u, x, 214u, 8u);
    }

    LCD_Draw_Rect(14u, 14u, 212u, 14u, 0u, 0u);
    LCD_Draw_Line(14u, 28u, 226u, 28u, accent);
    LCD_Draw_Line(14u, 214u, 226u, 214u, line_colour);
}

/* Decorative equalizer ticks used to show activity around the frame. */
static void G2_DrawTelemetryTicks(uint32_t now_ms, uint8_t hot)
{
    uint8_t i;
    uint8_t phase = (uint8_t)((now_ms / 180u) % 6u);

    for (i = 0u; i < 6u; ++i) {
        uint8_t colour = (i == phase) ? (hot ? 10u : 14u) : 13u;
        uint16_t x = (uint16_t)(24u + i * 32u);
        LCD_Draw_Rect(x, 4u, 18u, 2u, colour, 1u);
        LCD_Draw_Rect(x, 234u, 18u, 2u, 8u, 1u);
    }
}

/* Clears the buffer and builds the common Game 2 frame shell. */
static void G2_DrawFrame(uint8_t combo_glow, uint32_t now_ms)
{
    uint8_t pulse = (uint8_t)(((now_ms / 220u) & 1u) ? 1u : 0u);
    uint8_t accent = combo_glow ? (pulse ? 10u : 14u) : 14u;
    uint8_t alt = combo_glow ? 8u : 13u;

    LCD_Fill_Buffer(0u);
    G2_DrawBackdrop(now_ms, combo_glow);
    LCD_Draw_Rect(2u, 2u, 236u, 236u, 13u, 0u);
    LCD_Draw_Rect(6u, 6u, 228u, 228u, alt, 0u);
    LCD_Draw_Line(14u, 30u, 226u, 30u, accent);
    LCD_Draw_Line(14u, 216u, 226u, 216u, alt);
    G2_DrawFrameMarkers(accent, alt, now_ms);
    G2_DrawTelemetryTicks(now_ms, combo_glow);
}

/* Small menu/result sparkles that blink based on time. */
static void G2_DrawSparkles(uint32_t now_ms)
{
    static const uint16_t xs[6] = {22u, 44u, 196u, 218u, 26u, 214u};
    static const uint16_t ys[6] = {18u, 18u, 18u, 18u, 222u, 222u};
    uint8_t i;

    for (i = 0u; i < 6u; ++i) {
        uint8_t on = (uint8_t)((((now_ms / 180u) + i) & 1u) != 0u);
        uint8_t colour = on ? ((i < 4u) ? 14u : 8u) : 13u;
        LCD_Draw_Rect(xs[i], ys[i], 2u, 2u, colour, 1u);
    }
}

/* Centers a monospaced LCD string horizontally on the 240px screen. */
static void G2_PrintCentered(const char *text, uint16_t y, uint8_t colour, uint8_t size)
{
    uint16_t len = 0u;
    uint16_t width;

    while (text[len] != '\0') {
        ++len;
    }

    width = (uint16_t)(len * 6u * size);
    if (width > 240u) {
        width = 240u;
    }

    LCD_printString(text, (uint16_t)((240u - width) / 2u), y, colour, size);
}

/* Prints a title with a one-pixel animated shadow for arcade styling. */
static void G2_PrintArcadeTitle(const char *text, uint16_t y, uint8_t size, uint32_t now_ms)
{
    uint8_t accent = (uint8_t)(((now_ms / 260u) & 1u) ? 14u : 8u);
    G2_PrintCentered(text, (uint16_t)(y + 1u), accent, size);
    G2_PrintCentered(text, y, 1u, size);
}

/* Safely converts a lane index to its screen X coordinate. */
static uint16_t G2_LaneCenter(uint8_t lane)
{
    if (lane >= G2_LANE_COUNT) {
        return G2_LANE_CENTER_MID;
    }
    return g_lane_centers[lane];
}

/* Chooses the display colour for the latest judgement label. */
static uint8_t G2_JudgeColour(G2_JudgeResult result)
{
    switch (result) {
        case G2_JUDGE_PERFECT:
            return 10u;
        case G2_JUDGE_GOOD:
            return 6u;
        case G2_JUDGE_MISS:
            return 2u;
        case G2_JUDGE_DODGE:
            return 3u;
        case G2_JUDGE_NONE:
        default:
            return 14u;
    }
}

/*
 * Converts a chart timestamp into the current screen Y position.
 * Keep this integer-only so frame pacing stays stable on the target MCU.
 */
static int32_t G2_YForTime(const G2_GameState *state, uint32_t hit_time_ms)
{
    int32_t spawn_time;
    int32_t t;

    if (state->chart == 0) {
        return -1000;
    }

    spawn_time = (int32_t)hit_time_ms - (int32_t)state->chart->scroll_time_ms;
    t = (int32_t)state->elapsed_ms - spawn_time;

    return G2_NOTE_SPAWN_Y + (t * (int32_t)(G2_HIT_LINE_Y - G2_NOTE_SPAWN_Y)) / (int32_t)state->chart->scroll_time_ms;
}

/*
 * Looks ahead for obstacle notes in one lane and returns a small warning level.
 * 0 = quiet, 1 = incoming, 2 = immediate danger around the hit line.
 */
static uint8_t G2_LaneDangerLevel(const G2_GameState *state, uint8_t lane)
{
    uint16_t i;
    uint8_t level = 0u;

    if (state->chart == 0) {
        return 0u;
    }

    for (i = 0u; i < state->chart->note_count; ++i) {
        const G2_NoteEvent *note = &state->chart->notes[i];
        int32_t delta;

        if (state->note_state[i] != G2_NOTE_STATE_PENDING || note->type != G2_NOTE_OBSTACLE || note->lane != lane) {
            continue;
        }

        delta = (int32_t)note->hit_time_ms - (int32_t)state->elapsed_ms;
        if (delta >= 0 && (uint32_t)delta <= G2_OBSTACLE_WARNING_MS) {
            level = 1u;
        }
        if (delta >= -(int32_t)G2_OBSTACLE_WINDOW_MS && delta <= (int32_t)(G2_OBSTACLE_WINDOW_MS + 35u)) {
            return 2u;
        }
    }

    return level;
}

/* Renders obstacle warning indicators above and around one lane. */
static void G2_DrawLaneWarning(uint16_t center, uint8_t level, uint8_t pulse)
{
    uint8_t colour;

    if (level == 0u) {
        return;
    }

    colour = (level >= 2u) ? 2u : (pulse ? 6u : 10u);


    G2_DrawPanel((uint16_t)(center - 15u), 52u, 30u, 16u, 0u, colour);
    LCD_printString("D!", (uint16_t)(center - 6u), 56u, colour, 1u);
    LCD_Draw_Line((uint16_t)(center - 12u), 72u, center, 82u, colour);
    LCD_Draw_Line((uint16_t)(center + 12u), 72u, center, 82u, colour);
    LCD_Draw_Line((uint16_t)(center - 12u), 72u, (uint16_t)(center + 12u), 72u, colour);

    if (level >= 2u) {
        LCD_Draw_Rect((uint16_t)(center - 18u), (uint16_t)(G2_HIT_LINE_Y - 14u), 36u, 28u, colour, 0u);
        LCD_Draw_Line((uint16_t)(center - 24u), G2_HIT_LINE_Y, (uint16_t)(center - 19u), G2_HIT_LINE_Y, colour);
        LCD_Draw_Line((uint16_t)(center + 19u), G2_HIT_LINE_Y, (uint16_t)(center + 24u), G2_HIT_LINE_Y, colour);
    }
}

/* Draws lane rails, selected-lane glow, hit line, and danger warning UI. */
static void G2_DrawLaneGuide(const G2_GameState *state, uint32_t now_ms)
{
    uint8_t lane;
    uint8_t pulse = (uint8_t)(((now_ms / 150u) & 1u) ? 1u : 0u);

    for (lane = 0u; lane < G2_LANE_COUNT; ++lane) {
        uint16_t center = G2_LaneCenter(lane);
        uint16_t x = (uint16_t)(center - 25u);
        uint8_t selected = (lane == state->selected_lane) ? 1u : 0u;
        uint8_t level = G2_LaneDangerLevel(state, lane);
        uint8_t rail = selected ? (state->scoring.fever_active ? 10u : 14u) : 13u;
        uint8_t glow = selected ? (pulse ? rail : 8u) : 8u;
        uint16_t lane_h = (uint16_t)(G2_PLAYFIELD_BOTTOM - G2_PLAYFIELD_TOP - 20u);

        LCD_Draw_Rect(x, (uint16_t)(G2_PLAYFIELD_TOP + 8u), 50u, lane_h, 0u, 0u);
        LCD_Draw_Rect(x, (uint16_t)(G2_PLAYFIELD_TOP + 8u), 50u, lane_h, selected ? glow : 13u, 0u);
        LCD_Draw_Rect((uint16_t)(x + 4u), (uint16_t)(G2_PLAYFIELD_TOP + 12u), 42u, (uint16_t)(lane_h - 8u), 0u, 0u);
        LCD_Draw_Line(center, (uint16_t)(G2_PLAYFIELD_TOP + 12u), center, (uint16_t)(G2_PLAYFIELD_BOTTOM - 18u), rail);
        LCD_Draw_Line((uint16_t)(center - 16u), 122u, (uint16_t)(center + 16u), 122u, selected ? rail : 8u);
        LCD_Draw_Line((uint16_t)(center - 19u), G2_HIT_LINE_Y, (uint16_t)(center + 19u), G2_HIT_LINE_Y, selected ? 1u : 13u);

        G2_DrawPanel((uint16_t)(center - 15u), 36u, 30u, 14u, selected ? rail : 0u, selected ? rail : 13u);
        LCD_printString(g_lane_short[lane], (uint16_t)(center - 3u), 39u, selected ? 0u : 1u, 1u);

        if (selected != 0u) {
            LCD_Draw_Rect((uint16_t)(center - 18u), 199u, 36u, 13u, rail, 0u);
            LCD_Draw_Line((uint16_t)(center - 12u), 197u, center, 190u, rail);
            LCD_Draw_Line((uint16_t)(center + 12u), 197u, center, 190u, rail);
        }

        G2_DrawLaneWarning(center, level, pulse);
    }

    LCD_Draw_Rect(22u, (uint16_t)(G2_HIT_LINE_Y - 2u), 196u, 4u, 6u, 1u);
    LCD_Draw_Rect(22u, (uint16_t)(G2_HIT_LINE_Y + 4u), 196u, 1u, 14u, 1u);

    for (lane = 0u; lane < G2_LANE_COUNT; ++lane) {
        uint16_t center = G2_LaneCenter(lane);
        uint8_t selected = (lane == state->selected_lane) ? 1u : 0u;
        uint8_t fill = selected ? (state->scoring.fever_active ? 10u : 14u) : 0u;
        uint8_t border = selected ? fill : 13u;
        G2_DrawPanel((uint16_t)(center - 17u), 220u, 34u, 15u, fill, border);
        LCD_printString(g_lane_short[lane], (uint16_t)(center - 3u), 224u, selected ? 0u : 13u, 1u);
    }
}

/* Draws the circular head used by tap notes and the start of hold notes. */
static void G2_DrawTapOrHoldHead(const G2_NoteEvent *note, uint16_t x, uint16_t y)
{
    uint8_t fill_colour;
    uint8_t ring_colour;
    uint8_t glow_colour;

    if (note->type == G2_NOTE_HOLD) {
        fill_colour = note->accent ? 10u : 6u;
        ring_colour = 1u;
        glow_colour = 14u;
    } else {
        fill_colour = note->accent ? 10u : 4u;
        ring_colour = 1u;
        glow_colour = note->accent ? 6u : 14u;
    }

    LCD_Draw_Circle(x, y, (uint16_t)(G2_NOTE_RADIUS + 5u), glow_colour, 0u);
    LCD_Draw_Circle(x, y, (uint16_t)(G2_NOTE_RADIUS + 2u), 1u, 0u);
    LCD_Draw_Circle(x, y, G2_NOTE_RADIUS, fill_colour, 1u);
    LCD_Draw_Circle(x, y, (uint16_t)(G2_NOTE_RADIUS + 1u), ring_colour, 0u);
    LCD_Draw_Rect((uint16_t)(x - 2u), (uint16_t)(y - 5u), 4u, 4u, 1u, 1u);
}

/* Draws an obstacle marker that the player must avoid by switching lanes. */
static void G2_DrawObstacle(uint16_t x, uint16_t y, uint8_t accent)
{
    uint16_t left = (uint16_t)(x - 18u);
    uint16_t top = (uint16_t)(y - 9u);
    uint8_t colour = accent ? 2u : 12u;

    LCD_Draw_Rect((uint16_t)(left - 2u), (uint16_t)(top - 2u), 40u, 20u, colour, 0u);
    LCD_Draw_Rect(left, top, 36u, 18u, 0u, 1u);
    LCD_Draw_Rect(left, top, 36u, 18u, colour, 0u);
    LCD_Draw_Line(left, top, (uint16_t)(left + 35u), (uint16_t)(top + 17u), colour);
    LCD_Draw_Line((uint16_t)(left + 35u), top, left, (uint16_t)(top + 17u), colour);
    LCD_Draw_Line((uint16_t)(left + 6u), (uint16_t)(top + 9u), (uint16_t)(left + 29u), (uint16_t)(top + 9u), colour);
}

/* Draws the tap/hold/avoid legend shown during menu and tutorial moments. */
static void G2_DrawLegend(uint16_t y)
{
    G2_DrawPanel(18u, y, 204u, 30u, 0u, 13u);
    LCD_Draw_Circle(32u, (uint16_t)(y + 15u), 6u, 4u, 1u);
    LCD_Draw_Circle(32u, (uint16_t)(y + 15u), 8u, 14u, 0u);
    LCD_printString("Tap", 44u, (uint16_t)(y + 10u), 1u, 1u);

    LCD_Draw_Circle(88u, (uint16_t)(y + 15u), 6u, 6u, 1u);
    LCD_Draw_Rect(85u, (uint16_t)(y + 4u), 6u, 22u, 6u, 1u);
    LCD_printString("Hold", 100u, (uint16_t)(y + 10u), 1u, 1u);

    G2_DrawObstacle(158u, (uint16_t)(y + 15u), 1u);
    LCD_printString("Avoid", 176u, (uint16_t)(y + 10u), 1u, 1u);
}

/*
 * Draws all unresolved notes at their current Y positions.
 * Hold notes are drawn as a clipped body plus a head; when active, the head is
 * pinned to the hit line so the player sees the sustained input state.
 */
static void G2_DrawNotes(const G2_GameState *state)
{
    uint16_t i;

    if (state->chart == 0) {
        return;
    }

    for (i = 0u; i < state->chart->note_count; ++i) {
        const G2_NoteEvent *note = &state->chart->notes[i];
        int32_t start_y;
        uint16_t center;

        if (state->note_state[i] == G2_NOTE_STATE_RESOLVED) {
            continue;
        }

        center = G2_LaneCenter(note->lane);
        start_y = G2_YForTime(state, note->hit_time_ms);

        if (note->type == G2_NOTE_OBSTACLE) {
            if (start_y >= (int32_t)(G2_PLAYFIELD_TOP - 14u) && start_y <= (int32_t)(G2_PLAYFIELD_BOTTOM + 14u)) {
                G2_DrawObstacle(center, (uint16_t)start_y, note->accent);
            }
            continue;
        }

        if (note->type == G2_NOTE_HOLD) {
            int32_t end_y = G2_YForTime(state, (uint32_t)note->hit_time_ms + (uint32_t)note->duration_ms);
            int32_t head_y = start_y;
            int32_t body_top;
            int32_t body_bottom;

            /* Active hold heads stay on the hit line while the tail continues scrolling. */
            if (state->note_state[i] == G2_NOTE_STATE_HOLDING) {
                head_y = G2_HIT_LINE_Y;
            }

            body_top = (head_y < end_y) ? head_y : end_y;
            body_bottom = (head_y > end_y) ? head_y : end_y;

            /* Clip long hold bodies to the playfield to avoid drawing outside bounds. */
            if (body_bottom >= (int32_t)G2_PLAYFIELD_TOP && body_top <= (int32_t)G2_PLAYFIELD_BOTTOM) {
                if (body_top < (int32_t)G2_PLAYFIELD_TOP) {
                    body_top = G2_PLAYFIELD_TOP;
                }
                if (body_bottom > (int32_t)G2_PLAYFIELD_BOTTOM) {
                    body_bottom = G2_PLAYFIELD_BOTTOM;
                }
                LCD_Draw_Rect((uint16_t)(center - 8u), (uint16_t)body_top, 16u, (uint16_t)(body_bottom - body_top + 1), 1u, 0u);
                LCD_Draw_Rect((uint16_t)(center - 5u), (uint16_t)body_top, 10u, (uint16_t)(body_bottom - body_top + 1), note->accent ? 10u : 6u, 1u);
                LCD_Draw_Rect((uint16_t)(center - 2u), (uint16_t)body_top, 4u, (uint16_t)(body_bottom - body_top + 1), 1u, 1u);
            }

            if (head_y >= (int32_t)(G2_PLAYFIELD_TOP - 14u) && head_y <= (int32_t)(G2_PLAYFIELD_BOTTOM + 14u)) {
                G2_DrawTapOrHoldHead(note, center, (uint16_t)head_y);
            }
            continue;
        }

        if (start_y >= (int32_t)(G2_PLAYFIELD_TOP - 14u) && start_y <= (int32_t)(G2_PLAYFIELD_BOTTOM + 14u)) {
            G2_DrawTapOrHoldHead(note, center, (uint16_t)start_y);
        }
    }
}

/* Converts combo size into the small animated equalizer bars near the HUD. */
static void G2_DrawComboEqualizer(const G2_GameState *state, uint32_t now_ms)
{
    uint8_t i;
    uint8_t level = (uint8_t)(state->scoring.combo / 6u);
    if (level > 6u) {
        level = 6u;
    }

    for (i = 0u; i < 6u; ++i) {
        uint8_t active = (i < level) ? 1u : 0u;
        uint8_t colour = active ? ((((now_ms / 140u) + i) & 1u) ? 14u : 10u) : 13u;
        uint16_t x = (uint16_t)(26u + i * 6u);
        LCD_Draw_Rect(x, 22u, 4u, 3u, colour, 1u);
        LCD_Draw_Rect((uint16_t)(210u - i * 6u), 22u, 4u, 3u, colour, 1u);
    }
}

/* Computes the final grade from accuracy, misses, and selected difficulty. */
static const char *G2_Grade(const G2_GameState *state)
{
    uint32_t accuracy_x10 = G2_Judge_AccuracyX10(&state->scoring);

    if (G2_Judge_TotalJudged(&state->scoring) == 0u) {
        return "C";
    }

    if (state->difficulty == G2_DIFF_PRACTICE) {
        if (accuracy_x10 >= 930u && state->scoring.miss_count <= 1u) return "S+";
        if (accuracy_x10 >= 860u && state->scoring.miss_count <= 4u) return "S";
        if (accuracy_x10 >= 720u) return "A";
        if (accuracy_x10 >= 560u) return "B";
        return "C";
    }

    if (accuracy_x10 >= 980u && state->scoring.miss_count == 0u) return "S+";
    if (accuracy_x10 >= 950u && state->scoring.miss_count <= 2u) return "S";
    if (accuracy_x10 >= 880u) return "A";
    if (accuracy_x10 >= 750u) return "B";
    return "C";
}

/* Renders the difficulty selection screen. */
void G2_Render_DifficultyMenu(const G2_GameState *state, uint32_t now_ms)
{
    uint8_t i;

    G2_DrawFrame(0u, now_ms);
    G2_DrawSparkles(now_ms);
    G2_PrintArcadeTitle("PULSE ORBIT", 14u, 2u, now_ms);
    G2_PrintCentered("SELECT DIFFICULTY", 40u, 13u, 1u);
    G2_PrintCentered("Focused rhythm layout", 54u, 8u, 1u);

    G2_DrawPanel(22u, 74u, 196u, 102u, 0u, 8u);
    for (i = 0u; i < G2_DIFF_COUNT; ++i) {
        uint16_t y = (uint16_t)(88u + (i * 30u));
        uint8_t selected = (i == state->difficulty_index);
        uint8_t fill = selected ? ((i == G2_DIFF_FRENZY) ? 2u : (i == G2_DIFF_STANDARD ? 14u : 10u)) : 0u;
        uint8_t border = selected ? fill : 13u;
        G2_DrawPanel(34u, (uint16_t)(y - 4u), 172u, 24u, fill, border);
        LCD_printString(selected ? ">" : " ", 46u, y, selected ? 0u : 13u, 2u);
        LCD_printString(G2_DifficultyNames[i], 72u, y, selected ? 0u : 1u, 2u);
    }

    G2_DrawLegend(184u);
    LCD_printString("BT3 START", 26u, 222u, 10u, 1u);
    LCD_printString("BT2 EXIT", 172u, 222u, 14u, 1u);
}

/* Renders the pre-song countdown and quick control reminder. */
void G2_Render_Countdown(const G2_GameState *state, uint32_t now_ms)
{
    uint32_t elapsed = now_ms - state->scene_enter_ms;
    uint32_t remain;
    char text[16];

    G2_DrawFrame(0u, now_ms);
    G2_DrawSparkles(now_ms);
    G2_PrintArcadeTitle("SYNC CHECK", 18u, 2u, now_ms);
    G2_PrintCentered(G2_DifficultyNames[state->difficulty], 42u, 14u, 2u);

    G2_DrawLegend(70u);
    G2_DrawPanel(18u, 104u, 204u, 64u, 0u, 8u);
    LCD_printString("JOYSTICK  : L / C / R (STICKY)", 24u, 116u, 1u, 1u);
    LCD_printString("BT3       : TAP / HOLD", 42u, 130u, 10u, 1u);
    LCD_printString("BT2 SIDE  : ALT TAP / HOLD", 28u, 144u, 14u, 1u);
    LCD_printString("BT2 MID   : PAUSE", 44u, 158u, 13u, 1u);

    G2_DrawPanel(66u, 176u, 108u, 28u, 0u, 13u);
    if (elapsed >= G2_COUNTDOWN_MS) {
        G2_PrintCentered("GO", 182u, 10u, 3u);
    } else {
        remain = (G2_COUNTDOWN_MS - elapsed + 999u) / 1000u;
        if (remain == 0u) {
            remain = 1u;
        }
        snprintf(text, sizeof(text), "%lu", (unsigned long)remain);
        G2_PrintCentered(text, 178u, 10u, 4u);
    }

    LCD_printString("BT3 SKIP", 92u, 222u, 13u, 1u);
}

/* Renders gameplay HUD, lanes, notes, judge feedback, and progress bar. */
void G2_Render_Play(const G2_GameState *state, uint32_t now_ms)
{
    char hud[40];
    uint16_t progress;
    uint8_t judge_colour;
    uint8_t combo_glow = (uint8_t)((state->scoring.fever_active != 0u) || (state->scoring.combo >= 10u) || (state->audio.combo_pulse_until_ms > now_ms));

    G2_DrawFrame(combo_glow, now_ms);
    G2_DrawComboEqualizer(state, now_ms);

    G2_DrawPanel(8u, 8u, 72u, 20u, 0u, 13u);
    LCD_printString("SCORE", 14u, 12u, 13u, 1u);
    snprintf(hud, sizeof(hud), "%05lu", (unsigned long)state->scoring.score);
    LCD_printString(hud, 38u, 12u, 1u, 1u);

    G2_DrawPanel(84u, 8u, 72u, 20u, combo_glow ? 14u : 0u, combo_glow ? 14u : 13u);
    LCD_printString("COMBO", 90u, 12u, combo_glow ? 0u : 13u, 1u);
    snprintf(hud, sizeof(hud), "%u", state->scoring.combo);
    LCD_printString(hud, 128u, 12u, combo_glow ? 0u : 1u, 1u);

    G2_DrawPanel(160u, 8u, 72u, 20u, state->scoring.fever_active ? 10u : 0u, state->scoring.fever_active ? 10u : 13u);
    if (state->scoring.fever_active != 0u) {
        LCD_printString("FEVER", 180u, 12u, 0u, 1u);
    } else {
        LCD_printString(G2_DifficultyNames[state->difficulty], 168u, 12u, 1u, 1u);
    }

    snprintf(hud, sizeof(hud), "x%u.%u", (uint16_t)(state->scoring.multiplier_tenths / 10u), (uint16_t)(state->scoring.multiplier_tenths % 10u));
    LCD_printString(hud, 20u, 34u, combo_glow ? 10u : 14u, 1u);
    snprintf(hud, sizeof(hud), "LANE %s", g_lane_names[state->selected_lane]);
    LCD_printString(hud, 132u, 34u, combo_glow ? 10u : 1u, 1u);

    if (state->scoring.fever_active != 0u) {
        G2_PrintCentered("FEVER ACTIVE", 54u, (uint8_t)(((now_ms / 160u) & 1u) ? 10u : 14u), 1u);
    }

    G2_DrawLaneGuide(state, now_ms);
    G2_DrawNotes(state);

    judge_colour = G2_JudgeColour(state->scoring.last_result);
    if (state->scoring.last_result == G2_JUDGE_NONE || now_ms - state->scoring.last_result_ms > G2_RESULT_FLASH_MS) {
        G2_DrawPanel(72u, 196u, 96u, 18u, 0u, 13u);
        G2_PrintCentered("READY", 201u, 13u, 1u);
    } else {
        uint8_t flash = (uint8_t)(((now_ms / 90u) & 1u) ? judge_colour : 1u);
        G2_DrawPanel(60u, 192u, 120u, 24u, flash, flash);
        G2_PrintCentered(G2_Judge_Label(state->scoring.last_result), 199u, 0u, 2u);
    }

    if (state->active_hold != 0u) {
        G2_DrawPanel(18u, 56u, 86u, 18u, 10u, 10u);
        LCD_printString("HOLD", 38u, 60u, 0u, 2u);
    } else if (state->elapsed_ms < G2_TUTORIAL_MS) {
        G2_DrawLegend(72u);
    }

    progress = 0u;
    if (state->chart != 0 && state->chart->song_length_ms != 0u) {
        progress = (uint16_t)((state->elapsed_ms * 204u) / state->chart->song_length_ms);
        if (progress > 204u) {
            progress = 204u;
        }
    }
    G2_DrawPanel(14u, 218u, 212u, 16u, 0u, 13u);
    LCD_Draw_Rect(18u, 222u, 204u, 8u, 0u, 1u);
    LCD_Draw_Rect(18u, 222u, progress, 8u, combo_glow ? 10u : 14u, 1u);
    if (progress > 4u) {
        LCD_Draw_Rect((uint16_t)(18u + progress - 4u), 220u, 4u, 12u, 1u, 1u);
    }
}

/* Renders the pause menu using the stored pause selection index. */
void G2_Render_Pause(const G2_GameState *state)
{
    uint8_t i;
    uint32_t now_ms = state->scene_enter_ms;

    G2_DrawFrame(0u, now_ms);
    G2_PrintArcadeTitle("PAUSE", 24u, 2u, now_ms);
    G2_PrintCentered("BT2 resumes immediately", 52u, 13u, 1u);

    G2_DrawPanel(34u, 78u, 172u, 112u, 0u, 8u);
    for (i = 0u; i < 3u; ++i) {
        uint16_t y = (uint16_t)(96u + (i * 30u));
        uint8_t selected = (i == state->pause_index);
        G2_DrawPanel(48u, (uint16_t)(y - 4u), 144u, 22u, selected ? 14u : 0u, selected ? 14u : 13u);
        LCD_printString(selected ? ">" : " ", 58u, y, selected ? 0u : 13u, 2u);
        LCD_printString(G2_PauseItems[i], 82u, y, selected ? 0u : 1u, 2u);
    }
}

/* Renders final grade, stats, records, and Retry/Menu choices. */
void G2_Render_Result(const G2_GameState *state)
{
    char line[40];
    uint32_t accuracy_x10 = G2_Judge_AccuracyX10(&state->scoring);
    uint8_t flashy = (uint8_t)((state->result_new_record != 0u || state->scoring.max_combo >= G2_FEVER_COMBO) ? 1u : 0u);

    G2_DrawFrame(flashy, state->scene_enter_ms);
    G2_DrawSparkles(state->scene_enter_ms);
    G2_PrintArcadeTitle("RESULT", 12u, 2u, state->scene_enter_ms);

    snprintf(line, sizeof(line), "GRADE %s", G2_Grade(state));
    G2_PrintCentered(line, 38u, flashy ? 10u : 14u, 3u);

    if (state->result_new_record != 0u) {
        G2_PrintCentered("NEW RECORD", 64u, 10u, 2u);
    } else if (state->scoring.miss_count == 0u && G2_Judge_TotalJudged(&state->scoring) != 0u) {
        G2_PrintCentered("FULL COMBO", 64u, 14u, 2u);
    }

    G2_DrawPanel(14u, 86u, 102u, 84u, 0u, 8u);
    snprintf(line, sizeof(line), "Score %05lu", (unsigned long)state->scoring.score);
    LCD_printString(line, 22u, 98u, 1u, 1u);
    snprintf(line, sizeof(line), "Best  %05lu", (unsigned long)state->result_high_score);
    LCD_printString(line, 22u, 112u, 13u, 1u);
    snprintf(line, sizeof(line), "Acc   %lu.%lu%%", (unsigned long)(accuracy_x10 / 10u), (unsigned long)(accuracy_x10 % 10u));
    LCD_printString(line, 22u, 126u, 10u, 1u);
    snprintf(line, sizeof(line), "Combo %u", state->scoring.max_combo);
    LCD_printString(line, 22u, 140u, 14u, 1u);

    G2_DrawPanel(124u, 86u, 102u, 84u, 0u, 8u);
    snprintf(line, sizeof(line), "Perfect %u", state->scoring.perfect_count);
    LCD_printString(line, 132u, 98u, 10u, 1u);
    snprintf(line, sizeof(line), "Good    %u", state->scoring.good_count);
    LCD_printString(line, 132u, 112u, 6u, 1u);
    snprintf(line, sizeof(line), "Miss    %u", state->scoring.miss_count);
    LCD_printString(line, 132u, 126u, 2u, 1u);
    snprintf(line, sizeof(line), "Avoid   %u", state->scoring.obstacle_clear_count);
    LCD_printString(line, 132u, 140u, 3u, 1u);

    if (state->scoring.miss_count == 0u && state->scoring.obstacle_clear_count != 0u) {
        LCD_printString("CLEAN RUN", 28u, 178u, 3u, 1u);
    }
    if (state->scoring.hold_count != 0u) {
        snprintf(line, sizeof(line), "Hold Bonus %u", state->scoring.hold_count);
        LCD_printString(line, 124u, 178u, 14u, 1u);
    }

    G2_DrawPanel(24u, 202u, 84u, 22u, state->result_index == 0u ? 14u : 0u, state->result_index == 0u ? 14u : 13u);
    G2_DrawPanel(132u, 202u, 84u, 22u, state->result_index == 1u ? 14u : 0u, state->result_index == 1u ? 14u : 13u);
    LCD_printString(state->result_index == 0u ? "> Retry" : "  Retry", 34u, 209u, state->result_index == 0u ? 0u : 1u, 1u);
    LCD_printString(state->result_index == 1u ? "> Menu" : "  Menu", 144u, 209u, state->result_index == 1u ? 0u : 1u, 1u);
}

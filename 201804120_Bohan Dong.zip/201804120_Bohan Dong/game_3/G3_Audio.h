#ifndef G3_AUDIO_H
#define G3_AUDIO_H

#include "G3_Types.h"

void G3_Audio_GameEnter(void);
void G3_Audio_OnEvent(G3_Event event, const G3_GameState *state);
void G3_Audio_SetPolarityVisual(const G3_GameState *state);
void G3_Audio_ShowIdleVisual(void);

#endif

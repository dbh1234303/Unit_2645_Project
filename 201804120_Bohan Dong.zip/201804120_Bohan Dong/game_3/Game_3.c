#include "Game_3.h"
#include "G3_Audio.h"
#include "G3_Core.h"
#include "G3_Levels.h"
#include "G3_Render.h"
#include "InputHandler.h"
#include "Joystick.h"
#include "LCD.h"
#include "stm32l4xx_hal.h"
#include <string.h>

extern ST7789V2_cfg_t cfg0;
extern Joystick_cfg_t joystick_cfg;
extern Joystick_t joystick_data;

#define G3_FRAME_TIME_MS        33u
#define G3_INPUT_REPEAT_MS     180u

typedef enum {
    G3_SCREEN_LEVEL_SELECT = 0,
    G3_SCREEN_PLAYING,
    G3_SCREEN_PAUSED,
    G3_SCREEN_RESULT
} G3_Screen;

static G3_LevelProgress g3_progress[G3_LEVEL_COUNT] = {
    {1u, 0u, 0u, 0u},
    {0u, 0u, 0u, 0u},
    {0u, 0u, 0u, 0u}
};

static Direction g3_get_cardinal_direction(const Joystick_t *joy)
{
    float abs_x;
    float abs_y;
    if (joy->direction == CENTRE) {
        return CENTRE;
    }

    abs_x = (joy->coord_mapped.x >= 0.0f) ? joy->coord_mapped.x : -joy->coord_mapped.x;
    abs_y = (joy->coord_mapped.y >= 0.0f) ? joy->coord_mapped.y : -joy->coord_mapped.y;

    if (abs_x > abs_y) {
        return (joy->coord_mapped.x >= 0.0f) ? E : W;
    }
    return (joy->coord_mapped.y >= 0.0f) ? N : S;
}

static uint8_t g3_nav_up(Direction d)
{
    return d == N ? 1u : 0u;
}

static uint8_t g3_nav_down(Direction d)
{
    return d == S ? 1u : 0u;
}

static void g3_store_progress(const G3_GameState *state)
{
    G3_LevelProgress *p = &g3_progress[state->level_index];
    uint8_t stars;
    uint16_t elapsed;

    if (state->result != G3_RESULT_WIN) {
        return;
    }

    stars = G3_Core_ComputeStars(state);
    elapsed = G3_Core_GetElapsedSeconds(state);

    if (stars > p->stars) {
        p->stars = stars;
    }
    if (p->best_steps == 0u || state->steps < p->best_steps) {
        p->best_steps = state->steps;
    }
    if (p->best_time_s == 0u || elapsed < p->best_time_s) {
        p->best_time_s = elapsed;
    }
    if (state->level_index + 1u < G3_LEVEL_COUNT) {
        g3_progress[state->level_index + 1u].unlocked = 1u;
    }
}

MenuState Game3_Run(void)
{
    G3_GameState game;
    G3_Screen screen = G3_SCREEN_LEVEL_SELECT;
    uint8_t selected_level = 0u;
    uint8_t pause_option = 0u;
    uint8_t result_option = 0u;
    Direction last_nav_dir = CENTRE;
    Direction last_move_dir = CENTRE;
    uint32_t last_move_tick = 0u;

    memset(&game, 0, sizeof(game));
    LCD_Set_Palette(PALETTE_DEFAULT);
    G3_Audio_GameEnter();

    while (1) {
        uint32_t frame_start = HAL_GetTick();
        Direction nav_dir;

        Input_Read();
        Joystick_Read(&joystick_cfg, &joystick_data);
        nav_dir = g3_get_cardinal_direction(&joystick_data);

        if (screen == G3_SCREEN_LEVEL_SELECT) {
            if (g3_nav_down(nav_dir) && last_nav_dir != nav_dir) {
                do {
                    selected_level = (uint8_t)((selected_level + 1u) % G3_LEVEL_COUNT);
                } while (!g3_progress[selected_level].unlocked);
            } else if (g3_nav_up(nav_dir) && last_nav_dir != nav_dir) {
                do {
                    selected_level = (selected_level == 0u) ? (G3_LEVEL_COUNT - 1u) : (uint8_t)(selected_level - 1u);
                } while (!g3_progress[selected_level].unlocked);
            }

            if (current_input.btn2_pressed) {
                G3_Audio_ShowIdleVisual();
                return MENU_STATE_HOME;
            }
            if (current_input.btn3_pressed && g3_progress[selected_level].unlocked) {
                G3_Core_LoadLevel(&game, selected_level);
                G3_Audio_SetPolarityVisual(&game);
                screen = G3_SCREEN_PLAYING;
                last_move_dir = CENTRE;
                last_move_tick = 0u;
            }
            G3_Render_LevelSelect(selected_level, g3_progress);
        }
        else if (screen == G3_SCREEN_PLAYING) {
            G3_Event event = G3_EVENT_NONE;

            if (current_input.btn2_pressed) {
                G3_Core_Pause(&game);
                screen = G3_SCREEN_PAUSED;
                pause_option = 0u;
            } else if (current_input.btn3_pressed) {
                event = G3_Core_TogglePolarity(&game);
            } else if (nav_dir != CENTRE && (nav_dir != last_move_dir || (HAL_GetTick() - last_move_tick) >= G3_INPUT_REPEAT_MS)) {
                if (nav_dir == N) {
                    event = G3_Core_MovePlayer(&game, 0, -1);
                } else if (nav_dir == S) {
                    event = G3_Core_MovePlayer(&game, 0, 1);
                } else if (nav_dir == E) {
                    event = G3_Core_MovePlayer(&game, 1, 0);
                } else if (nav_dir == W) {
                    event = G3_Core_MovePlayer(&game, -1, 0);
                }
                last_move_tick = HAL_GetTick();
            }

            if (event != G3_EVENT_NONE) {
                G3_Audio_OnEvent(event, &game);
            } else {
                G3_Audio_SetPolarityVisual(&game);
            }

            if (game.result != G3_RESULT_NONE) {
                g3_store_progress(&game);
                screen = G3_SCREEN_RESULT;
                result_option = 0u;
            }

            G3_Render_Game(&game);
        }
        else if (screen == G3_SCREEN_PAUSED) {
            if (current_input.btn2_pressed) {
                G3_Core_Resume(&game);
                screen = G3_SCREEN_PLAYING;
            } else {
                if (g3_nav_down(nav_dir) && last_nav_dir != nav_dir) {
                    pause_option = (uint8_t)((pause_option + 1u) % 3u);
                } else if (g3_nav_up(nav_dir) && last_nav_dir != nav_dir) {
                    pause_option = (pause_option == 0u) ? 2u : (uint8_t)(pause_option - 1u);
                }

                if (current_input.btn3_pressed) {
                    if (pause_option == 0u) {
                        G3_Core_Resume(&game);
                        screen = G3_SCREEN_PLAYING;
                    } else if (pause_option == 1u) {
                        G3_Core_LoadLevel(&game, game.level_index);
                        screen = G3_SCREEN_PLAYING;
                    } else {
                        G3_Audio_ShowIdleVisual();
                        return MENU_STATE_HOME;
                    }
                }
            }
            G3_Render_Pause(&game, pause_option);
        }
        else {
            if (g3_nav_down(nav_dir) && last_nav_dir != nav_dir) {
                result_option = (uint8_t)((result_option + 1u) % 3u);
            } else if (g3_nav_up(nav_dir) && last_nav_dir != nav_dir) {
                result_option = (result_option == 0u) ? 2u : (uint8_t)(result_option - 1u);
            }

            if (current_input.btn2_pressed) {
                G3_Audio_ShowIdleVisual();
                return MENU_STATE_HOME;
            }
            if (current_input.btn3_pressed) {
                if (result_option == 0u && game.result == G3_RESULT_WIN && (game.level_index + 1u) < G3_LEVEL_COUNT && g3_progress[game.level_index + 1u].unlocked) {
                    selected_level = (uint8_t)(game.level_index + 1u);
                    G3_Core_LoadLevel(&game, selected_level);
                    screen = G3_SCREEN_PLAYING;
                } else if (result_option == 1u || (result_option == 0u && game.result == G3_RESULT_FAIL)) {
                    G3_Core_LoadLevel(&game, game.level_index);
                    screen = G3_SCREEN_PLAYING;
                } else {
                    G3_Audio_ShowIdleVisual();
                    return MENU_STATE_HOME;
                }
            }
            G3_Render_Result(&game, result_option, g3_progress);
        }

        last_nav_dir = nav_dir;
        last_move_dir = nav_dir;

        {
            uint32_t frame_time = HAL_GetTick() - frame_start;
            if (frame_time < G3_FRAME_TIME_MS) {
                HAL_Delay(G3_FRAME_TIME_MS - frame_time);
            }
        }
    }
}

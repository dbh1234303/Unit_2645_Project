#ifndef G3_TYPES_H
#define G3_TYPES_H

#include <stdint.h>

typedef enum {
    G3_TILE_FLOOR = 0,
    G3_TILE_WALL,
    G3_TILE_SWITCH,
    G3_TILE_GATE,
    G3_TILE_EXIT,
    G3_TILE_TRAP
} G3_Tile;

typedef enum {
    G3_POLARITY_NORTH = 0,
    G3_POLARITY_SOUTH = 1
} G3_Polarity;

typedef enum {
    G3_RESULT_NONE = 0,
    G3_RESULT_WIN,
    G3_RESULT_FAIL
} G3_Result;

typedef enum {
    G3_EVENT_NONE = 0,
    G3_EVENT_MOVE,
    G3_EVENT_PUSH_BOX,
    G3_EVENT_PULL_BOX,
    G3_EVENT_REPEL_BOX,
    G3_EVENT_TOGGLE_ONLY,
    G3_EVENT_GATE_OPEN,
    G3_EVENT_GATE_CLOSE,
    G3_EVENT_BLOCKED,
    G3_EVENT_WIN,
    G3_EVENT_FAIL
} G3_Event;

typedef struct {
    int8_t x;
    int8_t y;
} G3_Pos;

#define G3_MAX_WIDTH     10
#define G3_MAX_HEIGHT    10
#define G3_MAX_BOXES      2
#define G3_MAX_SWITCHES   2
#define G3_LEVEL_COUNT    3

typedef struct {
    const char *title;
    const char *subtitle;
    uint8_t width;
    uint8_t height;
    uint16_t par_steps;
    uint16_t par_time_s;
    const char *rows[G3_MAX_HEIGHT];
} G3_LevelDef;

typedef struct {
    uint8_t unlocked;
    uint8_t stars;
    uint16_t best_steps;
    uint16_t best_time_s;
} G3_LevelProgress;

typedef struct {
    const G3_LevelDef *level_def;
    uint8_t level_index;
    uint8_t width;
    uint8_t height;
    G3_Tile tiles[G3_MAX_HEIGHT][G3_MAX_WIDTH];

    G3_Pos player;
    G3_Pos boxes[G3_MAX_BOXES];
    uint8_t box_count;

    G3_Pos switches[G3_MAX_SWITCHES];
    uint8_t switch_count;

    G3_Polarity polarity;
    uint8_t gate_open;
    uint16_t steps;
    uint32_t level_start_tick;
    uint32_t paused_accum_ms;
    uint32_t pause_start_tick;
    uint8_t paused;
    G3_Result result;
    char hint[48];
} G3_GameState;

#endif

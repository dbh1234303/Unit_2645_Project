#include "G3_Audio.h"
#include "PWM.h"
#include "Buzzer.h"
#include "stm32l4xx_hal.h"

extern PWM_cfg_t pwm_cfg;
extern Buzzer_cfg_t buzzer_cfg;

static void g3_play_tone(uint32_t freq, uint8_t volume, uint16_t duration_ms)
{
    buzzer_tone(&buzzer_cfg, freq, volume);
    HAL_Delay(duration_ms);
    buzzer_off(&buzzer_cfg);
}

void G3_Audio_SetPolarityVisual(const G3_GameState *state)
{
    if (state == 0) {
        return;
    }

    if (state->result == G3_RESULT_FAIL) {
        PWM_SetDuty(&pwm_cfg, 100);
        return;
    }

    if (state->gate_open) {
        PWM_SetDuty(&pwm_cfg, 85);
        return;
    }

    if (state->polarity == G3_POLARITY_NORTH) {
        PWM_SetDuty(&pwm_cfg, 25);
    } else {
        PWM_SetDuty(&pwm_cfg, 60);
    }
}

void G3_Audio_ShowIdleVisual(void)
{
    PWM_SetDuty(&pwm_cfg, 15);
}

void G3_Audio_GameEnter(void)
{
    g3_play_tone(988, 28, 35);
    g3_play_tone(1319, 28, 35);
    G3_Audio_ShowIdleVisual();
}

void G3_Audio_OnEvent(G3_Event event, const G3_GameState *state)
{
    switch (event) {
        case G3_EVENT_MOVE:
            g3_play_tone(740, 12, 8);
            break;
        case G3_EVENT_PUSH_BOX:
            g3_play_tone(523, 22, 25);
            break;
        case G3_EVENT_PULL_BOX:
            g3_play_tone(659, 22, 25);
            break;
        case G3_EVENT_REPEL_BOX:
            g3_play_tone(392, 22, 25);
            break;
        case G3_EVENT_TOGGLE_ONLY:
            g3_play_tone(880, 20, 18);
            break;
        case G3_EVENT_GATE_OPEN:
            g3_play_tone(988, 25, 20);
            g3_play_tone(1319, 25, 45);
            break;
        case G3_EVENT_GATE_CLOSE:
            g3_play_tone(440, 16, 20);
            break;
        case G3_EVENT_WIN:
            g3_play_tone(1047, 30, 35);
            g3_play_tone(1319, 30, 35);
            g3_play_tone(1568, 30, 65);
            break;
        case G3_EVENT_FAIL:
            g3_play_tone(330, 30, 70);
            break;
        case G3_EVENT_BLOCKED:
            g3_play_tone(247, 12, 15);
            break;
        case G3_EVENT_NONE:
        default:
            break;
    }

    G3_Audio_SetPolarityVisual(state);
}

#include "G3_Render.h"
#include "G3_Core.h"
#include "LCD.h"
#include <stdio.h>
#include <string.h>

extern ST7789V2_cfg_t cfg0;

#define G3_COL_BG         0
#define G3_COL_TEXT       1
#define G3_COL_PLAYER     14
#define G3_COL_WALL       13
#define G3_COL_FLOOR      9
#define G3_COL_SWITCH     8
#define G3_COL_GATE_CLS   5
#define G3_COL_GATE_OPN   3
#define G3_COL_EXIT       6
#define G3_COL_TRAP       2
#define G3_COL_BOX        10
#define G3_COL_ACCENT     7
#define G3_COL_DIM        13

static void g3_draw_panel(uint16_t x, uint16_t y, uint16_t w, uint16_t h)
{
    LCD_Draw_Rect(x, y, w, h, G3_COL_DIM, 0);
}

static void g3_draw_centered_text(const char *text, uint16_t y, uint8_t colour, uint8_t size)
{
    uint16_t width = (uint16_t)(strlen(text) * 6u * size);
    uint16_t x = (240u > width) ? (uint16_t)((240u - width) / 2u) : 0u;
    LCD_printString(text, x, y, colour, size);
}

static void g3_format_time(uint16_t seconds, char *out, uint16_t out_len)
{
    uint16_t mins = (uint16_t)(seconds / 60u);
    uint16_t secs = (uint16_t)(seconds % 60u);
    snprintf(out, out_len, "%02u:%02u", mins, secs);
}

static void g3_draw_tile(const G3_GameState *state, uint8_t tx, uint8_t ty, uint16_t tile_size, uint16_t ox, uint16_t oy)
{
    uint16_t px = ox + (uint16_t)(tx * tile_size);
    uint16_t py = oy + (uint16_t)(ty * tile_size);
    G3_Tile tile = state->tiles[ty][tx];
    uint8_t colour = G3_COL_FLOOR;

    switch (tile) {
        case G3_TILE_WALL:
            colour = G3_COL_WALL;
            break;
        case G3_TILE_SWITCH:
            colour = G3_COL_SWITCH;
            break;
        case G3_TILE_GATE:
            colour = state->gate_open ? G3_COL_GATE_OPN : G3_COL_GATE_CLS;
            break;
        case G3_TILE_EXIT:
            colour = G3_COL_EXIT;
            break;
        case G3_TILE_TRAP:
            colour = G3_COL_TRAP;
            break;
        case G3_TILE_FLOOR:
        default:
            colour = G3_COL_FLOOR;
            break;
    }

    LCD_Draw_Rect(px, py, tile_size - 1u, tile_size - 1u, colour, 1);
    LCD_Draw_Rect(px, py, tile_size - 1u, tile_size - 1u, G3_COL_TEXT, 0);

    if (tile == G3_TILE_SWITCH) {
        LCD_printString("M", px + 5u, py + 5u, G3_COL_TEXT, 1);
    } else if (tile == G3_TILE_GATE) {
        LCD_printString("G", px + 5u, py + 5u, G3_COL_TEXT, 1);
    } else if (tile == G3_TILE_EXIT) {
        LCD_printString("E", px + 5u, py + 5u, G3_COL_TEXT, 1);
    } else if (tile == G3_TILE_TRAP) {
        LCD_printString("T", px + 5u, py + 5u, G3_COL_TEXT, 1);
    }
}

static void g3_draw_map(const G3_GameState *state)
{
    uint16_t tile_size = 18u;
    uint16_t ox = (uint16_t)((240u - state->width * tile_size) / 2u);
    uint16_t oy = 34u;
    uint8_t x;
    uint8_t y;
    uint8_t i;

    for (y = 0; y < state->height; ++y) {
        for (x = 0; x < state->width; ++x) {
            g3_draw_tile(state, x, y, tile_size, ox, oy);
        }
    }

    for (i = 0; i < state->box_count; ++i) {
        uint16_t px = ox + (uint16_t)(state->boxes[i].x * tile_size) + 3u;
        uint16_t py = oy + (uint16_t)(state->boxes[i].y * tile_size) + 3u;
        LCD_Draw_Rect(px, py, tile_size - 7u, tile_size - 7u, G3_COL_BOX, 1);
        LCD_Draw_Rect(px, py, tile_size - 7u, tile_size - 7u, G3_COL_TEXT, 0);
        LCD_printString("B", px + 4u, py + 3u, G3_COL_BG, 1);
    }

    {
        uint16_t px = ox + (uint16_t)(state->player.x * tile_size) + 4u;
        uint16_t py = oy + (uint16_t)(state->player.y * tile_size) + 4u;
        LCD_Draw_Circle(px + 4u, py + 4u, 6u, G3_COL_PLAYER, 1);
        LCD_printString(state->polarity == G3_POLARITY_NORTH ? "N" : "S", px + 2u, py + 1u, G3_COL_BG, 1);
    }
}

void G3_Render_LevelSelect(uint8_t selected_level, const G3_LevelProgress progress[G3_LEVEL_COUNT])
{
    uint8_t i;
    LCD_Fill_Buffer(G3_COL_BG);
    g3_draw_centered_text("MAGNETIC MAZE", 10u, G3_COL_TEXT, 2u);
    g3_draw_centered_text("Research Tower", 28u, G3_COL_ACCENT, 1u);
    g3_draw_panel(18u, 48u, 204u, 136u);

    for (i = 0; i < G3_LEVEL_COUNT; ++i) {
        char line[48];
        char stars[8] = "---";
        uint16_t y = (uint16_t)(62u + i * 32u);
        uint8_t colour = progress[i].unlocked ? G3_COL_TEXT : G3_COL_DIM;

        if (progress[i].stars > 0u) {
            uint8_t s;
            for (s = 0; s < 3u; ++s) {
                stars[s] = (s < progress[i].stars) ? '*' : '-';
            }
            stars[3] = '\0';
        }

        snprintf(line, sizeof(line), "%c Level %u", (i == selected_level) ? '>' : ' ', (unsigned)(i + 1u));
        LCD_printString(line, 28u, y, colour, 2u);
        LCD_printString(i == 0u ? "Polarity Basics" : (i == 1u ? "Push the Box" : "Cross Platforms"), 48u, y + 14u, colour, 1u);
        LCD_printString(progress[i].unlocked ? stars : "LOCK", 182u, y + 6u, colour, 1u);
    }

    LCD_printString("JOY: Select level", 24u, 196u, G3_COL_TEXT, 1u);
    LCD_printString("BTN3: Start", 24u, 210u, G3_COL_TEXT, 1u);
    LCD_printString("BTN2: Back to menu", 24u, 224u, G3_COL_TEXT, 1u);
    LCD_Refresh(&cfg0);
}

void G3_Render_Game(const G3_GameState *state)
{
    char top_line[32];
    char time_str[8];

    LCD_Fill_Buffer(G3_COL_BG);
    g3_format_time(G3_Core_GetElapsedSeconds(state), time_str, sizeof(time_str));
    snprintf(top_line, sizeof(top_line), "L%u  ST:%03u  %s  [%c]", (unsigned)(state->level_index + 1u), (unsigned)state->steps, time_str, state->polarity == G3_POLARITY_NORTH ? 'N' : 'S');
    LCD_printString(top_line, 8u, 8u, G3_COL_TEXT, 1u);
    LCD_Draw_Line(6u, 24u, 233u, 24u, G3_COL_DIM);

    g3_draw_map(state);

    LCD_Draw_Line(6u, 216u, 233u, 216u, G3_COL_DIM);
    LCD_printString(state->hint, 8u, 220u, G3_COL_TEXT, 1u);
    LCD_Refresh(&cfg0);
}

void G3_Render_Pause(const G3_GameState *state, uint8_t selected_option)
{
    const char *options[3] = {"Resume", "Restart", "Menu"};
    uint8_t i;
    char line[24];
    char time_str[8];

    LCD_Fill_Buffer(G3_COL_BG);
    g3_draw_centered_text("PAUSED", 18u, G3_COL_TEXT, 3u);
    g3_draw_panel(36u, 62u, 168u, 112u);

    for (i = 0; i < 3u; ++i) {
        snprintf(line, sizeof(line), "%c %s", (i == selected_option) ? '>' : ' ', options[i]);
        LCD_printString(line, 60u, (uint16_t)(78u + i * 24u), G3_COL_TEXT, 2u);
    }

    g3_format_time(G3_Core_GetElapsedSeconds(state), time_str, sizeof(time_str));
    LCD_printString(state->polarity == G3_POLARITY_NORTH ? "Polarity: N" : "Polarity: S", 56u, 146u, G3_COL_TEXT, 1u);
    snprintf(line, sizeof(line), "Steps: %u  %s", (unsigned)state->steps, time_str);
    LCD_printString(line, 56u, 160u, G3_COL_TEXT, 1u);
    LCD_Refresh(&cfg0);
}

void G3_Render_Result(const G3_GameState *state, uint8_t selected_option, const G3_LevelProgress progress[G3_LEVEL_COUNT])
{
    const char *options[3] = {
        (state->result == G3_RESULT_WIN && (state->level_index + 1u) < G3_LEVEL_COUNT && progress[state->level_index + 1u].unlocked) ? "Next" : "Replay",
        "Replay",
        "Menu"
    };
    char line[32];
    char time_str[8];
    char stars[8] = "---";
    uint8_t i;
    uint8_t star_count = progress[state->level_index].stars;

    LCD_Fill_Buffer(G3_COL_BG);
    if (state->result == G3_RESULT_WIN) {
        g3_draw_centered_text("LEVEL COMPLETE", 12u, G3_COL_TEXT, 2u);
    } else {
        g3_draw_centered_text("LEVEL FAILED", 12u, G3_COL_TRAP, 2u);
    }

    g3_draw_panel(24u, 44u, 192u, 152u);
    g3_format_time(G3_Core_GetElapsedSeconds(state), time_str, sizeof(time_str));
    snprintf(line, sizeof(line), "Steps : %u", (unsigned)state->steps);
    LCD_printString(line, 40u, 60u, G3_COL_TEXT, 2u);
    snprintf(line, sizeof(line), "Time  : %s", time_str);
    LCD_printString(line, 40u, 84u, G3_COL_TEXT, 2u);

    for (i = 0; i < 3u; ++i) {
        stars[i] = (i < star_count) ? '*' : '-';
    }
    stars[3] = '\0';
    LCD_printString("Stars :", 40u, 112u, G3_COL_TEXT, 2u);
    LCD_printString(stars, 124u, 112u, G3_COL_ACCENT, 2u);

    for (i = 0; i < 3u; ++i) {
        snprintf(line, sizeof(line), "%c %s", (i == selected_option) ? '>' : ' ', options[i]);
        LCD_printString(line, 52u, (uint16_t)(142u + i * 18u), G3_COL_TEXT, 1u);
    }
    LCD_Refresh(&cfg0);
}
